// Headless rules tests: full AI-only matches for 2–6 players plus targeted
// scenarios for every card. Run with: node scripts/sim.mjs
import { CARD_INFO, regularCounts } from "../src/game/rules/cards.js";
import {
  applyCommand, checkIntegrity, createMatch, dealMatch, eligibleReactors, legalPlays, legalReactions, PHASE,
} from "../src/game/rules/engine.js";
import { answerPrompt, chooseReaction, chooseTurn, createMemory, observe } from "../src/game/rules/ai.js";

let failures = 0;
const results = [];
const assert = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log("  FAIL:", msg);
  }
  return cond;
};

function seededRnd(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function runMatch(n, seed, diffs) {
  const rnd = seededRnd(seed * 7 + 3);
  const match = createMatch({
    seed,
    players: Array.from({ length: n }, (_, i) => ({ name: `P${i}`, avatar: 2 + i, isAI: true, difficulty: diffs[i % diffs.length] })),
  });
  const deal = dealMatch(match);
  checkIntegrity(match);
  const mem = match.players.map(() => createMemory());
  const counts = { plays: {}, reacts: {}, draws: 0, eliminations: 0, defuses: 0, kafkhaStack: 0 };
  const feed = (events) => {
    for (const e of events) {
      match.players.forEach((p) => observe(mem[p.id], match, e, p.id));
      if (e.type === "play") counts.plays[e.cardType] = (counts.plays[e.cardType] || 0) + 1;
      if (e.type === "react") counts.reacts[e.cardType] = (counts.reacts[e.cardType] || 0) + 1;
      if (e.type === "draw") counts.draws++;
      if (e.type === "eliminate") counts.eliminations++;
      if (e.type === "defuse") counts.defuses++;
      if (e.type === "resolve" && e.effective === "kafkha" && e.debt > 2) counts.kafkhaStack++;
    }
  };
  feed(deal);
  let steps = 0;
  while (match.phase !== PHASE.GAME_OVER) {
    if (++steps > 20000) throw new Error(`stuck after ${steps} steps (phase ${match.phase})`);
    let cmd;
    if (match.phase === PHASE.PLAYER_TURN) cmd = chooseTurn(match, match.turn, mem[match.turn], rnd);
    else if (match.phase === PHASE.REACTION_WINDOW) {
      const reactors = eligibleReactors(match).sort(() => rnd() - 0.5);
      cmd = null;
      for (const id of reactors) {
        const c = chooseReaction(match, id, mem[id], rnd);
        if (c.kind === "react") { cmd = c; break; }
      }
      if (!cmd) cmd = { kind: "closeReactions" };
    } else cmd = answerPrompt(match, match.prompt.player, mem[match.prompt.player], rnd);
    cmd.cid = `cmd${steps}`;
    const res = applyCommand(match, cmd);
    if (!res.ok) throw new Error(`rejected ${JSON.stringify(cmd)}: ${res.error}`);
    // Duplicate command id must be rejected.
    if (steps % 50 === 0) {
      const dup = applyCommand(match, cmd);
      if (dup.ok || dup.error !== "duplicate") throw new Error("duplicate command accepted");
    }
    feed(res.events);
    checkIntegrity(match);
  }
  const alive = match.players.filter((p) => p.alive);
  if (alive.length !== 1 || match.winner !== alive[0].id) throw new Error("bad winner");
  if (match.eliminated.length !== n - 1) throw new Error("bad elimination count");
  return { counts, steps, turns: match.turnCount };
}

// ---------------------------------------------------------------------------
console.log("== Deck composition ==");
for (let n = 2; n <= 6; n++) {
  const m = createMatch({ seed: n, players: Array.from({ length: n }, (_, i) => ({ name: `P${i}`, isAI: true })) });
  dealMatch(m);
  const types = Object.values(m.cards);
  const regular = types.filter((t) => t !== "batran" && t !== "wafqari").length;
  const bat = types.filter((t) => t === "batran").length;
  const waf = types.filter((t) => t === "wafqari").length;
  const handsOk = m.players.every((p) => p.hand.length === 6 && p.hand.filter((c) => m.cards[c] === "batran").length === 1 && !p.hand.some((c) => m.cards[c] === "wafqari"));
  const uniqueIds = new Set(Object.keys(m.cards)).size === types.length;
  const ok = assert(regular === 8 * n && bat === n && waf === n - 1 && handsOk && uniqueIds && m.deck.length === 8 * n - 5 * n + (n - 1), `deck for ${n}`);
  console.log(`  ${n}p: ${regular} action + ${bat} Batran + ${waf} Wafqari; hands 1 Batran + 5; deck ${m.deck.length} ${ok ? "OK" : ""}`);
  if (n === 6) console.log("   6p counts:", JSON.stringify(regularCounts(6)));
}

console.log("== Full AI matches ==");
const diffSets = [["easy"], ["medium"], ["hard"], ["easy", "medium", "hard"]];
for (let n = 2; n <= 6; n++) {
  let games = 0;
  let totalTurns = 0;
  const agg = { plays: {}, reacts: {}, draws: 0, eliminations: 0, defuses: 0, kafkhaStack: 0 };
  for (let s = 1; s <= 300; s++) {
    try {
      const r = runMatch(n, s * 31 + n, diffSets[s % diffSets.length]);
      games++;
      totalTurns += r.turns;
      for (const k of Object.keys(r.counts.plays)) agg.plays[k] = (agg.plays[k] || 0) + r.counts.plays[k];
      for (const k of Object.keys(r.counts.reacts)) agg.reacts[k] = (agg.reacts[k] || 0) + r.counts.reacts[k];
      agg.draws += r.counts.draws; agg.eliminations += r.counts.eliminations; agg.defuses += r.counts.defuses; agg.kafkhaStack += r.counts.kafkhaStack;
    } catch (e) {
      assert(false, `${n}p seed ${s}: ${e.message}`);
    }
  }
  const played = Object.keys(agg.plays).length;
  console.log(`  ${n}p: ${games}/300 matches finished, avg ${(totalTurns / games).toFixed(1)} turns, ${played} card types played, reactions ${JSON.stringify(agg.reacts)}, defuses ${agg.defuses}, eliminations ${agg.eliminations}, stacked kafkha ${agg.kafkhaStack}`);
  results.push({ n, games });
}

// ---------------------------------------------------------------------------
// Targeted scenarios on a hand-built 3-player table.
console.log("== Card scenarios ==");
let cardSeq = 1000;
function table(hands, deck, opts = {}) {
  const m = createMatch({ seed: 5, players: hands.map((_, i) => ({ name: `P${i}`, isAI: true, difficulty: "hard" })) });
  const mk = (t) => { const id = `t${cardSeq++}`; m.cards[id] = t; return id; };
  m.players.forEach((p, i) => { p.hand = hands[i].map(mk); });
  m.deck = deck.map(mk);
  m.discard = (opts.discard || []).map(mk);
  m.turn = opts.turn || 0;
  m.phase = PHASE.PLAYER_TURN;
  m.debt = opts.debt || 1;
  m.underAttack = Boolean(opts.underAttack);
  m.lastCopyable = opts.lastCopyable || null;
  return m;
}
const cardOf = (m, p, t) => m.players[p].hand.find((c) => m.cards[c] === t);
const types = (m, list) => list.map((c) => m.cards[c]);
const ok = (res, label) => assert(res.ok, `${label}: ${res.error}`);
const play = (m, p, t, extra = {}) => applyCommand(m, { kind: "play", player: p, cardId: cardOf(m, p, t), ...extra });
const close = (m) => applyCommand(m, { kind: "closeReactions" });
const W = ["wafqari", "wafqari"];

function scenario(name, fn) {
  try { fn(); console.log(`  ✓ ${name}`); } catch (e) { assert(false, `${name}: ${e.message}`); }
}

scenario("وافقري without البطران eliminates", () => {
  const m = table([["khabs"], ["batran"], ["batran"]], ["wafqari", "khabs", "wafqari"]);
  ok(applyCommand(m, { kind: "draw", player: 0 }), "draw");
  assert(!m.players[0].alive && m.turn === 1 && m.discard.length === 2, "p0 out, hand + wafqari discarded, turn → p1");
  checkIntegrity(m);
});
scenario("البطران defuse + secret reinsertion at chosen position", () => {
  const m = table([["batran"], ["khabs"], ["khabs"]], ["wafqari", "baser", "shima", "khabs", "wafqari"]);
  ok(applyCommand(m, { kind: "draw", player: 0 }), "draw");
  assert(m.phase === PHASE.DEFUSE_SELECTION && m.prompt.kind === "reinsert" && m.prompt.player === 0, "reinsert prompt");
  assert(!applyCommand(m, { kind: "reinsert", player: 1, position: 0 }).ok, "other player cannot place it");
  ok(applyCommand(m, { kind: "reinsert", player: 0, position: 2 }), "reinsert");
  assert(m.cards[m.deck[2]] === "wafqari" && m.players[0].alive && m.turn === 1, "at position 2, turn passes");
  assert(m.players[0].hand.length === 0 && m.discard.some((c) => m.cards[c] === "batran"), "batran consumed");
  checkIntegrity(m);
});
scenario("كفخة: target owes two actions", () => {
  const m = table([["kafkha"], ["khabs", "khabs"], ["khabs"]], ["baser", "shima", "khabs", "salakhni", ...W]);
  ok(play(m, 0, "kafkha", { target: 2 }), "play"); ok(close(m), "close");
  assert(m.turn === 2 && m.debt === 2 && m.underAttack, "p2 owes 2");
  ok(applyCommand(m, { kind: "draw", player: 2 }), "draw 1");
  assert(m.turn === 2 && m.debt === 1, "still p2");
  ok(play(m, 2, "khabs"), "play 2"); ok(close(m), "close");
  assert(m.turn === 0 && m.debt === 1, "debt paid, next player in order (from p2 → p0)");
});
scenario("كفخة stacking: 2 → 4 passes to next player", () => {
  const m = table([["kafkha"], ["kafkha", "khabs"], ["khabs"]], ["baser", "shima", "khabs", ...W]);
  ok(play(m, 0, "kafkha", { target: 1 }), "play"); ok(close(m), "close");
  assert(m.turn === 1 && m.debt === 2, "p1 owes 2");
  ok(play(m, 1, "kafkha", { target: 0 }), "stack"); ok(close(m), "close");
  assert(m.turn === 2 && m.debt === 4, `stacked to next player with 4 (got p${m.turn} ${m.debt})`);
});
scenario("سلفني: target chooses the card privately", () => {
  const m = table([["salifni"], ["hajaa", "batran", "khabs"], ["khabs"]], ["baser", ...W]);
  ok(play(m, 0, "salifni", { target: 1 }), "play"); ok(close(m), "close");
  assert(m.prompt?.kind === "give" && m.prompt.player === 1, "target prompted");
  assert(!applyCommand(m, { kind: "give", player: 0, cardId: m.players[1].hand[0] }).ok, "actor cannot choose");
  const k = cardOf(m, 1, "khabs");
  ok(applyCommand(m, { kind: "give", player: 1, cardId: k }), "give");
  assert(m.players[0].hand.includes(k) && m.turn === 1, "card moved to actor");
});
scenario("ساقب swaps whole hands", () => {
  const m = table([["saqib", "khabs"], ["batran", "hajaa", "kafkha"], ["khabs"]], ["baser", ...W]);
  ok(play(m, 0, "saqib", { target: 1 }), "play"); ok(close(m), "close");
  assert(types(m, m.players[0].hand).sort().join() === "batran,hajaa,kafkha" && types(m, m.players[1].hand).join() === "khabs", "swapped");
});
scenario("هبش takes up to two random cards (one if that's all)", () => {
  const m = table([["habsh", "habsh"], ["khabs", "baser", "shima"], ["batran"]], ["baser", "shima", ...W], { debt: 2, underAttack: true });
  ok(play(m, 0, "habsh", { target: 1 }), "play"); ok(close(m), "close");
  assert(m.players[1].hand.length === 1 && m.players[0].hand.length === 3, "took 2");
  ok(play(m, 0, "habsh", { target: 2 }), "play 2"); ok(close(m), "close");
  assert(m.players[2].hand.length === 0, "took the only card");
});
scenario("العيار reorders the top three privately", () => {
  const m = table([["ayyar"], ["khabs"], ["khabs"]], ["wafqari", "baser", "shima", "khabs", "wafqari"]);
  ok(play(m, 0, "ayyar"), "play"); ok(close(m), "close");
  assert(m.prompt?.kind === "reorder" && m.prompt.cards.length === 3, "prompt");
  const [a, b, c] = m.prompt.cards;
  ok(applyCommand(m, { kind: "reorder", player: 0, order: [b, c, a] }), "reorder");
  assert(m.deck[2] === a && m.deck[0] === b, "new order applied");
});
scenario("باصر reveals top three without changing order", () => {
  const m = table([["baser"], ["khabs"], ["khabs"]], ["wafqari", "baser", "shima", "khabs", "wafqari"]);
  const before = m.deck.slice();
  ok(play(m, 0, "baser"), "play"); const r = close(m);
  const ev = r.events.find((e) => e.type === "resolve");
  assert(ev.revealed.join() === before.slice(0, 3).join() && m.deck.join() === before.join(), "revealed, order kept");
});
scenario("خبص shuffles (same cards)", () => {
  const m = table([["khabs"], ["khabs"], ["khabs"]], ["wafqari", "baser", "shima", "khabs", "kafkha", "habsh", "wafqari"]);
  const before = m.deck.slice().sort().join();
  ok(play(m, 0, "khabs"), "play"); ok(close(m), "close");
  assert(m.deck.slice().sort().join() === before, "same cards");
});
scenario("شوح reverses direction", () => {
  const m = table([["shawwah"], ["khabs"], ["khabs"]], ["baser", ...W]);
  ok(play(m, 0, "shawwah"), "play"); ok(close(m), "close");
  assert(m.direction === -1 && m.turn === 2, "reversed → p2 next");
});
scenario("سلخني ends turn without drawing", () => {
  const m = table([["salakhni"], ["khabs"], ["khabs"]], ["baser", ...W]);
  const deckLen = m.deck.length;
  ok(play(m, 0, "salakhni"), "play"); ok(close(m), "close");
  assert(m.turn === 1 && m.deck.length === deckLen && m.players[0].hand.length === 0, "skipped");
});
scenario("هجع cancels; a second هجع restores", () => {
  const m = table([["kafkha"], ["hajaa"], ["hajaa"]], ["baser", ...W]);
  ok(play(m, 0, "kafkha", { target: 1 }), "play");
  ok(applyCommand(m, { kind: "react", player: 1, cardId: cardOf(m, 1, "hajaa"), chainLen: 0 }), "hajaa");
  assert(m.pending.cancelled, "cancelled");
  assert(!applyCommand(m, { kind: "react", player: 2, cardId: cardOf(m, 2, "hajaa"), chainLen: 0 }).ok, "stale simultaneous reaction rejected");
  ok(applyCommand(m, { kind: "react", player: 2, cardId: cardOf(m, 2, "hajaa"), chainLen: 1 }), "hajaa 2");
  assert(!m.pending.cancelled, "restored");
  ok(close(m), "close");
  assert(m.turn === 1 && m.debt === 2, "kafkha landed");
});
scenario("هجع cancellation still uses the action", () => {
  const m = table([["habsh"], ["hajaa", "khabs"], ["khabs"]], ["baser", ...W]);
  ok(play(m, 0, "habsh", { target: 1 }), "play");
  ok(applyCommand(m, { kind: "react", player: 1, cardId: cardOf(m, 1, "hajaa"), chainLen: 0 }), "hajaa");
  ok(close(m), "close");
  assert(m.players[1].hand.length === 1 && m.turn === 1, "nothing stolen, turn passed");
});
scenario("صوبنا takes over: redirected كفخة", () => {
  const m = table([["kafkha"], ["sawbna"], ["khabs"]], ["baser", ...W]);
  ok(play(m, 0, "kafkha", { target: 1 }), "play");
  ok(applyCommand(m, { kind: "react", player: 1, cardId: cardOf(m, 1, "sawbna"), target: 0, chainLen: 0 }), "sawbna");
  ok(close(m), "close");
  assert(m.turn === 0 && m.debt === 2, "attacker now owes 2");
});
scenario("صوبنا takes over: هبش benefit goes to reactor", () => {
  const m = table([["habsh", "kafkha", "khabs"], ["sawbna", "baser"], ["khabs"]], ["baser", ...W]);
  ok(play(m, 0, "habsh", { target: 1 }), "play");
  ok(applyCommand(m, { kind: "react", player: 1, cardId: cardOf(m, 1, "sawbna"), target: 0, chainLen: 0 }), "sawbna");
  ok(close(m), "close");
  assert(m.players[1].hand.length === 3 && m.players[0].hand.length === 0, "reactor stole 2 from original actor");
});
scenario("هجع/صوبنا can't be played as actions; وافقري/البطران never pending", () => {
  const m = table([["hajaa", "sawbna", "batran"], ["khabs"], ["khabs"]], ["baser", ...W]);
  assert(legalPlays(m, 0).length === 0, "no legal plays");
  assert(!play(m, 0, "batran").ok, "batran rejected");
});
scenario("صوبنا not allowed on شوح", () => {
  const m = table([["shawwah"], ["sawbna"], ["khabs"]], ["baser", ...W]);
  ok(play(m, 0, "shawwah"), "play");
  assert(legalReactions(m, 1).length === 0, "no sawbna option");
});
scenario("تجمل: success takes one copy, failure takes nothing", () => {
  const m = table([["tajammal", "tajammal"], ["batran", "batran", "khabs"], ["khabs"]], ["baser", "shima", ...W], { debt: 2, underAttack: true });
  ok(play(m, 0, "tajammal", { target: 1, named: "batran" }), "ask"); const r = close(m);
  assert(r.events.find((e) => e.type === "resolve").success && m.players[1].hand.length === 2, "took one batran");
  ok(play(m, 0, "tajammal", { target: 1, named: "kafkha" }), "ask 2"); const r2 = close(m);
  assert(!r2.events.find((e) => e.type === "resolve").success && m.players[1].hand.length === 2, "failed request");
});
scenario("مبرطم retrieves a chosen discard card (not وافقري)", () => {
  const m = table([["mbartam"], ["khabs"], ["khabs"]], ["baser", ...W], { discard: ["wafqari", "kafkha", "habsh"] });
  ok(play(m, 0, "mbartam"), "play"); ok(close(m), "close");
  assert(m.prompt?.kind === "retrieve" && m.prompt.options.every((c) => m.cards[c] !== "wafqari") && m.prompt.options.length === 2, "options exclude wafqari");
  const pickId = m.prompt.options.find((c) => m.cards[c] === "kafkha");
  ok(applyCommand(m, { kind: "retrieve", player: 0, cardId: pickId }), "retrieve");
  assert(m.players[0].hand.includes(pickId), "in hand");
});
scenario("مبرطم unplayable with nothing eligible", () => {
  const m = table([["mbartam"], ["khabs"], ["khabs"]], ["baser", ...W], { discard: ["wafqari"] });
  assert(legalPlays(m, 0).length === 0, "not playable");
});
scenario("نفس النمونة copies the last eligible action", () => {
  const m = table([["shawwah", "nafs"], ["khabs"], ["khabs"]], ["baser", "shima", ...W], { debt: 2, underAttack: true });
  ok(play(m, 0, "shawwah"), "shawwah"); ok(close(m), "close");
  assert(m.direction === -1, "reversed once");
  ok(play(m, 0, "nafs"), "copy"); ok(close(m), "close");
  assert(m.direction === 1 && m.lastCopyable === "shawwah", "reversed again via copy, nafs never copyable");
});
scenario("نفس النمونة unplayable with nothing to copy", () => {
  const m = table([["nafs"], ["khabs"], ["khabs"]], ["baser", ...W]);
  assert(legalPlays(m, 0).length === 0, "not playable");
});
scenario("الشيمة draws the second card; وافقري there resolves normally", () => {
  const m = table([["shima", "batran"], ["khabs"], ["khabs"]], ["baser", "wafqari", "wafqari"]);
  const top = m.deck[0];
  ok(play(m, 0, "shima"), "play"); ok(close(m), "close");
  assert(m.phase === PHASE.DEFUSE_SELECTION && m.deck[0] === top, "top untouched, wafqari defused");
  ok(applyCommand(m, { kind: "reinsert", player: 0, position: 0 }), "reinsert");
  checkIntegrity(m);
});
scenario("الشيمة with one card left draws it", () => {
  const m = table([["shima"], ["khabs"]], ["wafqari"]);
  ok(play(m, 0, "shima"), "play"); const r = close(m);
  assert(r.events.some((e) => e.type === "win" && e.player === 1), "p0 eliminated, p1 wins");
});
scenario("Winner detection with 6 players", () => {
  const m = table([["khabs"], ["khabs"], ["khabs"], ["khabs"], ["khabs"], ["khabs"]], ["wafqari", "wafqari", "wafqari", "wafqari", "wafqari"]);
  for (let i = 0; i < 5; i++) ok(applyCommand(m, { kind: "draw", player: m.turn }), `draw ${i}`);
  assert(m.phase === PHASE.GAME_OVER && m.winner === 5 && m.eliminated.length === 5, "last survivor wins");
});
scenario("Out-of-turn and invalid commands rejected", () => {
  const m = table([["khabs"], ["khabs"], ["khabs"]], ["baser", ...W]);
  assert(!applyCommand(m, { kind: "draw", player: 1 }).ok, "wrong player draw");
  assert(!applyCommand(m, { kind: "play", player: 0, cardId: "nope" }).ok, "fake card");
  assert(!applyCommand(m, { kind: "give", player: 0, cardId: m.players[0].hand[0] }).ok, "no prompt");
  ok(applyCommand(m, { kind: "draw", player: 0, cid: "x1" }), "draw");
  assert(applyCommand(m, { kind: "draw", player: 1, cid: "x1" }).error === "duplicate", "duplicate id");
});

console.log(`\n${failures === 0 ? "ALL TESTS PASSED" : `${failures} FAILURE(S)`}`);
console.log(`card types: ${Object.keys(CARD_INFO).length} (17 playable incl. Batran/Wafqari)`);
process.exit(failures ? 1 : 0);
