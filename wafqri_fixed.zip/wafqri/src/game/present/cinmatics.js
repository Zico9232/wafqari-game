// One cinematic per rules event. A cinematic only decorates: the card
// positions come from the event's snapshot (ctx.applySnap), which the
// presenter applies at the latest when the cinematic ends — so skipping or
// interrupting never leaves the table wrong.

import * as THREE from "three";
import { CARD_INFO } from "../rules/cards.js";

const clamp01 = (x) => Math.max(0, Math.min(1, x));
export const seg = (t, a, b) => clamp01((t - a) / (b - a));
const outBack = (k) => { const c = 1.9; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); };
const inOut = (k) => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2);
const hop = (k, h) => Math.sin(k * Math.PI) * h;

export const LINES = {
  kafkha: "خذها عاد!",
  habsh: "هبشتك!",
  hajaa: "هيه وقف!",
  batran: "سلمت هالمرة!",
  wafqari: "وااافقري!",
  khabs: "خبّصتها!",
  baser: "شوفوا يا جماعة!",
  ayyar: "خلني أشوف…",
  tajammal: "تجمّل علي!",
  saqib: "ساقب!",
  salakhni: "سلخني!",
  salifni: "سلّفني!",
  shawwah: "شوح!",
  sawbna: "صوبنا!",
  mbartam: "وين راحت؟",
  nafs: "نفس النمونة!",
  shima: "أبي الثانية!",
};

const V = (x, y, z) => new THREE.Vector3(x, y, z);

// Spot on the felt in front of a player where characters land.
function landing(ctx, id) {
  const s = ctx.table.seatWorld(id).clone();
  const inward = s.clone().setY(0).multiplyScalar(0.72);
  if (id === ctx.table.viewer) return V(0, 0, 2.4);
  return V(inward.x, 0, inward.z);
}

function stageLeft(ctx) {
  const s = ctx.table.stackPos();
  return V(s.x - 1.35, 0.05, s.z + 0.15);
}

function stageRight(ctx, i = 0) {
  const s = ctx.table.stackPos();
  return V(s.x + 1.55 + i * 0.55, 0.05, s.z + 0.1 - i * 0.2);
}

// ---------------------------------------------------------------------------

export function cinematicFor(ev, ctx) {
  switch (ev.type) {
    case "deal": return deal(ev, ctx);
    case "play": return play(ev, ctx);
    case "react": return react(ev, ctx);
    case "resolve": return resolve(ev, ctx);
    case "given": return simple(ctx, 0.6, () => { ctx.audio.play("flick"); ctx.ui.bubbleAtSeat(ev.player, "تفضّل…"); });
    case "retrieved": return simple(ctx, 0.7, () => { ctx.audio.play("pop"); ctx.fx.sparkle(ctx.table.discardPos()); });
    case "reordered": return simple(ctx, 0.3, () => ctx.audio.play("flick"), { snapDeck: true });
    case "draw": return ev.cardType === "wafqari" ? drawWafqari(ev, ctx) : draw(ev, ctx);
    case "defuse": return defuse(ev, ctx);
    case "reinsert": return reinsert(ev, ctx);
    case "eliminate": return eliminate(ev, ctx);
    case "turn": return turn(ev, ctx);
    case "win": return win(ev, ctx);
    default: return simple(ctx, 0, null);
  }
}

function simple(ctx, dur, onStart, snapOpts) {
  return {
    dur,
    start() { ctx.applySnap(snapOpts); onStart?.(); },
    update() {},
  };
}

// --- Deal -------------------------------------------------------------------

function deal(ev, ctx) {
  const total = ev.snap.hands.reduce((n, h) => n + h.length, 0);
  const stagger = ctx.reduced ? 0.02 : 0.055;
  return {
    dur: 0.9 + total * stagger,
    start() {
      ctx.audio.play("shuffle");
      ctx.applySnap({ stagger, duration: 0.42 });
    },
    update(t) {
      const n = Math.floor((t - 0.0) / stagger);
      if (n !== this.last && n >= 0 && n < total && n % 2 === 0) ctx.audio.play("deal");
      this.last = n;
    },
  };
}

// --- Play: card rises, character jumps out of it ------------------------

function play(ev, ctx) {
  const actorType = ev.cardType;
  let actor;
  const from = V(0, 0, 0);
  const to = stageLeft(ctx);
  return {
    dur: 1.25,
    start() {
      ctx.audio.play("flick");
      ctx.applySnap();
      ctx.rig.focusOn(ctx.table.stackPos(), 9);
      if (ev.target !== null && ev.target !== undefined) ctx.ui.markTarget(ev.target);
      actor = ctx.spawn(actorType, ctx.table.stackPos(), { height: 1.55 });
      actor.root.scale.setScalar(0.01);
      ctx.persist.pending = actor;
      ctx.persist.pendingType = ev.cardType;
      from.copy(ctx.table.stackPos());
    },
    update(t) {
      const k = seg(t, 0.35, 0.95);
      actor.root.position.lerpVectors(from, to, inOut(k));
      actor.root.position.y = THREE.MathUtils.lerp(from.y - 0.4, to.y, k) + hop(k, 0.9);
      actor.root.scale.setScalar(Math.max(0.01, outBack(seg(t, 0.3, 0.8))));
      actor.uniforms.uSquash.value = k > 0.95 ? Math.sin(seg(t, 0.95, 1.25) * Math.PI) * -0.12 : 0;
      if (t >= 0.62 && !this.said) {
        this.said = true;
        let line = CARD_INFO[ev.cardType].name;
        if (ev.cardType === "nafs" && ev.copyOf) line = `نفس النمونة ← ${CARD_INFO[ev.copyOf].name}`;
        if (ev.cardType === "tajammal" && ev.named) line = `عندك ${CARD_INFO[ev.named].name}؟`;
        ctx.ui.bubble(actor, line, "card");
        ctx.audio.mumble(1, 3, true);
      }
    },
  };
}

// --- Reactions --------------------------------------------------------------

function react(ev, ctx) {
  const idx = ctx.persist.reacts.length;
  const spot = stageRight(ctx, idx);
  let actor;
  const from = V();
  return {
    dur: 1.5,
    start() {
      ctx.applySnap();
      from.copy(ctx.table.stackPos()).add(V(0.4 + idx * 0.42, 0, 0));
      actor = ctx.spawn(ev.cardType, from, { height: 1.45 });
      actor.root.scale.setScalar(0.01);
      ctx.persist.reacts.push(actor);
      ctx.audio.play(ev.cardType === "hajaa" ? "stamp" : "magic", 0.3);
    },
    update(t) {
      const k = seg(t, 0.1, 0.55);
      actor.root.position.lerpVectors(from, spot, inOut(k));
      actor.root.position.y = THREE.MathUtils.lerp(from.y - 0.3, spot.y, k) + hop(k, 0.7);
      actor.root.scale.setScalar(Math.max(0.01, outBack(seg(t, 0.05, 0.5))));
      if (t > 0.45 && !this.done) {
        this.done = true;
        const pending = ctx.persist.pending;
        ctx.ui.bubble(actor, LINES[ev.cardType], "shout");
        ctx.audio.mumble(1.1, 3, true);
        if (ev.cardType === "hajaa") {
          ctx.ui.stamp(ev.cancelled ? "ملغي!" : "رجعت!", ev.cancelled ? "red" : "green");
          if (pending) {
            pending.frozen = ev.cancelled;
            pending.uniforms.uTint.value.set(ev.cancelled ? "#7fc8ff" : "#ffffff");
            pending.uniforms.uTintAmt.value = ev.cancelled ? 0.5 : 0;
            ctx.fx.emit("soft", { pos: pending.root.position.clone().add(V(0, 0.8, 0)), count: 26, color: ev.cancelled ? "#a8e4ff" : "#ffe08a", speed: 1.6, size: 0.35, life: 0.8 });
          }
        } else {
          const toward = ev.target !== null && ev.target !== undefined ? ev.target : ev.actor;
          ctx.fx.arrow(ctx.table.stackPos(), ctx.table.seatWorld(toward).clone().setY(0.6), "#5ff2ff", 1.6);
          ctx.ui.markTarget(toward);
        }
      }
      // Arm raise: stretch punch.
      actor.uniforms.uSquash.value = Math.sin(seg(t, 0.5, 0.85) * Math.PI) * 0.12;
      if (ev.cardType === "sawbna" && t > 0.5) {
        // Catch: lunge toward the pending character and back.
        const pend = ctx.persist.pending;
        if (pend) {
          const c = seg(t, 0.55, 1.2);
          const lunge = Math.sin(c * Math.PI);
          actor.root.position.lerpVectors(spot, pend.root.position, lunge * 0.55);
        }
      }
    },
  };
}

// --- Resolution: the character performs its action ---------------------

function resolve(ev, ctx) {
  const pending = ctx.persist.pending;
  const eff = ev.effective;
  const actorSpot = stageLeft(ctx);
  let performer = pending;
  let ghost = null;
  const finish = { dur: 0.55 };
  const base = { start: null, dur: 1.2, update: () => {} };

  if (ev.cancelled) {
    return withWrap(ctx, {
      dur: 0.9,
      start() { ctx.audio.play("whoosh"); },
      update(t) {
        if (pending) {
          pending.uniforms.uOpacity.value = 1 - seg(t, 0.1, 0.7);
          pending.root.position.y = actorSpot.y + seg(t, 0.1, 0.7) * 0.6;
        }
        if (t > 0.3 && !this.s) { this.s = true; ctx.applySnap(); }
      },
    }, finish);
  }

  const target = ev.target;
  const targetSpot = target !== null && target !== undefined ? landing(ctx, target) : null;
  const say = (line, who = performer) => { if (who) ctx.ui.bubble(who, line, "shout"); ctx.audio.mumble(1, 3, true); };

  const spec = { ...base };
  const go = (k, a, b, h = 0.8) => {
    if (!performer) return;
    performer.root.position.lerpVectors(a, b, inOut(k));
    performer.root.position.y = THREE.MathUtils.lerp(a.y, b.y, k) + hop(k, h);
  };

  switch (eff) {
    case "kafkha":
      spec.dur = 1.7;
      spec.start = () => { ctx.audio.play("attack"); };
      spec.update = function (t) {
        go(seg(t, 0, 0.55), actorSpot, targetSpot, 1.4);
        if (t > 0.55 && !this.hit) {
          this.hit = true;
          const at = targetSpot.clone().add(V(0, 0.9, 0));
          ctx.fx.impact(at, "#ffdd55");
          ctx.audio.play("slap");
          ctx.ui.flash("rgba(255,40,30,0.35)");
          ctx.rig.shake(0.18, 0.35);
          ctx.ui.floatAtSeat(target, `×${ev.debt}`, "debt");
          say(LINES.kafkha);
          ctx.view.haptic?.(40);
        }
        if (performer) performer.uniforms.uSquash.value = t > 0.5 && t < 0.75 ? Math.sin(seg(t, 0.5, 0.75) * Math.PI) * 0.22 : 0;
        if (performer) performer.root.rotation.z = t > 0.5 && t < 0.75 ? Math.sin(seg(t, 0.5, 0.75) * Math.PI) * 0.4 : 0;
        if (t > 1.0) go(seg(t, 1.0, 1.5), targetSpot, actorSpot, 0.7);
        if (t > 1.0 && !this.s) { this.s = true; ctx.applySnap(); }
      };
      break;
    case "habsh":
      spec.dur = 1.6;
      spec.update = function (t) {
        // Tiptoe: several small hops.
        const k = seg(t, 0, 0.7);
        if (performer && t <= 0.7) {
          performer.root.position.lerpVectors(actorSpot, targetSpot, k);
          performer.root.position.y = Math.abs(Math.sin(k * Math.PI * 4)) * 0.25;
        }
        if (t > 0.75 && !this.s) {
          this.s = true;
          ctx.applySnap();
          ctx.audio.play("steal");
          say(LINES.habsh);
          ctx.fx.sparkle(targetSpot.clone().add(V(0, 0.5, 0)), "#ffe28a", 14);
        }
        if (t > 0.9) go(seg(t, 0.9, 1.25), targetSpot, actorSpot, 0.3);
      };
      break;
    case "saqib":
      spec.dur = 1.5;
      spec.start = () => { ctx.audio.play("magic"); say(LINES.saqib); };
      spec.update = function (t) {
        if (performer) performer.root.rotation.y = seg(t, 0, 0.6) * Math.PI * 4;
        if (t > 0.2 && !this.sp) { this.sp = true; ctx.fx.sparkle(actorSpot.clone().add(V(0, 1, 0)), "#c69bff", 30); }
        if (t > 0.6 && !this.s) {
          this.s = true;
          ctx.applySnap({ duration: 0.7 });
          ctx.fx.sparkle(ctx.table.seatWorld(ev.actor), "#c69bff", 16);
          if (target !== null) ctx.fx.sparkle(ctx.table.seatWorld(target), "#c69bff", 16);
        }
      };
      break;
    case "salifni":
      spec.dur = 1.1;
      spec.start = () => say(LINES.salifni);
      spec.update = function (t) {
        go(seg(t, 0, 0.6), actorSpot, actorSpot.clone().lerp(targetSpot, 0.6), 0.4);
        if (performer) performer.uniforms.uSquash.value = Math.sin(seg(t, 0.6, 1.0) * Math.PI) * 0.08;
        if (t > 0.8 && !this.s) { this.s = true; ctx.applySnap(); }
      };
      break;
    case "khabs": {
      const deck = ctx.table.deckPos().setY(0.1);
      spec.dur = 1.5;
      spec.update = function (t) {
        go(seg(t, 0, 0.4), actorSpot, deck, 1.0);
        if (t > 0.4 && t < 1.2) {
          if (!this.sh) { this.sh = true; ctx.audio.play("shuffle"); say(LINES.khabs); }
          for (const cid of ctx.table.allDeckCards()) ctx.table.shake(cid, 0.09);
          if (performer) performer.root.rotation.y = Math.sin(t * 40) * 0.3;
        }
        if (t > 1.2) { if (performer) performer.root.rotation.y = 0; go(seg(t, 1.2, 1.5), deck, actorSpot, 0.5); }
        if (t > 1.2 && !this.s) { this.s = true; ctx.applySnap({ snapDeck: true }); }
      };
      break;
    }
    case "baser":
    case "ayyar": {
      const cards = eff === "baser" ? ev.revealed || [] : ev.seen || [];
      const faceUp = eff === "baser" || ev.private === ctx.viewer();
      spec.dur = eff === "baser" ? 2.8 : 1.8;
      spec.start = () => {
        ctx.audio.play("reveal");
        say(eff === "baser" ? LINES.baser : LINES.ayyar);
        const cam = ctx.view.camera;
        cards.forEach((cid, i) => {
          const pos = ctx.table.deckPos().clone().add(V(-0.95 + i * 0.95 - 0.6, 1.9 + (i === 1 ? 0.12 : 0), 0.7));
          const quat = cam.quaternion.clone();
          if (!faceUp) quat.multiply(new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), Math.PI));
          ctx.table.setOverride(cid, { pos, quat, scale: 0.85, faceUp });
        });
        ctx.rig.focusOn(ctx.table.deckPos().clone().add(V(-0.6, 1.6, 0.6)), 6);
      };
      spec.update = function (t) {
        if (performer) performer.uniforms.uSquash.value = Math.sin(t * 6) * 0.04;
        if (t > spec.dur - 0.5 && !this.c) {
          this.c = true;
          cards.forEach((cid) => ctx.table.setOverride(cid, null));
          ctx.applySnap();
        }
      };
      spec.end = () => cards.forEach((cid) => ctx.table.setOverride(cid, null));
      break;
    }
    case "tajammal":
      spec.dur = 1.7;
      spec.update = function (t) {
        go(seg(t, 0, 0.6), actorSpot, actorSpot.clone().lerp(targetSpot, 0.7), 0.6);
        if (t > 0.8 && !this.r) {
          this.r = true;
          if (ev.success) {
            ctx.applySnap();
            ctx.audio.play("steal");
            ctx.fx.sparkle(targetSpot.clone().add(V(0, 0.5, 0)), "#9dff6a", 20);
            say("✓ تمّت!");
          } else {
            ctx.audio.play("error");
            ctx.ui.bubbleAtSeat(target, "ما عندي!");
            if (performer) performer.uniforms.uSquash.value = -0.08;
          }
        }
        if (t > 1.2) go(seg(t, 1.2, 1.6), actorSpot.clone().lerp(targetSpot, 0.7), actorSpot, 0.4);
      };
      break;
    case "mbartam": {
      const pile = ctx.table.discardPos().setY(0.1);
      spec.dur = 1.3;
      spec.start = () => say(LINES.mbartam);
      spec.update = function (t) {
        go(seg(t, 0, 0.45), actorSpot, pile, 0.9);
        if (performer && t > 0.45) performer.root.rotation.z = Math.sin(t * 30) * 0.12;
        if (t > 0.5 && !this.s) { this.s = true; ctx.applySnap(); ctx.audio.play("flick"); }
      };
      spec.end = () => { if (performer) performer.root.rotation.z = 0; };
      break;
    }
    case "shawwah":
      spec.dur = 1.4;
      spec.start = () => { ctx.audio.play("reverse"); say(LINES.shawwah); };
      spec.update = function (t) {
        if (performer) {
          performer.root.rotation.y = inOut(seg(t, 0, 0.9)) * Math.PI * 6;
          performer.root.position.y = actorSpot.y + hop(seg(t, 0, 0.9), 0.6);
        }
        if (t > 0.45 && !this.s) {
          this.s = true;
          ctx.applySnap();
          ctx.fx.ring(V(0.55, 0.05, 0.45), "#ffd36a", 0.8, 2.6, 0.05);
        }
      };
      break;
    case "salakhni":
      spec.dur = 1.0;
      spec.start = () => { ctx.audio.play("whoosh"); say(LINES.salakhni); };
      spec.update = function (t) {
        if (performer) {
          const k = seg(t, 0.2, 0.8);
          performer.root.position.x = actorSpot.x - k * k * 7;
          performer.root.rotation.z = k * 0.4;
          performer.uniforms.uOpacity.value = 1 - seg(t, 0.5, 0.85);
        }
        if (t > 0.3 && !this.s) { this.s = true; ctx.applySnap(); ctx.fx.emit("smoke", { pos: actorSpot.clone().add(V(0, 0.3, 0)), count: 10, color: "#d8c8b8", size: 0.6, sizeEnd: 1.2, life: 0.7, speed: 0.8 }); }
      };
      break;
    case "shima": {
      const deck = ctx.table.deckPos().setY(0.1);
      spec.dur = 1.0;
      spec.start = () => say(LINES.shima);
      spec.update = function (t) {
        go(seg(t, 0, 0.5), actorSpot, deck, 0.9);
        if (t > 0.6 && !this.s) { this.s = true; ctx.applySnap(); }
      };
      break;
    }
    default:
      spec.dur = 0.8;
      spec.start = () => ctx.fx.sparkle(actorSpot.clone().add(V(0, 1, 0)));
  }

  // نفس النمونة: a ghost copy of the copied card's character performs.
  if (ev.cardType === "nafs" && pending) {
    const inner = spec;
    return withWrap(ctx, {
      dur: inner.dur + 0.5,
      start() {
        ghost = ctx.spawn(eff, actorSpot.clone().add(V(0.5, 0, 0.3)), { height: 1.5 });
        ghost.uniforms.uGhost.value = 1;
        ghost.uniforms.uOpacity.value = 0.85;
        ghost.root.scale.setScalar(0.01);
        ctx.audio.play("magic");
        ctx.fx.sparkle(ghost.root.position.clone().add(V(0, 0.8, 0)), "#7ff0ff", 30);
        ctx.persist.extra.push(ghost);
      },
      update(t, dt) {
        if (t < 0.5) {
          ghost.root.scale.setScalar(Math.max(0.01, outBack(seg(t, 0, 0.45))));
          return;
        }
        if (!this.started) {
          this.started = true;
          performer = ghost;
          actorSpot.copy(ghost.root.position);
          inner.start?.();
        }
        inner.update.call(inner, t - 0.5, dt);
      },
      end() { inner.end?.(); },
    }, finish);
  }
  return withWrap(ctx, spec, finish);
}

// After any resolution: every stage character shrinks back into the cards.
function withWrap(ctx, spec, finish) {
  const total = spec.dur + finish.dur;
  let collected = null;
  return {
    dur: total,
    deferSnap: true,
    start() { spec.start?.call(spec); },
    update(t, dt) {
      if (t <= spec.dur) spec.update.call(spec, t, dt);
      else {
        if (!collected) {
          spec.end?.();
          collected = ctx.stageActors().map((a) => ({ a, from: a.root.position.clone(), s: a.root.scale.x }));
          ctx.applySnap();
          ctx.rig.release();
          ctx.ui.clearMarks();
        }
        const k = seg(t, spec.dur, total);
        const pile = ctx.table.discardPos();
        for (const { a, from, s } of collected) {
          a.root.position.lerpVectors(from, pile, inOut(k));
          a.root.scale.setScalar(Math.max(0.01, s * (1 - k)));
        }
      }
    },
    end() {
      spec.end?.();
      ctx.clearStage();
    },
  };
}

// --- Drawing -------------------------------------------------------------

function draw(ev, ctx) {
  return {
    dur: 0.55,
    start() {
      ctx.applySnap();
      ctx.audio.play("flick");
    },
    update() {},
  };
}

function drawWafqari(ev, ctx) {
  const lift = V(0.4, 2.1, 1.6);
  let actor;
  return {
    dur: 2.3,
    start() {
      ctx.audio.play("alarm");
      ctx.ui.vignette(true);
      ctx.view.alarmOn = true;
      const quat = ctx.view.camera.quaternion.clone();
      ctx.table.setOverride(ev.cardId, { pos: lift, quat, scale: 1.1, faceUp: true });
      ctx.rig.focusOn(lift, 5.2);
      ctx.persist.wafqariCard = ev.cardId;
      ctx.view.haptic?.([30, 40, 30]);
    },
    update(t) {
      if (t > 0.75 && !actor) {
        actor = ctx.spawn("wafqari", lift.clone().add(V(0, -0.9, 0.3)), { height: 2.1 });
        actor.root.scale.setScalar(0.01);
        ctx.persist.wafqari = actor;
        ctx.audio.play("sting");
        ctx.ui.bubble(actor, LINES.wafqari, "danger");
        ctx.audio.mumble(0.8, 4, true);
        ctx.fx.fire(lift.clone().add(V(0, -0.6, 0)), 1);
        ctx.rig.shake(0.08, 0.3);
      }
      if (actor) {
        const k = seg(t, 0.75, 1.3);
        actor.root.scale.setScalar(Math.max(0.01, outBack(k)));
        actor.root.position.y = lift.y - 0.9 + hop(k, 0.5);
        actor.uniforms.uSquash.value = Math.sin(t * 18) * 0.03;
      }
    },
  };
}

function defuse(ev, ctx) {
  const seat = landing(ctx, ev.player);
  let hero;
  return {
    dur: 2.4,
    start() {
      ctx.applySnap();
      hero = ctx.spawn("batran", seat.clone(), { height: 1.7 });
      hero.root.scale.setScalar(0.01);
      ctx.audio.play("shield");
      ctx.fx.shield(seat.clone(), 2.2);
      ctx.ui.bubble(hero, LINES.batran, "hero");
      ctx.audio.mumble(1.2, 3, false);
      ctx.ui.flash("rgba(255,215,90,0.35)");
    },
    update(t) {
      hero.root.scale.setScalar(Math.max(0.01, outBack(seg(t, 0, 0.5))));
      hero.root.position.y = seat.y + hop(seg(t, 0, 0.5), 0.8);
      const w = ctx.persist.wafqari;
      if (w) {
        const k = seg(t, 0.6, 1.4);
        w.root.scale.setScalar(Math.max(0.01, 1 - k));
        w.uniforms.uTint.value.set("#ffd86a");
        w.uniforms.uTintAmt.value = k * 0.6;
      }
      if (t > 1.5 && !this.calm) {
        this.calm = true;
        ctx.ui.vignette(false);
        ctx.view.alarmOn = false;
        if (ctx.persist.wafqariCard) ctx.table.setOverride(ctx.persist.wafqariCard, null);
        ctx.rig.release();
      }
      if (t > 1.8) hero.root.scale.setScalar(Math.max(0.01, 1 - seg(t, 1.8, 2.4)));
    },
    end() {
      ctx.ui.vignette(false);
      ctx.view.alarmOn = false;
      if (ctx.persist.wafqariCard) ctx.table.setOverride(ctx.persist.wafqariCard, null);
      ctx.clearStage();
    },
  };
}

// The وافقري card goes back face-down. It always flies to the top of the
// pile; the deck then re-sorts instantly so nobody can see the real slot.
function reinsert(ev, ctx) {
  return {
    dur: 0.7,
    start() {
      const top = ctx.table.deckPos().clone().setY(0.6);
      const quat = new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.PI / 2, 0, 0));
      ctx.table.setOverride(ev.cardId, { pos: top, quat, scale: 0.66, faceUp: false });
      ctx.applySnap({ snapDeck: true });
      ctx.audio.play("flick");
    },
    update(t) {
      if (t > 0.55 && !this.d) {
        this.d = true;
        ctx.table.setOverride(ev.cardId, null);
        ctx.applySnap({ snapDeck: true, teleport: [ev.cardId] });
      }
    },
    end() {
      ctx.table.setOverride(ev.cardId, null);
    },
  };
}

function eliminate(ev, ctx) {
  const seat = landing(ctx, ev.player);
  return {
    dur: 2.6,
    start() {
      const w = ctx.persist.wafqari;
      this.w = w;
      this.from = w ? w.root.position.clone() : seat.clone().add(V(0, 2, 0));
      ctx.rig.focusOn(seat.clone().add(V(0, 0.6, 0)), 6);
    },
    update(t) {
      const w = this.w;
      if (w) {
        const k = seg(t, 0, 0.45);
        w.root.position.lerpVectors(this.from, seat, inOut(k));
        w.root.position.y = THREE.MathUtils.lerp(this.from.y, seat.y, k) + hop(k, 1.2);
        if (t > 0.5) w.root.scale.setScalar(Math.max(0.01, 1 - seg(t, 0.5, 0.65)));
      }
      if (t > 0.5 && !this.boom) {
        this.boom = true;
        if (ctx.persist.wafqariCard) ctx.table.setOverride(ctx.persist.wafqariCard, null);
        ctx.applySnap({ duration: 0.8 });
        ctx.fx.explosion(seat.clone().add(V(0, 0.4, 0)));
        ctx.fx.fire(seat.clone(), 1.5);
        ctx.audio.play("explosion");
        ctx.rig.shake(0.55, 0.8);
        ctx.ui.flash("rgba(255,120,30,0.6)");
        ctx.ui.bubbleAtSeat(ev.player, LINES.wafqari, "danger");
        ctx.view.haptic?.([80, 40, 120]);
      }
      if (t > 1.6 && !this.sad) { this.sad = true; ctx.audio.play("defeat"); }
    },
    end() {
      ctx.ui.vignette(false);
      ctx.view.alarmOn = false;
      ctx.rig.release();
      if (ctx.persist.wafqariCard) ctx.table.setOverride(ctx.persist.wafqariCard, null);
      ctx.clearStage();
    },
  };
}

function turn(ev, ctx) {
  return {
    dur: ev.continued ? 0.25 : 0.55,
    start() {
      ctx.applySnap();
      ctx.table.setTurn(ev.player);
      ctx.ui.announceTurn(ev);
    },
    update() {},
  };
}

function win(ev, ctx) {
  let dancer;
  return {
    dur: 3.4,
    start() {
      ctx.applySnap();
      ctx.audio.play("fanfare");
      const type = ctx.avatarType(ev.player);
      dancer = ctx.spawn(type, V(0.5, 0.05, 0.6), { height: 2.2 });
      ctx.rig.focusOn(V(0.5, 1.2, 0.6), 7);
      ctx.fx.confetti(V(0.5, 0, 0.5), 160);
    },
    update(t) {
      dancer.root.position.y = 0.05 + Math.abs(Math.sin(t * 5)) * 0.5;
      dancer.root.rotation.y = Math.sin(t * 2.5) * 0.6;
      dancer.uniforms.uSquash.value = Math.sin(t * 10) * 0.06;
      const n = Math.floor(t / 0.7);
      if (n !== this.n) { this.n = n; ctx.fx.fireworks(V(0.5, 0, -1)); ctx.audio.play("pop"); }
    },
  };
}
