// Plays rules events back as cinematics, one after another. The rules have
// already happened; this only shows them. Tapping speeds the current
// cinematic up, and any cinematic has a hard time cap, so the presentation
// can never hold the game hostage.

import * as THREE from "three";
import { cinematicFor } from "./cinematics.js";
import { createCharacter } from "../view/character.js";

const MAX_CINEMATIC = 6; // seconds, hard cap

export function createPresenter({ view, table, fx, audio, ui, rig, textures, getViewer, avatarType, settings }) {
  const queue = [];
  let current = null;
  let boost = 1;
  const stage = []; // characters on stage for the current play
  const persist = { pending: null, reacts: [], wafqari: null, wafqariCard: null, extra: [] };
  let idleHand = null; // character standing on the selected hand card
  let idleDiscard = null; // character living on the discard pile
  let idleDiscardType = null;

  const ctx = {
    view, table, fx, audio, ui, rig, textures, persist,
    get reduced() { return settings().reducedMotion; },
    viewer: () => getViewer(),
    avatarType,
    snapOpts: null,
    applySnap(opts) {
      if (!current || current.snapApplied) return;
      current.snapApplied = true;
      table.applySnapshot(current.event.snap, { ...(opts || {}), ...(current.snapExtra || {}) });
    },
    spawn(type, pos, opts) {
      const a = createCharacter(textures, type, opts);
      a.root.position.copy(pos);
      view.scene.add(a.root);
      stage.push(a);
      return a;
    },
    stageActors: () => stage.slice(),
    clearStage() {
      for (const a of stage) a.dispose();
      stage.length = 0;
      persist.pending = null;
      persist.reacts = [];
      persist.wafqari = null;
      persist.extra = [];
    },
  };

  function push(events) {
    for (const e of events) if (e.snap) queue.push(e);
  }

  function startNext() {
    const event = queue.shift();
    if (!event) return;
    const cin = cinematicFor(event, ctx);
    current = { event, cin, t: 0, snapApplied: false };
    try {
      cin.start?.call(cin);
    } catch (e) {
      console.warn("[presenter] cinematic start failed", e);
    }
  }

  function finishCurrent() {
    if (!current) return;
    try {
      current.cin.end?.call(current.cin);
    } catch (e) {
      console.warn("[presenter] cinematic end failed", e);
    }
    // Whatever happened, the table settles on the event's state.
    if (!current.snapApplied) table.applySnapshot(current.event.snap);
    current = null;
  }

  function update(dt) {
    const s = settings();
    const speed = (s.cinematicSpeed || 1) * boost * (s.reducedMotion ? 1.6 : 1);
    let budget = dt * speed;
    // Process instant events in the same frame.
    for (let guard = 0; guard < 40; guard++) {
      if (!current) {
        if (!queue.length) { boost = 1; break; }
        startNext();
      }
      const c = current;
      const dur = Math.min(c.cin.dur, MAX_CINEMATIC);
      const step = Math.min(budget, Math.max(0, dur - c.t));
      c.t += step;
      budget -= step;
      try {
        c.cin.update.call(c.cin, c.t, step);
      } catch (e) {
        console.warn("[presenter] cinematic failed", e);
        c.t = dur;
      }
      if (c.t >= dur) {
        finishCurrent();
        if (!queue.length) boost = 1;
        continue;
      }
      if (budget <= 1e-6) break;
    }
    for (const a of stage) a.update(dt, view.camera);
    updateIdle(dt);
  }

  // --- Idle life: selected hand card + discard pile character -----------

  function updateIdle(dt) {
    const sel = table.selected;
    const selType = sel ? ctx.cardType(sel) : null;
    if (!sel || !selType) {
      if (idleHand) { idleHand.dispose(); idleHand = null; }
    } else {
      if (!idleHand || idleHand.cid !== sel) {
        idleHand?.dispose();
        idleHand = createCharacter(textures, selType, { height: 1 });
        idleHand.cid = sel;
        idleHand.root.scale.setScalar(0.01);
        idleHand.appear = 0;
        view.scene.add(idleHand.root);
        audio.mumble(1.3, 2, false);
      }
      const mesh = table.cardMesh(sel);
      if (mesh) {
        idleHand.appear = Math.min(1, idleHand.appear + dt * 4);
        const k = idleHand.appear;
        const up = new THREE.Vector3(0, 1, 0).applyQuaternion(view.camera.quaternion);
        const s = mesh.scale.x;
        idleHand.root.position.copy(mesh.position).addScaledVector(up, s * 0.55);
        const back = new THREE.Vector3(0, 0, -1).applyQuaternion(view.camera.quaternion);
        idleHand.root.position.addScaledVector(back, 0.05);
        idleHand.root.quaternion.copy(view.camera.quaternion);
        idleHand.root.scale.setScalar(Math.max(0.01, s * 0.62 * (k < 1 ? 1.1 * Math.sin(k * Math.PI * 0.6) / Math.sin(Math.PI * 0.6) : 1)));
        idleHand.billboard = false;
        idleHand.mesh.rotation.set(0, 0, 0);
        idleHand.update(dt, null);
      }
    }
    // Discard pile resident: the last played character (not during a play).
    const snap = table.snapshot;
    const top = snap?.discard?.length ? ctx.cardType(snap.discard[snap.discard.length - 1]) : null;
    const want = !current && stage.length === 0 && top && top !== "wafqari" ? top : null;
    if (want !== idleDiscardType) {
      idleDiscard?.dispose();
      idleDiscard = null;
      idleDiscardType = want;
      if (want) {
        idleDiscard = createCharacter(textures, want, { height: 0.85 });
        idleDiscard.root.position.copy(table.discardPos()).setY(0.32);
        idleDiscard.root.position.z -= 0.25;
        idleDiscard.root.scale.setScalar(0.01);
        idleDiscard.appear = 0;
        view.scene.add(idleDiscard.root);
      }
    }
    if (idleDiscard) {
      idleDiscard.appear = Math.min(1, idleDiscard.appear + dt * 3);
      idleDiscard.root.scale.setScalar(Math.max(0.01, idleDiscard.appear));
      idleDiscard.update(dt, view.camera);
    }
  }

  return {
    push,
    update,
    get idle() { return !current && queue.length === 0; },
    get busy() { return Boolean(current) || queue.length > 0; },
    get pendingCount() { return queue.length + (current ? 1 : 0); },
    skip() { if (current || queue.length) boost = 4; },
    // Drop everything (new match / quit): settle immediately.
    reset() {
      queue.length = 0;
      if (current) current = null;
      ctx.clearStage();
      idleHand?.dispose(); idleHand = null;
      idleDiscard?.dispose(); idleDiscard = null; idleDiscardType = null;
      boost = 1;
    },
    setCardTypes(fn) { ctx.cardType = fn; },
    currentEvent: () => current?.event || null,
  };
}
