// WAFQARI rules engine: a deterministic state machine over plain JSON.
//
// Graphics never touch this file. Every change to a match goes through
// applyCommand(match, command), which validates the command, mutates the
// match, and returns the events that happened, in order. The presentation
// layer replays those events; the rules never wait for an animation.
//
// Phases: DEALING → PLAYER_TURN → (REACTION_WINDOW → RESOLVING)
//         → PRIVATE_SELECTION | DEFUSE_SELECTION → TURN_COMPLETE → … → GAME_OVER
// (LOBBY and TARGET_SELECTION live in the UI: the lobby builds the config,
// and target selection happens before a play command is sent.)

import {
  CARD_INFO, NOT_ACTION, NOT_COPYABLE, NOT_RETRIEVABLE, SAWBNA_OK, UNREACTABLE, regularCounts,
} from "./cards.js";
import { randInt, shuffleInPlace } from "./rng.js";

export const PHASE = {
  DEALING: "DEALING",
  PLAYER_TURN: "PLAYER_TURN",
  REACTION_WINDOW: "REACTION_WINDOW",
  RESOLVING: "RESOLVING",
  PRIVATE_SELECTION: "PRIVATE_SELECTION",
  DEFUSE_SELECTION: "DEFUSE_SELECTION",
  TURN_COMPLETE: "TURN_COMPLETE",
  GAME_OVER: "GAME_OVER",
};

const MAX_SEEN_COMMANDS = 64;

// ---------------------------------------------------------------------------
// Setup

export function createMatch({ players, seed = 1, snapshots = false }) {
  if (!Array.isArray(players) || players.length < 2 || players.length > 6) {
    throw new Error("WAFQARI needs 2–6 players");
  }
  const match = {
    version: 1,
    rng: seed | 0,
    phase: PHASE.DEALING,
    players: players.map((p, i) => ({
      id: i,
      name: p.name,
      avatar: p.avatar,
      isAI: Boolean(p.isAI),
      difficulty: p.difficulty || "medium",
      alive: true,
      hand: [],
      stats: { played: 0, drawn: 0, survived: 0, kafkhaLanded: 0, turns: 0 },
    })),
    cards: {},
    deck: [],
    discard: [],
    stack: [],
    turn: 0,
    direction: 1,
    debt: 1,
    underAttack: false,
    pending: null,
    reaction: null,
    prompt: null,
    lastCopyable: null,
    winner: null,
    eliminated: [],
    turnCount: 0,
    actionCount: 0,
    seenCommands: [],
    snapshots,
    events: null,
  };
  return match;
}

// Deals the opening hands. Returns the deal events. Separate from
// createMatch so the presenter can animate the deal from an empty table.
export function dealMatch(match) {
  const events = (match.events = []);
  const n = match.players.length;
  let next = 1;
  const make = (type) => {
    const id = `c${next++}`;
    match.cards[id] = type;
    return id;
  };
  const regular = [];
  const counts = regularCounts(n);
  for (const [type, count] of Object.entries(counts)) {
    for (let i = 0; i < count; i++) regular.push(make(type));
  }
  shuffleInPlace(match, regular);
  // 1. One البطران each. 2. Five regular cards each.
  for (const p of match.players) p.hand.push(make("batran"));
  for (let round = 0; round < 5; round++) {
    for (const p of match.players) p.hand.push(regular.pop());
  }
  // 3. Remaining regular cards, 4. plus (players − 1) وافقري, 5. shuffled.
  match.deck = regular;
  for (let i = 0; i < n - 1; i++) match.deck.push(make("wafqari"));
  shuffleInPlace(match, match.deck);
  match.turn = randInt(match, n);
  match.phase = PHASE.PLAYER_TURN;
  match.debt = 1;
  emit(match, { type: "deal" });
  startTurnStats(match);
  emit(match, { type: "turn", player: match.turn, debt: match.debt });
  match.events = null;
  return events;
}

// ---------------------------------------------------------------------------
// Queries (used by UI, AI and validation)

export const typeOf = (match, cardId) => match.cards[cardId];
export const alivePlayers = (match) => match.players.filter((p) => p.alive);
export const countType = (match, list, type) => list.filter((c) => match.cards[c] === type).length;
export const wafqariInDeck = (match) => countType(match, match.deck, "wafqari");

export function nextAlive(match, from, direction = match.direction) {
  const n = match.players.length;
  let i = from;
  for (let step = 0; step < n; step++) {
    i = (i + direction + n) % n;
    if (match.players[i].alive) return i;
  }
  return from;
}

// The type a pending play will actually resolve as (نفس النمونة copies).
export const effectiveType = (pending) => (pending.type === "nafs" ? pending.copyOf : pending.type);

function needsTargetType(type) {
  return Boolean(CARD_INFO[type]?.target);
}

export function validTargets(match, player, type) {
  const info = CARD_INFO[type];
  if (!info?.target) return [];
  return match.players
    .filter((p) => p.alive && p.id !== player && (!info.targetNeedsCards || p.hand.length > 0))
    .map((p) => p.id);
}

export function retrievableCards(match) {
  return match.discard.filter((c) => !NOT_RETRIEVABLE.has(match.cards[c]));
}

// Is a kafkha by this player a stacking kafkha (auto-targets next player)?
export function isStackingKafkha(match, player) {
  return match.underAttack && match.turn === player;
}

// Every card the player may legally play right now, with its targets.
export function legalPlays(match, player) {
  if (match.phase !== PHASE.PLAYER_TURN || match.turn !== player) return [];
  const p = match.players[player];
  if (!p?.alive) return [];
  const out = [];
  for (const cardId of p.hand) {
    const type = match.cards[cardId];
    if (NOT_ACTION.has(type)) continue;
    let effective = type;
    if (type === "nafs") {
      if (!match.lastCopyable) continue;
      effective = match.lastCopyable;
    }
    if (effective === "mbartam" && retrievableCards(match).length === 0) continue;
    let targets = [];
    let autoTarget = null;
    if (effective === "kafkha" && isStackingKafkha(match, player)) {
      autoTarget = nextAlive(match, player);
    } else if (needsTargetType(effective)) {
      targets = validTargets(match, player, effective);
      if (targets.length === 0) continue;
    }
    out.push({ cardId, type, effective, targets, autoTarget });
  }
  return out;
}

// Players who may still react to the current pending play.
export function eligibleReactors(match) {
  if (match.phase !== PHASE.REACTION_WINDOW || !match.pending) return [];
  const last = lastChainPlayer(match.pending);
  return match.players.filter((p) => p.alive && p.id !== last).map((p) => p.id);
}

function lastChainPlayer(pending) {
  return pending.chain.length ? pending.chain[pending.chain.length - 1].player : pending.actor;
}

// What reaction cards this player could play now, with the targets a صوبنا
// would need.
export function legalReactions(match, player) {
  if (!eligibleReactors(match).includes(player)) return [];
  const p = match.players[player];
  const pending = match.pending;
  const eff = effectiveType(pending);
  const out = [];
  for (const cardId of p.hand) {
    const type = match.cards[cardId];
    if (type === "hajaa" && !UNREACTABLE.has(eff)) out.push({ cardId, type, targets: [] });
    if (type === "sawbna" && !pending.cancelled && SAWBNA_OK.has(pending.type) && SAWBNA_OK.has(eff)) {
      let targets = [];
      if (needsTargetType(eff)) {
        targets = validTargets(match, player, eff);
        if (targets.length === 0) continue;
      }
      out.push({ cardId, type, targets });
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// Commands

export function applyCommand(match, command) {
  match.events = [];
  const fail = (error) => {
    match.events = null;
    return { ok: false, error, events: [] };
  };
  if (!command || typeof command !== "object") return fail("bad-command");
  if (command.cid) {
    if (match.seenCommands.includes(command.cid)) return fail("duplicate");
  }
  if (match.phase === PHASE.GAME_OVER) return fail("game-over");
  let error = null;
  switch (command.kind) {
    case "play": error = cmdPlay(match, command); break;
    case "draw": error = cmdDraw(match, command); break;
    case "react": error = cmdReact(match, command); break;
    case "pass": error = cmdPass(match, command); break;
    case "closeReactions": error = cmdClose(match); break;
    case "give": error = cmdGive(match, command); break;
    case "reorder": error = cmdReorder(match, command); break;
    case "reinsert": error = cmdReinsert(match, command); break;
    case "retrieve": error = cmdRetrieve(match, command); break;
    default: error = "unknown-command";
  }
  if (error) return fail(error);
  if (command.cid) {
    match.seenCommands.push(command.cid);
    if (match.seenCommands.length > MAX_SEEN_COMMANDS) match.seenCommands.shift();
  }
  const events = match.events;
  match.events = null;
  return { ok: true, events };
}

function cmdPlay(match, { player, cardId, target, named }) {
  if (match.phase !== PHASE.PLAYER_TURN) return "not-your-phase";
  if (match.turn !== player) return "not-your-turn";
  const legal = legalPlays(match, player).find((l) => l.cardId === cardId);
  if (!legal) return "illegal-card";
  const eff = legal.effective;
  let finalTarget = null;
  if (legal.autoTarget !== null) finalTarget = legal.autoTarget;
  else if (needsTargetType(eff)) {
    if (!legal.targets.includes(target)) return "bad-target";
    finalTarget = target;
  }
  if (eff === "tajammal") {
    if (!CARD_INFO[named] || named === "wafqari") return "bad-name";
  }
  const p = match.players[player];
  removeFrom(p.hand, cardId);
  match.stack.push(cardId);
  p.stats.played++;
  match.pending = {
    cardId,
    type: legal.type,
    copyOf: legal.type === "nafs" ? match.lastCopyable : null,
    actor: player,
    turnPlayer: player,
    target: finalTarget,
    named: eff === "tajammal" ? named : null,
    debtAtPlay: match.debt,
    stacking: legal.autoTarget !== null,
    cancelled: false,
    chain: [],
  };
  emit(match, {
    type: "play", player, cardId, cardType: legal.type, copyOf: match.pending.copyOf,
    target: finalTarget, named: match.pending.named,
  });
  openReactionWindow(match);
  return null;
}

function openReactionWindow(match) {
  match.phase = PHASE.REACTION_WINDOW;
  match.reaction = { passes: [], round: (match.reaction?.round || 0) + 1 };
  emit(match, { type: "reactionWindow", eligible: eligibleReactors(match) });
}

function cmdReact(match, { player, cardId, target, chainLen }) {
  if (match.phase !== PHASE.REACTION_WINDOW) return "no-window";
  // Simultaneous reactions: a reaction aimed at an older chain loses.
  if (typeof chainLen === "number" && chainLen !== match.pending.chain.length) return "stale-reaction";
  const legal = legalReactions(match, player).find((r) => r.cardId === cardId);
  if (!legal) return "illegal-reaction";
  const pending = match.pending;
  if (legal.type === "sawbna" && legal.targets.length && !legal.targets.includes(target)) return "bad-target";
  const p = match.players[player];
  removeFrom(p.hand, cardId);
  match.stack.push(cardId);
  p.stats.played++;
  const link = { player, cardId, type: legal.type };
  if (legal.type === "hajaa") {
    pending.cancelled = !pending.cancelled;
  } else {
    // صوبنا: the reactor becomes the actor and picks the new target.
    link.from = pending.actor;
    pending.actor = player;
    pending.target = legal.targets.length ? target : null;
    pending.stacking = false;
  }
  pending.chain.push(link);
  emit(match, {
    type: "react", player, cardId, cardType: legal.type, cancelled: pending.cancelled,
    actor: pending.actor, target: pending.target, pendingType: effectiveType(pending),
  });
  openReactionWindow(match);
  return null;
}

function cmdPass(match, { player }) {
  if (match.phase !== PHASE.REACTION_WINDOW) return "no-window";
  if (!eligibleReactors(match).includes(player)) return "not-eligible";
  if (!match.reaction.passes.includes(player)) match.reaction.passes.push(player);
  const all = eligibleReactors(match).every((id) => match.reaction.passes.includes(id));
  if (all) resolvePending(match);
  return null;
}

function cmdClose(match) {
  if (match.phase !== PHASE.REACTION_WINDOW) return "no-window";
  resolvePending(match);
  return null;
}

// ---------------------------------------------------------------------------
// Resolution

function resolvePending(match) {
  match.phase = PHASE.RESOLVING;
  match.reaction = null;
  const pending = match.pending;
  const eff = effectiveType(pending);
  // Played card and every reaction card go to the discard pile.
  const stackCards = match.stack.splice(0);
  match.discard.push(...stackCards);
  if (pending.cancelled) {
    emit(match, { type: "resolve", cardType: pending.type, effective: eff, actor: pending.actor, cancelled: true });
    match.pending = null;
    finishAction(match);
    return;
  }
  if (!NOT_COPYABLE.has(eff)) match.lastCopyable = eff;
  runEffect(match, pending, eff, stackCards);
}

function runEffect(match, pending, eff, stackCards) {
  const actor = match.players[pending.actor];
  const target = pending.target !== null ? match.players[pending.target] : null;
  const base = { type: "resolve", cardType: pending.type, effective: eff, actor: pending.actor, target: pending.target, cancelled: false };
  switch (eff) {
    case "khabs": {
      shuffleInPlace(match, match.deck);
      emit(match, base);
      break;
    }
    case "baser": {
      emit(match, { ...base, revealed: match.deck.slice(0, 3) });
      break;
    }
    case "ayyar": {
      const cards = match.deck.slice(0, 3);
      emit(match, { ...base, private: pending.actor, seen: cards });
      if (cards.length > 1) {
        match.pending = pending;
        setPrompt(match, PHASE.PRIVATE_SELECTION, { kind: "reorder", player: pending.actor, cards });
        return;
      }
      break;
    }
    case "tajammal": {
      const found = target?.alive ? target.hand.find((c) => match.cards[c] === pending.named) : null;
      if (found) {
        removeFrom(target.hand, found);
        actor.hand.push(found);
      }
      emit(match, { ...base, named: pending.named, success: Boolean(found), cardId: found || null });
      break;
    }
    case "saqib": {
      if (target && target.alive) {
        const mine = actor.hand;
        actor.hand = target.hand;
        target.hand = mine;
      }
      emit(match, base);
      break;
    }
    case "salakhni":
    case "shawwah": {
      if (eff === "shawwah") match.direction *= -1;
      emit(match, { ...base, direction: match.direction });
      break;
    }
    case "salifni": {
      emit(match, base);
      if (target && target.alive && target.hand.length > 0) {
        match.pending = pending;
        setPrompt(match, PHASE.PRIVATE_SELECTION, { kind: "give", player: target.id, to: actor.id });
        return;
      }
      break;
    }
    case "habsh": {
      const taken = [];
      if (target && target.alive) {
        for (let i = 0; i < 2 && target.hand.length > 0; i++) {
          const pick = target.hand[randInt(match, target.hand.length)];
          removeFrom(target.hand, pick);
          actor.hand.push(pick);
          taken.push(pick);
        }
      }
      emit(match, { ...base, taken, privateTo: [actor.id, target?.id] });
      break;
    }
    case "mbartam": {
      // Eligible: anything in the discard pile from before this play.
      const options = retrievableCards(match).filter((c) => !stackCards.includes(c));
      emit(match, base);
      if (options.length > 0) {
        match.pending = pending;
        setPrompt(match, PHASE.PRIVATE_SELECTION, { kind: "retrieve", player: actor.id, options });
        return;
      }
      break;
    }
    case "kafkha": {
      // A stacking كفخة adds 2 to everything the attacker still owed.
      const debt = pending.stacking ? pending.debtAtPlay + 2 : 2;
      actor.stats.kafkhaLanded++;
      match.pending = null;
      emit(match, { ...base, debt });
      handOverTurn(match, pending.target, debt, true);
      return;
    }
    case "shima": {
      emit(match, base);
      const index = match.deck.length >= 2 ? 1 : 0;
      match.pending = null;
      drawCard(match, actor.id, index, "shima");
      return;
    }
    default:
      emit(match, base);
  }
  match.pending = null;
  finishAction(match);
}

function setPrompt(match, phase, prompt) {
  match.phase = phase;
  match.prompt = prompt;
  emit(match, { type: "prompt", kind: prompt.kind, player: prompt.player });
}

function cmdGive(match, { player, cardId }) {
  const prompt = match.prompt;
  if (match.phase !== PHASE.PRIVATE_SELECTION || prompt?.kind !== "give") return "no-prompt";
  if (prompt.player !== player) return "not-your-prompt";
  const giver = match.players[player];
  if (!giver.hand.includes(cardId)) return "not-in-hand";
  removeFrom(giver.hand, cardId);
  match.players[prompt.to].hand.push(cardId);
  match.prompt = null;
  emit(match, { type: "given", player, to: prompt.to, cardId, privateTo: [player, prompt.to] });
  match.pending = null;
  finishAction(match);
  return null;
}

function cmdReorder(match, { player, order }) {
  const prompt = match.prompt;
  if (match.phase !== PHASE.PRIVATE_SELECTION || prompt?.kind !== "reorder") return "no-prompt";
  if (prompt.player !== player) return "not-your-prompt";
  if (!Array.isArray(order) || order.length !== prompt.cards.length) return "bad-order";
  const sorted = [...order].sort().join();
  if (sorted !== [...prompt.cards].sort().join()) return "bad-order";
  match.deck.splice(0, order.length, ...order);
  match.prompt = null;
  emit(match, { type: "reordered", player, private: player, order });
  match.pending = null;
  finishAction(match);
  return null;
}

function cmdRetrieve(match, { player, cardId }) {
  const prompt = match.prompt;
  if (match.phase !== PHASE.PRIVATE_SELECTION || prompt?.kind !== "retrieve") return "no-prompt";
  if (prompt.player !== player) return "not-your-prompt";
  if (!prompt.options.includes(cardId) || !match.discard.includes(cardId)) return "bad-card";
  removeFrom(match.discard, cardId);
  match.players[player].hand.push(cardId);
  match.prompt = null;
  emit(match, { type: "retrieved", player, cardId });
  match.pending = null;
  finishAction(match);
  return null;
}

// ---------------------------------------------------------------------------
// Drawing and وافقري

function cmdDraw(match, { player }) {
  if (match.phase !== PHASE.PLAYER_TURN) return "not-your-phase";
  if (match.turn !== player) return "not-your-turn";
  if (match.deck.length === 0) return "empty-deck";
  drawCard(match, player, 0, "draw");
  return null;
}

function drawCard(match, player, index, via) {
  const p = match.players[player];
  const [cardId] = match.deck.splice(index, 1);
  p.stats.drawn++;
  const cardType = match.cards[cardId];
  emit(match, { type: "draw", player, cardId, cardType: cardType === "wafqari" ? "wafqari" : cardType, via, index, privateType: cardType !== "wafqari" });
  if (cardType !== "wafqari") {
    p.hand.push(cardId);
    finishAction(match);
    return;
  }
  // وافقري: everyone sees it.
  const batran = p.hand.find((c) => match.cards[c] === "batran");
  if (batran) {
    removeFrom(p.hand, batran);
    match.discard.push(batran);
    match.stack.push(cardId);
    p.stats.survived++;
    emit(match, { type: "defuse", player, cardId, batranId: batran });
    setPrompt(match, PHASE.DEFUSE_SELECTION, { kind: "reinsert", player, cardId, max: match.deck.length });
    return;
  }
  eliminate(match, player, cardId);
}

function cmdReinsert(match, { player, position }) {
  const prompt = match.prompt;
  if (match.phase !== PHASE.DEFUSE_SELECTION || prompt?.kind !== "reinsert") return "no-prompt";
  if (prompt.player !== player) return "not-your-prompt";
  if (!Number.isInteger(position) || position < 0 || position > match.deck.length) return "bad-position";
  removeFrom(match.stack, prompt.cardId);
  match.deck.splice(position, 0, prompt.cardId);
  match.prompt = null;
  // The position itself is private to the player.
  emit(match, { type: "reinsert", player, cardId: prompt.cardId, position, private: player });
  finishAction(match);
  return null;
}

function eliminate(match, player, wafqariId) {
  const p = match.players[player];
  p.alive = false;
  match.discard.push(...p.hand, wafqariId);
  const lost = p.hand.splice(0);
  match.eliminated.push(player);
  emit(match, { type: "eliminate", player, cardId: wafqariId, lost });
  const alive = alivePlayers(match);
  if (alive.length === 1) {
    match.winner = alive[0].id;
    match.phase = PHASE.GAME_OVER;
    match.pending = null;
    match.prompt = null;
    emit(match, { type: "win", player: match.winner });
    return;
  }
  finishAction(match);
}

// ---------------------------------------------------------------------------
// Turn flow

// One action (a play or a draw) is complete: pay one action of debt and move
// on when the debt is paid.
function finishAction(match) {
  if (match.phase === PHASE.GAME_OVER) return;
  match.actionCount++;
  match.prompt = null;
  match.pending = null;
  const current = match.players[match.turn];
  if (!current.alive) {
    handOverTurn(match, nextAlive(match, match.turn), 1, false);
    return;
  }
  match.debt -= 1;
  if (match.debt <= 0) {
    handOverTurn(match, nextAlive(match, match.turn), 1, false);
    return;
  }
  match.phase = PHASE.PLAYER_TURN;
  emit(match, { type: "turn", player: match.turn, debt: match.debt, continued: true });
}

function handOverTurn(match, player, debt, underAttack) {
  match.phase = PHASE.TURN_COMPLETE;
  match.prompt = null;
  match.pending = null;
  match.turn = player;
  match.debt = debt;
  match.underAttack = underAttack;
  match.phase = PHASE.PLAYER_TURN;
  startTurnStats(match);
  emit(match, { type: "turn", player, debt, attacked: underAttack });
}

function startTurnStats(match) {
  match.turnCount++;
  match.players[match.turn].stats.turns++;
}

// ---------------------------------------------------------------------------
// Helpers

function removeFrom(list, item) {
  const i = list.indexOf(item);
  if (i >= 0) list.splice(i, 1);
}

function emit(match, event) {
  if (!match.events) return;
  if (match.snapshots) event.snap = snapshot(match);
  match.events.push(event);
}

// Where every card is right now — what the table should show after an event.
export function snapshot(match) {
  return {
    deck: match.deck.slice(),
    discard: match.discard.slice(),
    stack: match.stack.slice(),
    hands: match.players.map((p) => p.hand.slice()),
    alive: match.players.map((p) => p.alive),
    turn: match.turn,
    direction: match.direction,
    debt: match.debt,
    underAttack: match.underAttack,
  };
}

// Invariant check used by tests: every card is in exactly one place.
export function checkIntegrity(match) {
  const where = new Map();
  const put = (id, place) => {
    if (where.has(id)) throw new Error(`card ${id} in ${where.get(id)} and ${place}`);
    where.set(id, place);
  };
  match.deck.forEach((c) => put(c, "deck"));
  match.discard.forEach((c) => put(c, "discard"));
  match.stack.forEach((c) => put(c, "stack"));
  match.players.forEach((p) => p.hand.forEach((c) => put(c, `hand${p.id}`)));
  const total = Object.keys(match.cards).length;
  if (where.size !== total) throw new Error(`card count ${where.size} != ${total}`);
  const alive = alivePlayers(match).length;
  const wafInPlay = match.deck.concat(match.stack).filter((c) => match.cards[c] === "wafqari").length;
  if (match.phase !== PHASE.GAME_OVER && wafInPlay !== alive - 1) {
    throw new Error(`wafqari in play ${wafInPlay} != alive-1 ${alive - 1}`);
  }
  for (const p of match.players) {
    if (p.hand.some((c) => match.cards[c] === "wafqari")) throw new Error("wafqari in a hand");
  }
  return true;
}
