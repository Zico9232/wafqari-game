// AI opponents. Each AI decides only from public information, its own hand,
// and what it has legitimately seen (باصر / العيار / its own reinsertion),
// tracked in a per-player memory object outside the match.
//
// Easy: random legal moves. Medium: risk-aware. Hard: remembers the deck,
// counts وافقري odds exactly and aims its reactions.

import { CARD_VALUE, SAWBNA_OK } from "./cards.js";
import {
  PHASE, effectiveType, legalPlays, legalReactions, nextAlive, wafqariInDeck,
} from "./engine.js";

export function createMemory() {
  return { known: [] }; // card ids in the deck whose type this AI has seen
}

// Feed every event to every AI so it can remember what it saw.
export function observe(memory, match, event, me) {
  switch (event.type) {
    case "resolve":
      if (event.effective === "khabs") memory.known = [];
      if (event.revealed) add(memory, event.revealed);
      if (event.seen && event.private === me) add(memory, event.seen);
      break;
    case "reorder":
    case "reordered":
      // Order changed; the ids are still known to the one who saw them.
      break;
    case "reinsert":
      if (event.player === me) add(memory, [event.cardId]);
      break;
    default:
  }
  memory.known = memory.known.filter((c) => match.deck.includes(c));
}

function add(memory, ids) {
  for (const id of ids) if (!memory.known.includes(id)) memory.known.push(id);
}

// Probability that deck[index] is وافقري, from this AI's point of view.
export function risk(match, memory, index = 0, difficulty = "medium") {
  const cid = match.deck[index];
  if (!cid) return 0;
  const total = wafqariInDeck(match);
  if (difficulty === "easy") return total / match.deck.length;
  if (memory.known.includes(cid)) return match.cards[cid] === "wafqari" ? 1 : 0;
  const knownWaf = memory.known.filter((c) => match.cards[c] === "wafqari").length;
  const unknown = match.deck.length - memory.known.length;
  return unknown > 0 ? Math.max(0, total - knownWaf) / unknown : 0;
}

const pick = (list, rnd) => list[Math.floor(rnd() * list.length)];

// ---------------------------------------------------------------------------
// Turn decision → command

export function chooseTurn(match, me, memory, rnd = Math.random) {
  const player = match.players[me];
  const diff = player.difficulty;
  const plays = legalPlays(match, me);
  const draw = { kind: "draw", player: me };
  if (plays.length === 0) return draw;
  if (diff === "easy") {
    if (rnd() < 0.45) return draw;
    return buildPlay(match, me, pick(plays, rnd), diff, memory, rnd);
  }
  const hasBatran = player.hand.some((c) => match.cards[c] === "batran");
  const danger = risk(match, memory, 0, diff);
  const threshold = hasBatran ? 0.55 : diff === "hard" ? 0.16 : 0.24;
  const byType = (t) => plays.find((p) => p.effective === t || p.type === t);

  // Certain or likely doom: get out of drawing.
  if (danger >= threshold) {
    const escapeOrder = ["kafkha", "salakhni", "shima", "khabs", "shawwah", "ayyar", "baser", "habsh", "salifni", "tajammal", "saqib", "mbartam", "nafs"];
    for (const t of escapeOrder) {
      const play = byType(t);
      if (!play) continue;
      if (t === "shima" && risk(match, memory, 1, diff) >= danger) continue;
      return buildPlay(match, me, play, diff, memory, rnd);
    }
    return buildPlay(match, me, plays[0], diff, memory, rnd);
  }

  // Safe enough: usually draw to build a hand, sometimes press an advantage.
  const richest = Math.max(...match.players.filter((p) => p.alive && p.id !== me).map((p) => p.hand.length));
  if (!hasBatran) {
    const ask = byType("tajammal");
    if (ask && rnd() < 0.6) return buildPlay(match, me, ask, diff, memory, rnd, "batran");
  }
  const steal = byType("habsh");
  if (steal && richest >= 3 && rnd() < (diff === "hard" ? 0.55 : 0.35)) return buildPlay(match, me, steal, diff, memory, rnd);
  const handCap = diff === "hard" ? 9 : 8;
  if (player.hand.length >= handCap) {
    // Spend the least useful card.
    const sorted = [...plays].sort((a, b) => (CARD_VALUE[a.type] ?? 5) - (CARD_VALUE[b.type] ?? 5));
    return buildPlay(match, me, sorted[0], diff, memory, rnd);
  }
  if (danger > 0.08 && diff === "hard") {
    const info = byType("ayyar") || byType("baser");
    if (info && !memory.known.includes(match.deck[0])) return buildPlay(match, me, info, diff, memory, rnd);
  }
  return rnd() < 0.85 ? draw : buildPlay(match, me, pick(plays, rnd), diff, memory, rnd);
}

function buildPlay(match, me, play, diff, memory, rnd, wanted) {
  const cmd = { kind: "play", player: me, cardId: play.cardId };
  if (play.targets.length) cmd.target = chooseTarget(match, me, play.effective, play.targets, diff, rnd);
  if (play.effective === "tajammal") cmd.named = wanted || nameForAsk(match, me, rnd);
  return cmd;
}

function chooseTarget(match, me, type, targets, diff, rnd) {
  if (diff === "easy") return pick(targets, rnd);
  const players = targets.map((id) => match.players[id]);
  if (type === "kafkha") {
    // Hit whoever looks most fragile: fewest cards.
    players.sort((a, b) => a.hand.length - b.hand.length);
    return diff === "hard" ? players[0].id : pick(players.slice(0, 2), rnd).id;
  }
  // Steal/ask/swap/borrow: richest hand.
  players.sort((a, b) => b.hand.length - a.hand.length);
  if (type === "saqib" && players[0].hand.length <= match.players[me].hand.length) return pick(targets, rnd);
  return players[0].id;
}

function nameForAsk(match, me, rnd) {
  const hand = match.players[me].hand.map((c) => match.cards[c]);
  if (!hand.includes("batran")) return "batran";
  return pick(["hajaa", "kafkha", "salakhni", "sawbna"], rnd);
}

// ---------------------------------------------------------------------------
// Reaction decision → command (react or pass)

export function chooseReaction(match, me, memory, rnd = Math.random) {
  const pass = { kind: "pass", player: me };
  const options = legalReactions(match, me);
  if (options.length === 0) return pass;
  const diff = match.players[me].difficulty;
  const pending = match.pending;
  const eff = effectiveType(pending);
  const willingness = diff === "easy" ? 0.3 : diff === "medium" ? 0.7 : 0.95;
  const hajaa = options.find((o) => o.type === "hajaa");
  const sawbna = options.find((o) => o.type === "sawbna");
  const chainLen = pending.chain.length;
  const react = (o, target) => ({ kind: "react", player: me, cardId: o.cardId, target, chainLen });

  const aimedAtMe = pending.target === me && !pending.cancelled;
  const harmful = ["kafkha", "habsh", "salifni", "tajammal"].includes(eff) ||
    (eff === "saqib" && match.players[me].hand.length > match.players[pending.actor].hand.length);
  if (aimedAtMe && harmful && rnd() < willingness) {
    if (sawbna && SAWBNA_OK.has(eff)) {
      const target = sawbna.targets.length ? (sawbna.targets.includes(pending.actor) ? pending.actor : sawbna.targets[0]) : undefined;
      return react(sawbna, target);
    }
    if (hajaa) return react(hajaa);
  }
  // My own action got cancelled: cancel the cancel (hard only).
  if (diff === "hard" && pending.cancelled && pending.actor === me && hajaa && rnd() < 0.8) return react(hajaa);
  // Someone else is getting a big benefit (stacked كفخة on me via chain etc.)
  if (diff !== "easy" && eff === "kafkha" && pending.stacking && pending.target === me && hajaa) return react(hajaa);
  return pass;
}

// ---------------------------------------------------------------------------
// Private prompts → command

export function answerPrompt(match, me, memory, rnd = Math.random) {
  const prompt = match.prompt;
  const diff = match.players[me].difficulty;
  if (!prompt || prompt.player !== me) return null;
  if (prompt.kind === "give") {
    const hand = [...match.players[me].hand];
    if (diff === "easy") return { kind: "give", player: me, cardId: pick(hand, rnd) };
    hand.sort((a, b) => (CARD_VALUE[match.cards[a]] ?? 5) - (CARD_VALUE[match.cards[b]] ?? 5));
    return { kind: "give", player: me, cardId: hand[0] };
  }
  if (prompt.kind === "retrieve") {
    const options = [...prompt.options];
    if (diff === "easy") return { kind: "retrieve", player: me, cardId: pick(options, rnd) };
    options.sort((a, b) => (CARD_VALUE[match.cards[b]] ?? 5) - (CARD_VALUE[match.cards[a]] ?? 5));
    return { kind: "retrieve", player: me, cardId: options[0] };
  }
  if (prompt.kind === "reorder") {
    const cards = [...prompt.cards];
    if (diff === "easy") return { kind: "reorder", player: me, order: cards.sort(() => rnd() - 0.5) };
    const waf = cards.filter((c) => match.cards[c] === "wafqari");
    const rest = cards.filter((c) => match.cards[c] !== "wafqari");
    // After this action my turn ends unless I still owe actions.
    const turnEnds = match.debt <= 1;
    const order = turnEnds ? [...waf, ...rest] : [...rest, ...waf];
    return { kind: "reorder", player: me, order };
  }
  if (prompt.kind === "reinsert") {
    const max = match.deck.length;
    let position;
    if (diff === "easy") position = Math.floor(rnd() * (max + 1));
    else if (diff === "medium") position = Math.min(max, Math.floor(rnd() * 3));
    else position = match.debt > 1 ? Math.min(max, 2) : 0;
    return { kind: "reinsert", player: me, position };
  }
  return null;
}

// Who must act next, and how — used by the controller and by tests.
export function pendingDecider(match) {
  if (match.phase === PHASE.PLAYER_TURN) return { kind: "turn", player: match.turn };
  if (match.phase === PHASE.PRIVATE_SELECTION || match.phase === PHASE.DEFUSE_SELECTION) {
    return { kind: "prompt", player: match.prompt.player };
  }
  if (match.phase === PHASE.REACTION_WINDOW) return { kind: "reaction" };
  return null;
}

export { nextAlive };
