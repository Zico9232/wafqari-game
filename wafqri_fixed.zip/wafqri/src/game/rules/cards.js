// Card catalogue for WAFQARI. `art` is the original image number in the
// creator's GitHub repository (1.png is the card back). Pure data: no DOM,
// no Three.js — the rules engine and the headless tests import this file.

export const CARD = {
  KHABS: "khabs",
  BASER: "baser",
  BATRAN: "batran",
  SHIMA: "shima",
  AYYAR: "ayyar",
  TAJAMMAL: "tajammal",
  SAQIB: "saqib",
  SALAKHNI: "salakhni",
  SALIFNI: "salifni",
  SHAWWAH: "shawwah",
  SAWBNA: "sawbna",
  KAFKHA: "kafkha",
  MBARTAM: "mbartam",
  NAFS: "nafs",
  HABSH: "habsh",
  HAJAA: "hajaa",
  WAFQARI: "wafqari",
};

export const BACK_ART = 1;

// name: Arabic card title. rule: one-line player-facing rule.
// target: needs an opponent chosen at play time. targetNeedsCards: that
// opponent must hold at least one card.
export const CARD_INFO = {
  khabs: { art: 2, name: "خبص", rule: "اخلط كومة السحب." },
  baser: { art: 3, name: "باصر", rule: "اكشف أعلى ٣ بطاقات للجميع دون تغيير ترتيبها." },
  batran: { art: 4, name: "البطران", rule: "تنقذك من وافقري، ثم تعيدها سرًا في الكومة حيث تشاء." },
  shima: { art: 5, name: "الشيمة", rule: "اسحب البطاقة الثانية من الكومة وتترك الأولى مكانها." },
  ayyar: { art: 6, name: "العيار", rule: "شاهد أعلى ٣ بطاقات سرًا ورتّبها كما تريد." },
  tajammal: { art: 7, name: "تجمل", rule: "اختر خصمًا وسمِّ بطاقة؛ إن كانت معه تأخذ نسخة.", target: true, targetNeedsCards: true },
  saqib: { art: 8, name: "ساقب", rule: "بدّل يدك كاملة مع خصم.", target: true },
  salakhni: { art: 9, name: "سلخني", rule: "اترك دورك دون سحب." },
  salifni: { art: 10, name: "سلفني", rule: "خصم يختار بطاقة ويعطيك إياها.", target: true, targetNeedsCards: true },
  shawwah: { art: 11, name: "شوح", rule: "اعكس اتجاه اللعب." },
  sawbna: { art: 12, name: "صوبنا", rule: "رد فعل: استولِ على الحركة المعلّقة ووجّهها لصالحك.", reaction: true },
  kafkha: { art: 13, name: "كفخة", rule: "اختر خصمًا يلعب حركتين. تتراكم ٤، ٦، ٨…", target: true },
  mbartam: { art: 14, name: "مبرطم", rule: "استرجع بطاقة من كومة المرمي إلى يدك." },
  nafs: { art: 15, name: "نفس النمونة", rule: "كرّر آخر حركة مؤهلة." },
  habsh: { art: 16, name: "هبش", rule: "خذ بطاقتين عشوائيتين من خصم.", target: true, targetNeedsCards: true },
  hajaa: { art: 17, name: "هجع", rule: "رد فعل: ألغِ الحركة المعلّقة.", reaction: true },
  wafqari: { art: 18, name: "وافقري", rule: "إن سحبتها بلا بطران تخرج من اللعبة." },
};

export const ALL_TYPES = Object.keys(CARD_INFO);

// The 15 regular action types, in balancing priority order: when the deck
// size is not a multiple of 15, the remainder goes one extra copy each to
// the types at the front of this list.
export const REGULAR_PRIORITY = [
  "hajaa", "kafkha", "habsh", "salakhni", "shawwah", "sawbna", "baser",
  "salifni", "ayyar", "khabs", "shima", "tajammal", "saqib", "mbartam", "nafs",
];

// Types that can never be played as your own action.
export const NOT_ACTION = new Set(["batran", "wafqari", "hajaa", "sawbna"]);
// Cards a هجع may not cancel / a صوبنا may not take over (never pending anyway,
// kept explicit to document the rule).
export const UNREACTABLE = new Set(["wafqari", "batran"]);
// صوبنا only makes sense where there is an owner or a target to take over.
export const SAWBNA_OK = new Set([
  "kafkha", "habsh", "salifni", "saqib", "tajammal", "mbartam", "ayyar", "baser", "nafs",
]);
// نفس النمونة never copies these (prevents loops and copying reactions).
export const NOT_COPYABLE = new Set(["wafqari", "batran", "nafs", "hajaa", "sawbna"]);
// مبرطم never retrieves these (وافقري by rule; مبرطم/نفس النمونة to rule out
// endless retrieve-and-replay loops — documented engine choice).
export const NOT_RETRIEVABLE = new Set(["wafqari", "mbartam", "nafs"]);

// Regular-card counts for a given player count: 8 per player.
export function regularCounts(playerCount) {
  const total = playerCount * 8;
  const base = Math.floor(total / REGULAR_PRIORITY.length);
  let extra = total - base * REGULAR_PRIORITY.length;
  const counts = {};
  for (const t of REGULAR_PRIORITY) {
    counts[t] = base + (extra > 0 ? 1 : 0);
    if (extra > 0) extra--;
  }
  return counts;
}

// How much a card is worth holding (AI heuristics, gift choice).
export const CARD_VALUE = {
  batran: 100, hajaa: 9, sawbna: 8, kafkha: 8, salakhni: 7, habsh: 7, shawwah: 6,
  ayyar: 6, shima: 6, salifni: 6, baser: 5, khabs: 5, tajammal: 5, mbartam: 5,
  nafs: 5, saqib: 4, wafqari: -100,
};
