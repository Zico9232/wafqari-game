// Seeded, serializable RNG (mulberry32). The whole match state stays plain
// JSON, so a server could hold it and replay it deterministically.

export function nextRandom(holder) {
  holder.rng = (holder.rng + 0x6d2b79f5) | 0;
  let t = holder.rng;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

export function randInt(holder, n) {
  return Math.floor(nextRandom(holder) * n);
}

export function shuffleInPlace(holder, list) {
  for (let i = list.length - 1; i > 0; i--) {
    const j = randInt(holder, i + 1);
    [list[i], list[j]] = [list[j], list[i]];
  }
  return list;
}
