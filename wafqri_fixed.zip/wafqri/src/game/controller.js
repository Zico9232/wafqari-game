// Match flow: owns the rules match, asks AIs and humans for decisions,
// runs the reaction countdown, manages who holds the device in pass-the-
// phone mode, and hands every event to the presenter. All timing is dt.

import { applyCommand, createMatch, dealMatch, eligibleReactors, legalPlays, legalReactions, PHASE } from "./rules/engine.js";
import { answerPrompt, chooseReaction, chooseTurn, createMemory, observe } from "./rules/ai.js";
import { CARD_INFO } from "./rules/cards.js";

export function createController({ presenter, table, ui, audio, tweaks, settings, onMatchEnd }) {
  let match = null;
  let config = null;
  let memories = [];
  let cmdSeq = 0;
  let aiTimer = 0;
  let reactionTimer = 0;
  let reactionTotal = 0;
  let reactionRound = -1;
  let aiReactPlan = null; // { round, at: Map(id → seconds) }
  let viewer = null; // seat holding the device (friends) / the human (ai)
  let facesShown = true;
  let handoffFor = null;
  let ended = false;
  let paused = false;
  let reactionHold = false; // a friend is choosing a reaction
  let passedRound = -1; // the human at the device passed this round
  let elapsed = 0;

  function start(cfg) {
    config = cfg;
    presenter.reset();
    table.clear();
    ui.resetMatch();
    match = createMatch({ players: cfg.players, seed: (Math.random() * 2 ** 31) | 0, snapshots: true });
    memories = match.players.map(() => createMemory());
    const firstHuman = match.players.find((p) => !p.isAI);
    viewer = firstHuman ? firstHuman.id : 0;
    facesShown = cfg.mode !== "friends";
    table.setPlayers(match.players.length, viewer);
    table.setViewer(viewer, facesShown);
    table.setTypes(match.cards);
    const events = dealMatch(match);
    table.setTypes(match.cards);
    presenter.setCardTypes((cid) => match.cards[cid]);
    feed(events);
    ended = false;
    aiTimer = 0.6;
    handoffFor = null;
    paused = false;
    elapsed = 0;
    ui.setupSeats(match, viewer);
  }

  function feed(events) {
    for (const e of events) {
      match.players.forEach((p) => { if (p.isAI) observe(memories[p.id], match, e, p.id); });
    }
    presenter.push(events);
    ui.onEvents(events, match);
  }

  function send(cmd) {
    if (!match) return false;
    cmd.cid = `k${++cmdSeq}`;
    const res = applyCommand(match, cmd);
    if (!res.ok) {
      if (res.error !== "duplicate") console.warn("[wafqari] rejected", cmd.kind, res.error);
      return false;
    }
    feed(res.events);
    table.setSelected(null);
    return true;
  }

  // --- viewer / handoff (pass the phone) ------------------------------------

  function needViewer(id) {
    if (config.mode !== "friends") return true;
    if (viewer === id && facesShown) return true;
    if (handoffFor !== id) {
      handoffFor = id;
      // Hide every hand until the right person confirms.
      facesShown = false;
      table.setViewer(viewer, false);
      ui.showHandoff(match.players[id], () => {
        viewer = id;
        facesShown = true;
        handoffFor = null;
        table.setViewer(viewer, true);
        ui.setupSeats(match, viewer);
      });
    }
    return false;
  }

  function spectate() {
    // Nobody in particular holds the device: hide faces.
    if (config.mode === "friends" && facesShown) {
      facesShown = false;
      table.setViewer(viewer, false);
    }
  }

  // --- frame ---------------------------------------------------------------

  function update(dt) {
    if (!match || paused) return;
    elapsed += dt;
    if (match.phase === PHASE.GAME_OVER) {
      if (!ended && presenter.idle) {
        ended = true;
        ui.hideAllPrompts();
        onMatchEnd?.(match, config);
      }
      return;
    }
    if (!presenter.idle) {
      ui.setInputEnabled(false);
      return;
    }
    const phase = match.phase;
    if (phase === PHASE.PLAYER_TURN) return turnPhase(dt);
    if (phase === PHASE.REACTION_WINDOW) return reactionPhase(dt);
    if (phase === PHASE.PRIVATE_SELECTION || phase === PHASE.DEFUSE_SELECTION) return promptPhase(dt);
  }

  function aiDelay(p) {
    const base = Number(tweaks.get("aiThinkSeconds")) || 0.8;
    const f = p.difficulty === "hard" ? 1.1 : p.difficulty === "easy" ? 0.8 : 1;
    return base * f * (0.7 + Math.random() * 0.6);
  }

  function turnPhase(dt) {
    ui.hideReaction();
    const p = match.players[match.turn];
    if (p.isAI) {
      spectate();
      ui.setInputEnabled(false);
      ui.hidePrompt();
      aiTimer -= dt;
      if (aiTimer > 0) return;
      aiTimer = aiDelay(p);
      const cmd = chooseTurn(match, p.id, memories[p.id]);
      if (!send(cmd)) send({ kind: "draw", player: p.id });
      return;
    }
    if (!needViewer(p.id)) { ui.setInputEnabled(false); return; }
    ui.hidePrompt();
    ui.setInputEnabled(true, { canDraw: true, plays: legalPlays(match, p.id) });
    aiTimer = 0.5;
  }

  function reactionPhase(dt) {
    ui.setInputEnabled(false);
    const round = match.reaction.round;
    const eligible = eligibleReactors(match);
    if (round !== reactionRound) {
      reactionRound = round;
      const base = Number(tweaks.get("reactionSeconds")) || 3;
      reactionTotal = base * (settings().reactionScale || 1);
      reactionTimer = reactionTotal;
      reactionHold = false;
      aiReactPlan = new Map();
      for (const id of eligible) {
        const p = match.players[id];
        if (p.isAI) aiReactPlan.set(id, 0.35 + Math.random() * Math.min(1.4, reactionTotal * 0.5));
      }
      // vs AI: a human with no reaction card passes at once (nothing to hide).
      if (config.mode !== "friends") {
        for (const id of eligible) {
          const p = match.players[id];
          if (!p.isAI && legalReactions(match, id).length === 0) send({ kind: "pass", player: id });
        }
        if (match.phase !== PHASE.REACTION_WINDOW) return;
      }
    }
    if (reactionHold) return;
    // AI decisions at their planned moments.
    for (const [id, at] of aiReactPlan) {
      if (reactionTotal - reactionTimer < at) continue;
      aiReactPlan.delete(id);
      const cmd = chooseReaction(match, id, memories[id]);
      if (cmd.kind === "react") {
        send(cmd);
        return;
      }
      send(cmd);
      if (match.phase !== PHASE.REACTION_WINDOW || match.reaction.round !== round) return;
    }
    reactionTimer -= dt;
    ui.showReaction(match, {
      left: Math.max(0, reactionTimer) / reactionTotal,
      mode: config.mode,
      viewer,
      options: config.mode === "friends" || passedRound === round ? null : legalReactions(match, viewer),
    });
    if (reactionTimer <= 0) {
      ui.hideReaction();
      send({ kind: "closeReactions" });
    }
  }

  function promptPhase(dt) {
    ui.hideReaction();
    const prompt = match.prompt;
    const p = match.players[prompt.player];
    if (p.isAI) {
      spectate();
      ui.hidePrompt();
      aiTimer -= dt;
      if (aiTimer > 0) return;
      aiTimer = aiDelay(p);
      const cmd = answerPrompt(match, p.id, memories[p.id]);
      if (cmd) send(cmd);
      return;
    }
    if (!needViewer(p.id)) return;
    ui.showPrompt(match, prompt);
  }

  // --- human actions (from UI / input) -----------------------------------

  function humanTurnPlayer() {
    if (!match || match.phase !== PHASE.PLAYER_TURN || !presenter.idle) return null;
    const p = match.players[match.turn];
    if (p.isAI || p.id !== viewer || !facesShown) return null;
    return p.id;
  }

  function draw() {
    const id = humanTurnPlayer();
    if (id === null) return false;
    audio.play("tick");
    return send({ kind: "draw", player: id });
  }

  function play(cardId, target, named) {
    const id = humanTurnPlayer();
    if (id === null) return false;
    return send({ kind: "play", player: id, cardId, target, named });
  }

  function react(player, cardId, target) {
    if (!match || match.phase !== PHASE.REACTION_WINDOW) return false;
    reactionHold = false;
    return send({ kind: "react", player, cardId, target, chainLen: match.pending.chain.length });
  }

  function passReaction(player) {
    if (!match || match.phase !== PHASE.REACTION_WINDOW) return;
    passedRound = match.reaction.round;
    send({ kind: "pass", player });
  }

  function closeReactions() {
    if (!match || match.phase !== PHASE.REACTION_WINDOW) return;
    send({ kind: "closeReactions" });
  }

  // Friends mode: someone wants to react → hand them the device.
  function friendWantsToReact(id) {
    if (!match || match.phase !== PHASE.REACTION_WINDOW) return;
    reactionHold = true;
    ui.showHandoff(match.players[id], () => {
      viewer = id;
      facesShown = true;
      table.setViewer(viewer, true);
      ui.setupSeats(match, viewer);
      ui.showPrivateReaction(match, id, legalReactions(match, id), () => {
        reactionHold = false;
        spectate();
      });
    });
  }

  function answer(cmd) {
    if (!match) return false;
    return send({ ...cmd, player: match.prompt?.player });
  }

  return {
    start,
    update,
    draw,
    play,
    react,
    passReaction,
    closeReactions,
    friendWantsToReact,
    answer,
    get match() { return match; },
    get config() { return config; },
    get viewer() { return viewer; },
    get facesShown() { return facesShown; },
    isMyTurn: () => humanTurnPlayer() !== null,
    legalFor: () => {
      const id = humanTurnPlayer();
      return id === null ? [] : legalPlays(match, id);
    },
    cardName: (cid) => CARD_INFO[match?.cards[cid]]?.name,
    setPaused(v) { paused = v; },
    get paused() { return paused; },
    quit() {
      match = null;
      presenter.reset();
      table.clear();
      ui.resetMatch();
    },
    get elapsed() { return elapsed; },
  };
}
