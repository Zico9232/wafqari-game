// In-match interface: top bar, seat badges anchored to the 3D seats, the
// action bar, the reaction countdown, private prompt sheets, the pass-the-
// phone cover, speech bubbles and screen effects. Counts shown here follow
// the table's displayed snapshot, so the HUD never runs ahead of the art.

import * as THREE from "three";
import { CARD_INFO, ALL_TYPES } from "../rules/cards.js";
import { el, esc, icon } from "./dom.js";

const tmp = new THREE.Vector3();

export function createHud({ root, frame, view, table, textures, audio, getController, onMenu }) {
  const ctl = () => getController();
  const charUrl = (art) => textures.charUrl[art];
  const cardUrl = (type) => textures.cardUrl[CARD_INFO[type]?.art ?? 1];

  // ---- DOM ------------------------------------------------------------------
  const seatsLayer = el("div", "seats-layer");
  const bubbleLayer = el("div", "bubble-layer");
  const fxLayer = el("div", "fx-layer");
  const flash = el("div", "screen-flash");
  const vignette = el("div", "screen-vignette");
  const stamp = el("div", "stamp");
  fxLayer.append(flash, vignette, stamp);
  frame.append(seatsLayer, bubbleLayer, fxLayer);

  const hud = el("div", "hud");
  hud.innerHTML = `
    <div class="hud-row top-bar bleed-top">
      <button class="control-btn icon-btn" data-act="menu" aria-label="القائمة">${icon("menu")}</button>
      <div class="turn-pill badge"><span class="turn-dot"></span><span class="turn-text control-label">—</span></div>
      <div class="deck-pill badge" title="بطاقات الكومة">${icon("cards")}<span class="deck-count">0</span></div>
    </div>
    <div class="reaction-bar" hidden>
      <div class="reaction-head"><span class="reaction-title control-label">رد فعل؟</span><span class="reaction-pending control-label"></span></div>
      <div class="reaction-timer"><i></i></div>
      <div class="reaction-actions"></div>
    </div>
    <div class="banner" hidden><span class="banner-text"></span></div>
    <div class="action-bar">
      <div class="me-chip"><span class="me-avatar"></span><span class="me-name control-label"></span><span class="me-debt" hidden></span></div>
      <div class="card-info" hidden>
        <div class="card-info-name"></div>
        <div class="card-info-rule"></div>
      </div>
      <div class="action-btns">
        <button class="control-btn primary play-btn" data-act="play" hidden>${icon("play")}<span class="control-label">العب</span></button>
        <button class="control-btn draw-btn" data-act="draw">${icon("draw")}<span class="control-label">اسحب</span></button>
      </div>
    </div>
    <div class="sheet" hidden><div class="sheet-title"></div><div class="sheet-sub"></div><div class="sheet-body"></div><div class="sheet-actions"></div></div>
  `;
  root.append(hud);
  const $ = (s) => hud.querySelector(s);
  const turnText = $(".turn-text");
  const turnDot = $(".turn-dot");
  const deckCount = $(".deck-count");
  const reactionBar = $(".reaction-bar");
  const reactionActions = $(".reaction-actions");
  const reactionTimerBar = $(".reaction-timer i");
  const reactionPending = $(".reaction-pending");
  const banner = $(".banner");
  const bannerText = $(".banner-text");
  const cardInfo = $(".card-info");
  const playBtn = $(".play-btn");
  const drawBtn = $(".draw-btn");
  const sheet = $(".sheet");
  const meAvatar = $(".me-avatar");
  const meName = $(".me-name");
  const meDebt = $(".me-debt");

  const cover = el("div", "handoff");
  cover.hidden = true;
  cover.innerHTML = `<div class="handoff-card"><div class="handoff-avatar"></div><div class="handoff-title">مرّر الجهاز إلى</div><div class="handoff-name"></div><button class="control-btn primary handoff-go"><span class="control-label">أنا جاهز</span></button><div class="handoff-note">لا تدع أحدًا يرى بطاقاتك</div></div>`;
  root.append(cover);

  // ---- state -------------------------------------------------------------
  const seatEls = new Map();
  const bubbles = [];
  const floats = [];
  let flashT = 0;
  let stampT = 0;
  let vignetteOn = false;
  let vignetteT = 0;
  let bannerT = 0;
  let inputEnabled = false;
  let plays = [];
  let targeting = null; // { cardId, targets, type }
  let sheetKey = null;
  let marks = new Set();
  let viewerRef = 0;
  let handoffCb = null;

  hud.addEventListener("click", (e) => {
    const b = e.target.closest("[data-act]");
    if (!b) return;
    audio.play("tick");
    const act = b.dataset.act;
    if (act === "menu") onMenu();
    if (act === "draw") { cancelTargeting(); ctl().draw(); }
    if (act === "play") tryPlaySelected();
  });
  cover.querySelector(".handoff-go").addEventListener("click", () => {
    audio.play("tick");
    cover.hidden = true;
    const cb = handoffCb;
    handoffCb = null;
    cb?.();
  });

  // ---- seats ----------------------------------------------------------------
  function setupSeats(match, viewer) {
    viewerRef = viewer;
    seatsLayer.replaceChildren();
    seatEls.clear();
    for (const p of match.players) {
      if (p.id === viewer) continue;
      const s = el("button", "seat");
      s.innerHTML = `<span class="seat-avatar" style="background-image:url('${charUrl(p.avatar)}')"></span><span class="seat-name">${esc(p.name)}</span><span class="seat-meta"><span class="seat-cards">${icon("cards")}<b>0</b></span><span class="seat-debt" hidden></span></span>`;
      s.dataset.id = p.id;
      s.addEventListener("click", () => onSeatTap(p.id));
      seatsLayer.append(s);
      seatEls.set(p.id, s);
    }
    const me = match.players[viewer];
    meAvatar.style.backgroundImage = `url('${charUrl(me.avatar)}')`;
    meName.textContent = me.name;
  }

  function onSeatTap(id) {
    if (targeting && targeting.targets.includes(id)) {
      audio.play("tick");
      const t = targeting;
      cancelTargeting();
      if (t.onPick) t.onPick(id);
    }
  }

  function worldToScreen(v, out = { x: 0, y: 0, behind: false }) {
    tmp.copy(v).project(view.camera);
    const r = frame.getBoundingClientRect();
    out.x = (tmp.x + 1) / 2 * r.width;
    out.y = (1 - tmp.y) / 2 * r.height;
    out.behind = tmp.z > 1;
    return out;
  }

  // ---- selection / playing --------------------------------------------------
  function reasonFor(type, legal) {
    if (legal) return null;
    if (type === "batran") return "تحميك تلقائيًا عند سحب وافقري";
    if (type === "hajaa" || type === "sawbna") return "بطاقة رد فعل — تُلعب عند لعب غيرك";
    if (!ctl().isMyTurn()) return "انتظر دورك";
    if (type === "nafs") return "لا توجد حركة لتكرارها بعد";
    if (type === "mbartam") return "لا شيء مؤهل في المرمي";
    return "لا يوجد هدف متاح";
  }

  function refreshCardInfo() {
    const sel = table.selected;
    const m = ctl().match;
    if (!sel || !m) {
      cardInfo.hidden = true;
      playBtn.hidden = true;
      return;
    }
    const type = m.cards[sel];
    const legal = plays.find((p) => p.cardId === sel);
    cardInfo.hidden = false;
    cardInfo.querySelector(".card-info-name").textContent = CARD_INFO[type].name;
    const reason = reasonFor(type, legal && inputEnabled);
    cardInfo.querySelector(".card-info-rule").textContent = reason ? `${CARD_INFO[type].rule} · ${reason}` : CARD_INFO[type].rule;
    playBtn.hidden = !(legal && inputEnabled);
  }

  function select(cid) {
    cancelTargeting();
    table.setSelected(table.selected === cid ? null : cid);
    refreshCardInfo();
  }

  function tryPlaySelected() {
    const sel = table.selected;
    const legal = plays.find((p) => p.cardId === sel);
    if (!legal || !inputEnabled) { audio.play("error"); return; }
    const finish = (target, named) => {
      ctl().play(sel, target, named);
      table.setSelected(null);
      refreshCardInfo();
    };
    const askName = (target) => {
      if (legal.effective !== "tajammal") return finish(target);
      openSheet("name", "سمِّ بطاقة", "إن كانت عند الخصم تأخذ نسخة منها", cardGrid(ALL_TYPES.filter((t) => t !== "wafqari"), (t) => finish(target, t)), [cancelButton()]);
    };
    if (legal.targets.length && legal.autoTarget === null) {
      startTargeting(legal.targets, CARD_INFO[legal.effective].name, askName);
    } else askName(legal.autoTarget ?? undefined);
  }

  function startTargeting(targets, label, onPick) {
    targeting = { targets, onPick };
    for (const [id, s] of seatEls) s.classList.toggle("targetable", targets.includes(id));
    const m = ctl().match;
    const list = el("div", "target-list");
    for (const id of targets) {
      const p = m.players[id];
      const b = el("button", "target-btn", `<span class="seat-avatar" style="background-image:url('${charUrl(p.avatar)}')"></span><span class="control-label">${esc(p.name)}</span><small>${icon("cards")}${p.hand.length}</small>`);
      b.addEventListener("click", () => onSeatTap(id));
      list.append(b);
    }
    openSheet("target", `${label}: اختر خصمًا`, "اضغط على صورة اللاعب", list, [cancelButton()]);
  }

  function cancelTargeting() {
    if (!targeting) return;
    targeting = null;
    for (const s of seatEls.values()) s.classList.remove("targetable");
    if (sheetKey === "target" || sheetKey === "name") closeSheet();
  }

  function cancelButton(label = "إلغاء") {
    const b = el("button", "control-btn ghost", `<span class="control-label">${label}</span>`);
    b.addEventListener("click", () => { audio.play("tick"); cancelTargeting(); closeSheet(); });
    return b;
  }

  // ---- sheets -------------------------------------------------------------
  function openSheet(key, title, sub, body, actions = []) {
    sheetKey = key;
    sheet.hidden = false;
    sheet.querySelector(".sheet-title").textContent = title;
    sheet.querySelector(".sheet-sub").textContent = sub || "";
    sheet.querySelector(".sheet-body").replaceChildren(body);
    sheet.querySelector(".sheet-actions").replaceChildren(...actions);
  }
  function closeSheet() {
    sheet.hidden = true;
    sheetKey = null;
  }

  function cardThumb(type, extra = "") {
    return `<span class="thumb ${extra}"><img src="${cardUrl(type)}" alt="${esc(CARD_INFO[type].name)}" draggable="false"></span>`;
  }

  function cardGrid(types, onPick, labels) {
    const g = el("div", "card-grid");
    types.forEach((t, i) => {
      const b = el("button", "grid-card", `${cardThumb(t)}<span class="grid-name">${esc(labels?.[i] ?? CARD_INFO[t].name)}</span>`);
      b.addEventListener("click", () => { audio.play("tick"); onPick(t, i); });
      g.append(b);
    });
    return g;
  }

  // Private prompts for the human at the device.
  function showPrompt(match, prompt) {
    const key = `${prompt.kind}:${prompt.player}:${match.actionCount}`;
    if (sheetKey === key) return;
    cancelTargeting();
    const me = match.players[prompt.player];
    if (prompt.kind === "give") {
      const to = match.players[prompt.to];
      const cards = me.hand.slice();
      openSheet(key, `${to.name} يطلب بطاقة`, "اختر البطاقة التي ستعطيها", cardGrid(cards.map((c) => match.cards[c]), (t, i) => {
        closeSheet();
        ctl().answer({ kind: "give", cardId: cards[i] });
      }));
    } else if (prompt.kind === "retrieve") {
      const opts = prompt.options.slice();
      openSheet(key, "مبرطم: اختر من المرمي", "تعود البطاقة إلى يدك", cardGrid(opts.map((c) => match.cards[c]), (t, i) => {
        closeSheet();
        ctl().answer({ kind: "retrieve", cardId: opts[i] });
      }));
    } else if (prompt.kind === "reorder") {
      const cards = prompt.cards.slice();
      let order = [];
      const body = el("div", "reorder");
      const render = () => {
        body.replaceChildren();
        const row = el("div", "reorder-row");
        cards.forEach((cid) => {
          const n = order.indexOf(cid);
          const b = el("button", `grid-card ${n >= 0 ? "picked" : ""}`, `${cardThumb(match.cards[cid])}<span class="grid-name">${n >= 0 ? `#${n + 1}` : CARD_INFO[match.cards[cid]].name}</span>`);
          b.addEventListener("click", () => {
            audio.play("tick");
            if (n >= 0) order = order.filter((c) => c !== cid);
            else order.push(cid);
            render();
            confirm.disabled = order.length !== cards.length;
          });
          row.append(b);
        });
        body.append(row);
      };
      const confirm = el("button", "control-btn primary", `${icon("check")}<span class="control-label">تأكيد</span>`);
      confirm.disabled = true;
      confirm.addEventListener("click", () => { closeSheet(); ctl().answer({ kind: "reorder", order }); });
      const keep = el("button", "control-btn ghost", `<span class="control-label">كما هي</span>`);
      keep.addEventListener("click", () => { closeSheet(); ctl().answer({ kind: "reorder", order: cards }); });
      render();
      openSheet(key, "العيار: رتّب أعلى الكومة", "اضغط بالترتيب: الأولى = أعلى الكومة (سرّي)", body, [keep, confirm]);
    } else if (prompt.kind === "reinsert") {
      const max = prompt.max;
      const body = el("div", "reinsert");
      body.innerHTML = `
        <div class="reinsert-preview"><span class="thumb small">${`<img src="${cardUrl("wafqari")}" alt="">`}</span><span class="reinsert-label"></span></div>
        <input type="range" min="0" max="${max}" step="1" value="0" class="reinsert-range" dir="ltr" aria-label="الموضع">
        <div class="reinsert-ends"><span>الأعلى</span><span>الأسفل</span></div>
        <div class="reinsert-quick"></div>`;
      const range = body.querySelector("input");
      const label = body.querySelector(".reinsert-label");
      const upd = () => {
        const v = Number(range.value);
        label.textContent = v === 0 ? "في الأعلى — اللاعب التالي يسحبها" : v === max ? "في أسفل الكومة" : `تحت ${v} ${v === 1 ? "بطاقة" : v === 2 ? "بطاقتين" : "بطاقات"}`;
      };
      range.addEventListener("input", upd);
      const quick = body.querySelector(".reinsert-quick");
      for (const [txt, v] of [["أعلى", 0], ["وسط", Math.floor(max / 2)], ["أسفل", max], ["عشوائي", -1]]) {
        const b = el("button", "chip", txt);
        b.addEventListener("click", () => { audio.play("tick"); range.value = v < 0 ? Math.floor(Math.random() * (max + 1)) : v; upd(); });
        quick.append(b);
      }
      upd();
      const confirm = el("button", "control-btn primary", `${icon("check")}<span class="control-label">أخفها هنا</span>`);
      confirm.addEventListener("click", () => { closeSheet(); ctl().answer({ kind: "reinsert", position: Number(range.value) }); });
      openSheet(key, "نجوت! أين تخفي وافقري؟", `اختر موضعها سرًا في الكومة (${max} بطاقة)`, body, [confirm]);
    }
  }

  function hidePrompt() {
    if (sheetKey && sheetKey !== "target" && sheetKey !== "name") closeSheet();
  }

  // ---- reactions -------------------------------------------------------------
  let reactionKey = null;
  function showReaction(match, info) {
    reactionBar.hidden = false;
    reactionTimerBar.style.transform = `scaleX(${info.left})`;
    const pending = match.pending;
    const eff = pending.type === "nafs" ? pending.copyOf : pending.type;
    const actor = match.players[pending.actor];
    const tgt = pending.target !== null ? match.players[pending.target] : null;
    reactionPending.textContent = `${actor.name}: ${CARD_INFO[eff].name}${tgt ? ` ← ${tgt.name}` : ""}${pending.cancelled ? " (ملغاة)" : ""}`;
    const key = `${match.reaction.round}:${info.mode}:${(info.options || []).map((o) => o.cardId).join()}`;
    if (key === reactionKey) return;
    reactionKey = key;
    reactionActions.replaceChildren();
    if (info.mode === "friends") {
      const eligible = match.players.filter((p) => !p.isAI && p.alive && pending && (pending.chain.length ? pending.chain[pending.chain.length - 1].player : pending.actor) !== p.id);
      for (const p of eligible) {
        const b = el("button", "control-btn react-who", `<span class="seat-avatar" style="background-image:url('${charUrl(p.avatar)}')"></span><span class="control-label">${esc(p.name)}</span>`);
        b.addEventListener("click", () => { audio.play("tick"); ctl().friendWantsToReact(p.id); });
        reactionActions.append(b);
      }
      const none = el("button", "control-btn ghost", `${icon("skip")}<span class="control-label">لا أحد</span>`);
      none.addEventListener("click", () => { audio.play("tick"); ctl().closeReactions(); });
      reactionActions.append(none);
      return;
    }
    const seen = new Set();
    for (const o of info.options || []) {
      if (seen.has(o.type)) continue; // one button per reaction type
      seen.add(o.type);
      reactionActions.append(reactionButton(match, info.viewer, o));
    }
    if (!(info.options || []).length) return;
    const pass = el("button", "control-btn ghost", `${icon("skip")}<span class="control-label">تخطَّ</span>`);
    pass.addEventListener("click", () => { audio.play("tick"); ctl().passReaction(info.viewer); hideReaction(); });
    reactionActions.append(pass);
  }

  function reactionButton(match, player, o, after) {
    const b = el("button", `control-btn react-btn ${o.type}`, `${cardThumb(o.type, "tiny")}<span class="control-label">${CARD_INFO[o.type].name}</span>`);
    b.addEventListener("click", () => {
      audio.play("tick");
      if (o.type === "sawbna" && o.targets.length) {
        startTargeting(o.targets, "صوبنا", (t) => { ctl().react(player, o.cardId, t); after?.(); });
      } else {
        ctl().react(player, o.cardId);
        after?.();
      }
      hideReaction();
    });
    return b;
  }

  function hideReaction() {
    reactionBar.hidden = true;
    reactionKey = null;
  }

  function showPrivateReaction(match, id, options, done) {
    const body = el("div", "react-private");
    if (!options.length) body.innerHTML = `<p class="muted">ليس معك هجع أو صوبنا الآن.</p>`;
    const row = el("div", "reorder-row");
    for (const o of options) row.append(reactionButton(match, id, o, () => { closeSheet(); done(); }));
    body.append(row);
    const back = el("button", "control-btn ghost", `<span class="control-label">رجوع</span>`);
    back.addEventListener("click", () => { audio.play("tick"); closeSheet(); done(); });
    openSheet(`private-react:${id}`, `${match.players[id].name}: رد الفعل`, "اختر بطاقة رد", body, [back]);
  }

  // ---- handoff -----------------------------------------------------------
  function showHandoff(player, cb) {
    cancelTargeting();
    closeSheet();
    handoffCb = cb;
    cover.hidden = false;
    cover.querySelector(".handoff-name").textContent = player.name;
    cover.querySelector(".handoff-avatar").style.backgroundImage = `url('${charUrl(player.avatar)}')`;
  }

  // ---- bubbles & effects ---------------------------------------------------
  function bubble(actor, text, tone = "card") {
    const b = el("div", `bubble ${tone}`, esc(text));
    bubbleLayer.append(b);
    bubbles.push({ b, actor, t: 0, life: 1.9 });
  }
  function bubbleAtSeat(id, text, tone = "card") {
    const b = el("div", `bubble ${tone}`, esc(text));
    bubbleLayer.append(b);
    bubbles.push({ b, seat: id, t: 0, life: 1.8 });
  }
  function floatAtSeat(id, text, tone = "debt") {
    const b = el("div", `float-text ${tone}`, esc(text));
    bubbleLayer.append(b);
    floats.push({ b, seat: id, t: 0, life: 1.8 });
  }
  function doFlash(color) {
    flash.style.background = color;
    flashT = 1;
  }
  function doStamp(text, color) {
    stamp.textContent = text;
    stamp.className = `stamp ${color}`;
    stampT = 1.3;
  }

  function announceTurn(ev) {
    const m = ctl().match;
    if (!m) return;
    const p = m.players[ev.player];
    const mine = !p.isAI && (ctl().config.mode !== "friends" || ev.player === viewerRef);
    const debtTxt = ev.debt > 1 ? ` · ${ev.debt} حركات` : "";
    if (ev.continued) {
      showBanner(mine ? `حركة أخرى${debtTxt}` : `${p.name}: حركة أخرى`, 0.9);
      return;
    }
    if (ctl().config.mode === "friends" && !p.isAI) showBanner(`دور ${p.name}${debtTxt}`, 1.2);
    else if (mine) {
      showBanner(`دورك!${debtTxt}`, 1.2);
      audio.play("turn");
    }
  }
  function showBanner(text, life = 1.2) {
    bannerText.textContent = text;
    banner.hidden = false;
    bannerT = life;
    banner.classList.remove("in");
    void banner.offsetWidth;
    banner.classList.add("in");
  }

  // ---- per-frame -----------------------------------------------------------
  const sp = { x: 0, y: 0, behind: false };
  function update(dt) {
    const m = ctl().match;
    const snap = table.snapshot;
    if (m && snap) {
      deckCount.textContent = snap.deck.length;
      const turnP = m.players[snap.turn];
      const mineTurn = turnP && !turnP.isAI && (ctl().config.mode !== "friends" ? true : snap.turn === viewerRef && ctl().facesShown);
      turnText.textContent = turnP ? (mineTurn ? "دورك" : `دور ${turnP.name}`) : "—";
      turnDot.classList.toggle("mine", Boolean(mineTurn));
      // Seat badges follow the 3D seats.
      for (const [id, s] of seatEls) {
        worldToScreen(table.seatWorld(id), sp);
        s.style.transform = `translate(${sp.x}px, ${sp.y}px) translate(-50%, -50%)`;
        s.querySelector(".seat-cards b").textContent = snap.hands[id].length;
        s.classList.toggle("out", !snap.alive[id]);
        s.classList.toggle("active", snap.turn === id);
        s.classList.toggle("marked", marks.has(id));
        const debt = s.querySelector(".seat-debt");
        const owes = snap.turn === id && snap.debt > 1;
        debt.hidden = !owes;
        if (owes) debt.textContent = `×${snap.debt}`;
        s.classList.toggle("ai", m.players[id].isAI);
      }
      const owes = snap.turn === viewerRef && snap.debt > 1;
      meDebt.hidden = !owes;
      if (owes) meDebt.textContent = `×${snap.debt}`;
    }
    for (let i = bubbles.length - 1; i >= 0; i--) {
      const q = bubbles[i];
      q.t += dt;
      let pos;
      if (q.actor) pos = q.actor.root.position.clone().add(new THREE.Vector3(0, q.actor.height * q.actor.root.scale.y + 0.25, 0));
      else pos = table.seatWorld(q.seat).clone().add(new THREE.Vector3(0, 0.9, 0));
      worldToScreen(pos, sp);
      const k = q.t / q.life;
      const scale = k < 0.12 ? 0.6 + (k / 0.12) * 0.4 : 1;
      q.b.style.transform = `translate(${sp.x}px, ${sp.y}px) translate(-50%, -100%) scale(${scale})`;
      q.b.style.opacity = k > 0.8 ? (1 - k) / 0.2 : 1;
      if (q.t >= q.life) { q.b.remove(); bubbles.splice(i, 1); }
    }
    for (let i = floats.length - 1; i >= 0; i--) {
      const q = floats[i];
      q.t += dt;
      worldToScreen(table.seatWorld(q.seat).clone().add(new THREE.Vector3(0, 1.1 + q.t * 0.6, 0)), sp);
      const k = q.t / q.life;
      q.b.style.transform = `translate(${sp.x}px, ${sp.y}px) translate(-50%, -50%) scale(${1 + Math.sin(Math.min(1, k * 4) * Math.PI) * 0.4})`;
      q.b.style.opacity = k > 0.7 ? (1 - k) / 0.3 : 1;
      if (q.t >= q.life) { q.b.remove(); floats.splice(i, 1); }
    }
    if (flashT > 0) { flashT = Math.max(0, flashT - dt * 2.5); flash.style.opacity = flashT; }
    vignetteT += dt;
    vignette.style.opacity = vignetteOn ? 0.55 + Math.sin(vignetteT * 9) * 0.3 : Math.max(0, Number(vignette.style.opacity || 0) - dt * 2);
    if (stampT > 0) {
      stampT = Math.max(0, stampT - dt);
      const k = 1.3 - stampT;
      stamp.style.opacity = stampT < 0.3 ? stampT / 0.3 : 1;
      stamp.style.transform = `translate(-50%, -50%) rotate(-12deg) scale(${k < 0.15 ? 2.2 - (k / 0.15) * 1.2 : 1})`;
      stamp.hidden = stampT <= 0;
    }
    if (bannerT > 0) {
      bannerT -= dt;
      if (bannerT <= 0) banner.hidden = true;
    }
    drawBtn.disabled = !inputEnabled;
    drawBtn.classList.toggle("ready", inputEnabled);
  }

  return {
    update,
    setupSeats,
    select,
    playSelected: () => tryPlaySelected(),
    refreshCardInfo,
    setInputEnabled(on, info) {
      const was = inputEnabled;
      inputEnabled = on;
      if (info?.plays) plays = info.plays;
      if (!on) { plays = []; cancelTargeting(); }
      if (was !== on || info) refreshCardInfo();
    },
    showPrompt,
    hidePrompt,
    showReaction,
    hideReaction,
    showPrivateReaction,
    showHandoff,
    hideAllPrompts() { closeSheet(); hideReaction(); cover.hidden = true; cancelTargeting(); },
    resetMatch() {
      closeSheet(); hideReaction(); cover.hidden = true; handoffCb = null;
      for (const q of bubbles) q.b.remove();
      for (const q of floats) q.b.remove();
      bubbles.length = 0; floats.length = 0;
      seatsLayer.replaceChildren(); seatEls.clear(); marks.clear();
      vignetteOn = false; banner.hidden = true; stamp.hidden = true;
      inputEnabled = false; plays = [];
      table.setSelected(null);
      refreshCardInfo();
    },
    onEvents() {},
    bubble,
    bubbleAtSeat,
    floatAtSeat,
    flash: doFlash,
    stamp: doStamp,
    vignette(on) { vignetteOn = on; },
    markTarget(id) { marks.add(id); },
    clearMarks() { marks.clear(); },
    announceTurn,
    showBanner,
    setVisible(v) {
      hud.hidden = !v;
      seatsLayer.hidden = !v;
      bubbleLayer.hidden = !v;
    },
    get targeting() { return Boolean(targeting); },
    hudEl: hud,
    seatEls,
  };
}
