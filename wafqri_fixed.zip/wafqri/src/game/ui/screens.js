// Out-of-match screens: intro, main menu, match setup (computer / friends),
// how to play, card gallery, settings, pause and the victory screen.

import { CARD_INFO } from "../rules/cards.js";
import { el, esc, icon } from "./dom.js";

export const AVATARS = [16, 13, 2, 5, 7, 11, 3, 10, 9, 14, 15, 17, 12, 6, 8, 4, 18];
const AI_NAMES = ["سالم", "مريم", "حمد", "شيخة", "خالد", "عائشة", "سعيد", "نورة", "مبارك", "ريّا"];
const DIFF = { easy: "سهل", medium: "متوسط", hard: "صعب" };
const PLAYABLE_ORDER = ["wafqari", "batran", "kafkha", "habsh", "hajaa", "sawbna", "salifni", "saqib", "tajammal", "baser", "ayyar", "khabs", "shawwah", "salakhni", "mbartam", "nafs", "shima"];

export function createScreens({ root, textures, audio, store, onStart, onResume, onQuit, onSettings, onScreen }) {
  const charUrl = (art) => textures.charUrl[art];
  const cardUrl = (type) => textures.cardUrl[CARD_INFO[type].art];
  const backUrl = textures.cardUrl[1];
  let current = null;
  let introT = 0;
  let introDone = false;
  let lastConfig = null;

  const wrap = el("div", "screens");
  root.append(wrap);
  const screens = {};

  function screen(name, cls = "") {
    const s = el("section", `screen ${cls}`);
    s.dataset.screen = name;
    s.hidden = true;
    wrap.append(s);
    screens[name] = s;
    return s;
  }

  function show(name) {
    for (const [n, s] of Object.entries(screens)) s.hidden = n !== name;
    current = name;
    wrap.classList.toggle("open", Boolean(name));
    if (name === "menu") renderMenu();
    if (name === "settings") renderSettings();
    if (name === "setupAi") renderSetupAi();
    if (name === "setupFriends") renderSetupFriends();
    onScreen?.(name);
  }

  const btn = (label, ic, cls = "") => el("button", `control-btn menu-btn ${cls}`, `${ic ? icon(ic) : ""}<span class="control-label">${label}</span>`);
  const backBtn = (to = "menu") => {
    const b = el("button", "control-btn icon-btn back-btn", icon("back"));
    b.setAttribute("aria-label", "رجوع");
    b.addEventListener("click", () => { audio.play("tick"); show(to); });
    return b;
  };
  const header = (title, to) => {
    const h = el("div", "screen-head");
    h.append(backBtn(to), el("h2", "", esc(title)));
    return h;
  };

  // ---- Intro -------------------------------------------------------------
  const intro = screen("intro", "intro");
  intro.innerHTML = `
    <div class="intro-black"></div>
    <div class="logo">
      <img class="logo-card" src="${backUrl}" alt="">
      <div class="logo-title">وافقري</div>
      <div class="logo-sub">WAFQARI 3D</div>
    </div>
    <div class="credit">من إبداع <b>زكريا جمعه الخالدي</b></div>
    <div class="tap-hint">اضغط للمتابعة</div>`;
  intro.addEventListener("click", () => finishIntro());

  function finishIntro() {
    if (introDone) return;
    introDone = true;
    audio.unlock();
    audio.play("sting");
    audio.playMusic("menu");
    show("menu");
  }

  // ---- Menu ----------------------------------------------------------------
  const menu = screen("menu", "menu");
  function renderMenu() {
    const r = store.record;
    menu.innerHTML = `
      <div class="menu-logo">
        <div class="logo-title small">وافقري</div>
        <div class="logo-sub">WAFQARI 3D</div>
      </div>
      <div class="menu-list"></div>
      <div class="menu-foot">
        <span class="record">${icon("bolt")} انتصارات: ${r.wins.easy + r.wins.medium + r.wins.hard} · نجاة من وافقري: ${r.wafqariSurvived}</span>
        <span class="credit small">من إبداع زكريا جمعه الخالدي</span>
      </div>`;
    const list = menu.querySelector(".menu-list");
    const items = [
      ["العب الآن", "play", "primary big", () => quickPlay()],
      ["اللعب ضد الكمبيوتر", "bot", "", () => show("setupAi")],
      ["اللعب مع الأصدقاء", "users", "", () => show("setupFriends")],
      ["طريقة اللعب", "book", "", () => { slide = 0; renderRules(); show("rules"); }],
      ["شرح البطاقات", "cards", "", () => { renderGallery(); show("gallery"); }],
      ["الإعدادات", "gear", "", () => { settingsBack = "menu"; show("settings"); }],
    ];
    for (const [label, ic, cls, fn] of items) {
      const b = btn(label, ic, cls);
      b.addEventListener("click", () => { audio.unlock(); audio.play("tick"); fn(); });
      list.append(b);
    }
  }

  function quickPlay() {
    const name = store.profile.name || "أنت";
    start({
      mode: "ai",
      players: [
        { name, avatar: store.profile.avatar, isAI: false },
        ...pickAiPlayers(3, "medium", [store.profile.avatar]),
      ],
    });
  }

  function pickAiPlayers(n, difficulty, used) {
    const avatars = AVATARS.filter((a) => !used.includes(a) && a !== 18 && a !== 4);
    const names = AI_NAMES.slice().sort(() => Math.random() - 0.5);
    return Array.from({ length: n }, (_, i) => ({ name: names[i], avatar: avatars[(i * 3 + Math.floor(Math.random() * 3)) % avatars.length], isAI: true, difficulty }));
  }

  function start(cfg) {
    lastConfig = cfg;
    audio.unlock();
    show(null);
    onStart(cfg);
  }

  // ---- Setup vs computer -----------------------------------------------------
  const setupAi = screen("setupAi", "panel-screen");
  const aiState = { count: 3, difficulty: "medium" };
  function renderSetupAi() {
    setupAi.replaceChildren(header("اللعب ضد الكمبيوتر"));
    const body = el("div", "panel");
    body.innerHTML = `
      <label class="field"><span>اسمك</span><input class="name-input" maxlength="12" value="${esc(store.profile.name || "أنت")}"></label>
      <div class="field"><span>صورتك</span><div class="avatar-row"></div></div>
      <div class="field"><span>عدد الخصوم</span><div class="stepper"><button class="control-btn icon-btn" data-d="-1">${icon("minus")}</button><b class="count"></b><button class="control-btn icon-btn" data-d="1">${icon("plus")}</button></div></div>
      <div class="opp-preview"></div>
      <div class="field"><span>الصعوبة</span><div class="segmented diff"></div></div>`;
    const row = body.querySelector(".avatar-row");
    for (const a of AVATARS) {
      const b = el("button", `avatar-pick ${a === store.profile.avatar ? "on" : ""}`);
      b.style.backgroundImage = `url('${charUrl(a)}')`;
      b.setAttribute("aria-label", CARD_INFO[Object.keys(CARD_INFO).find((k) => CARD_INFO[k].art === a)].name);
      b.addEventListener("click", () => { audio.play("tick"); store.profile.avatar = a; store.save(); renderSetupAi(); });
      row.append(b);
    }
    body.querySelector(".name-input").addEventListener("change", (e) => { store.profile.name = e.target.value.trim().slice(0, 12) || "أنت"; store.save(); });
    body.querySelector(".count").textContent = aiState.count;
    body.querySelectorAll(".stepper button").forEach((b) => b.addEventListener("click", () => {
      audio.play("tick");
      aiState.count = Math.max(1, Math.min(5, aiState.count + Number(b.dataset.d)));
      renderSetupAi();
    }));
    const prev = body.querySelector(".opp-preview");
    for (let i = 0; i < aiState.count; i++) prev.append(el("span", "seat-avatar", ""));
    const seg = body.querySelector(".diff");
    for (const [k, label] of Object.entries(DIFF)) {
      const b = el("button", `seg ${aiState.difficulty === k ? "on" : ""}`, label);
      b.addEventListener("click", () => { audio.play("tick"); aiState.difficulty = k; renderSetupAi(); });
      seg.append(b);
    }
    const go = btn("ابدأ المباراة", "play", "primary big");
    go.addEventListener("click", () => {
      audio.play("tick");
      const name = body.querySelector(".name-input").value.trim().slice(0, 12) || "أنت";
      store.profile.name = name;
      store.save();
      const ais = pickAiPlayers(aiState.count, aiState.difficulty, [store.profile.avatar]);
      prev.querySelectorAll(".seat-avatar").forEach((s, i) => { s.style.backgroundImage = `url('${charUrl(ais[i].avatar)}')`; });
      start({ mode: "ai", difficulty: aiState.difficulty, players: [{ name, avatar: store.profile.avatar, isAI: false }, ...ais] });
    });
    body.append(go);
    setupAi.append(body);
  }

  // ---- Setup friends (pass the phone) ----------------------------------------
  const setupFriends = screen("setupFriends", "panel-screen");
  const friends = {
    seats: [
      { name: "لاعب ١", avatar: 16, isAI: false, difficulty: "medium" },
      { name: "لاعب ٢", avatar: 13, isAI: false, difficulty: "medium" },
      { name: "لاعب ٣", avatar: 2, isAI: false, difficulty: "medium" },
    ],
  };
  function renderSetupFriends() {
    setupFriends.replaceChildren(header("اللعب مع الأصدقاء"));
    const body = el("div", "panel");
    body.innerHTML = `
      <p class="muted">جهاز واحد يُمرَّر بين اللاعبين. تظهر شاشة تغطية قبل كل دور حتى تبقى البطاقات سرية.</p>
      <div class="field"><span>عدد اللاعبين</span><div class="stepper"><button class="control-btn icon-btn" data-d="-1">${icon("minus")}</button><b class="count">${friends.seats.length}</b><button class="control-btn icon-btn" data-d="1">${icon("plus")}</button></div></div>
      <div class="seat-list"></div>`;
    body.querySelectorAll(".stepper button").forEach((b) => b.addEventListener("click", () => {
      audio.play("tick");
      const n = Math.max(2, Math.min(6, friends.seats.length + Number(b.dataset.d)));
      while (friends.seats.length < n) {
        const used = friends.seats.map((s) => s.avatar);
        friends.seats.push({ name: `لاعب ${(friends.seats.length + 1).toLocaleString("ar-EG")}`, avatar: AVATARS.find((a) => !used.includes(a)), isAI: false, difficulty: "medium" });
      }
      friends.seats.length = n;
      renderSetupFriends();
    }));
    const list = body.querySelector(".seat-list");
    friends.seats.forEach((s, i) => {
      const row = el("div", "seat-row");
      const av = el("button", "avatar-pick on");
      av.style.backgroundImage = `url('${charUrl(s.avatar)}')`;
      av.setAttribute("aria-label", "تغيير الصورة");
      av.addEventListener("click", () => {
        audio.play("tick");
        const used = friends.seats.map((x) => x.avatar);
        let idx = AVATARS.indexOf(s.avatar);
        for (let k = 0; k < AVATARS.length; k++) {
          idx = (idx + 1) % AVATARS.length;
          if (!used.includes(AVATARS[idx])) break;
        }
        s.avatar = AVATARS[idx];
        renderSetupFriends();
      });
      const name = el("input", "name-input");
      name.maxLength = 12;
      name.value = s.isAI ? `${s.name}` : s.name;
      name.addEventListener("change", () => { s.name = name.value.trim().slice(0, 12) || `لاعب ${i + 1}`; });
      const kind = el("button", `chip ${s.isAI ? "ai" : ""}`, s.isAI ? `${icon("bot")} ${DIFF[s.difficulty]}` : `${icon("hand")} إنسان`);
      kind.addEventListener("click", () => {
        audio.play("tick");
        if (!s.isAI) { s.isAI = true; s.difficulty = "easy"; }
        else if (s.difficulty === "easy") s.difficulty = "medium";
        else if (s.difficulty === "medium") s.difficulty = "hard";
        else s.isAI = false;
        renderSetupFriends();
      });
      row.append(av, name, kind);
      list.append(row);
    });
    const humans = friends.seats.filter((s) => !s.isAI).length;
    const go = btn("ابدأ المباراة", "play", "primary big");
    go.disabled = humans < 1;
    const note = el("p", "muted small", humans < 1 ? "يلزم لاعب واحد على الأقل." : `${humans} ${humans === 1 ? "لاعب" : "لاعبين"} على الجهاز${friends.seats.length - humans ? ` + ${friends.seats.length - humans} كمبيوتر` : ""}`);
    go.addEventListener("click", () => {
      audio.play("tick");
      start({ mode: "friends", players: friends.seats.map((s) => ({ ...s, name: s.name || "لاعب" })) });
    });
    body.append(note, go);
    setupFriends.append(body);
  }

  // ---- How to play ---------------------------------------------------------
  const rules = screen("rules", "panel-screen");
  let slide = 0;
  const SLIDES = [
    { art: "wafqari", title: "الهدف", text: "كن آخر لاعب يبقى على الطاولة. من يسحب وافقري بلا بطران يخرج من اللعبة. إفراغ يدك لا يعني الفوز." },
    { art: "kafkha", title: "دورك: حركة واحدة", text: "إما أن تلعب بطاقة واحدة أو تسحب بطاقة واحدة، ثم ينتقل الدور تلقائيًا. كفخة تُجبر خصمك على حركتين، وتتراكم ٤، ٦، ٨…" },
    { art: "batran", title: "البطران", text: "تبدأ بواحد. عند سحب وافقري يُستهلك البطران، ثم تعيد وافقري سرًا إلى أي موضع تختاره في الكومة." },
    { art: "hajaa", title: "ردود الفعل", text: "بعد كل بطاقة يظهر عدّاد قصير. هجع يلغي الحركة، وهجع ثانٍ يعيدها. صوبنا تستولي على الحركة وتوجهها لصالحك." },
    { art: "baser", title: "المعلومة سلاح", text: "باصر يكشف أعلى ٣ بطاقات للجميع، والعيار يريك إياها سرًا لترتبها. كلما صغرت الكومة زاد خطر وافقري." },
  ];
  function renderRules() {
    const s = SLIDES[slide];
    rules.replaceChildren(header("طريقة اللعب"));
    const body = el("div", "panel slide");
    body.innerHTML = `
      <div class="slide-art"><img src="${cardUrl(s.art)}" alt="${esc(CARD_INFO[s.art].name)}"></div>
      <h3>${esc(s.title)}</h3><p>${esc(s.text)}</p>
      <div class="dots">${SLIDES.map((_, i) => `<i class="${i === slide ? "on" : ""}"></i>`).join("")}</div>`;
    const nav = el("div", "slide-nav");
    const prev = btn("السابق", "", "ghost");
    prev.disabled = slide === 0;
    prev.addEventListener("click", () => { audio.play("tick"); slide--; renderRules(); });
    const next = btn(slide === SLIDES.length - 1 ? "فهمت" : "التالي", "", "primary");
    next.addEventListener("click", () => {
      audio.play("tick");
      if (slide === SLIDES.length - 1) show("menu");
      else { slide++; renderRules(); }
    });
    nav.append(prev, next);
    body.append(nav);
    rules.append(body);
  }

  // ---- Card gallery ----------------------------------------------------------
  const gallery = screen("gallery", "panel-screen");
  function renderGallery(focus) {
    gallery.replaceChildren(header("شرح البطاقات"));
    const body = el("div", "panel");
    if (focus) {
      const info = CARD_INFO[focus];
      body.innerHTML = `
        <div class="card3d-stage"><div class="card3d"><img class="face" src="${cardUrl(focus)}" alt="${esc(info.name)}"><img class="back" src="${backUrl}" alt=""></div></div>
        <h3 class="center">${esc(info.name)}</h3><p class="center">${esc(info.rule)}</p>`;
      const stage = body.querySelector(".card3d-stage");
      const card = body.querySelector(".card3d");
      let drag = null;
      stage.addEventListener("pointerdown", (e) => { drag = { x: e.clientX, r: Number(card.dataset.r || 0) }; stage.setPointerCapture(e.pointerId); card.classList.add("dragging"); });
      stage.addEventListener("pointermove", (e) => { if (!drag) return; const r = drag.r + (e.clientX - drag.x) * 0.8; card.dataset.r = r; card.style.setProperty("--ry", `${r}deg`); });
      stage.addEventListener("pointerup", () => { drag = null; card.classList.remove("dragging"); });
      const back = btn("كل البطاقات", "cards", "ghost");
      back.addEventListener("click", () => { audio.play("tick"); renderGallery(); });
      body.append(back);
    } else {
      const grid = el("div", "card-grid gallery-grid");
      for (const t of PLAYABLE_ORDER) {
        const b = el("button", "grid-card", `<span class="thumb"><img src="${cardUrl(t)}" alt="" draggable="false"></span><span class="grid-name">${esc(CARD_INFO[t].name)}</span>`);
        b.addEventListener("click", () => { audio.play("tick"); renderGallery(t); });
        grid.append(b);
      }
      body.append(grid);
    }
    gallery.append(body);
  }

  // ---- Settings --------------------------------------------------------------
  const settingsScreen = screen("settings", "panel-screen");
  let settingsBack = "menu";
  function renderSettings() {
    const s = store.settings;
    settingsScreen.replaceChildren(header("الإعدادات", settingsBack));
    const body = el("div", "panel");
    body.innerHTML = `
      <label class="field"><span>الموسيقى</span><input type="range" min="0" max="1" step="0.05" data-k="music" value="${s.music}" dir="ltr"></label>
      <label class="field"><span>المؤثرات</span><input type="range" min="0" max="1" step="0.05" data-k="sfx" value="${s.sfx}" dir="ltr"></label>
      <div class="field"><span>كتم الصوت</span><button class="toggle ${s.muted ? "on" : ""}" data-t="muted" role="switch" aria-checked="${s.muted}"><i></i></button></div>
      <div class="field"><span>الرسوميات</span><div class="segmented" data-seg="quality"></div></div>
      <div class="field"><span>تقليل الحركة</span><button class="toggle ${s.reducedMotion ? "on" : ""}" data-t="reducedMotion" role="switch" aria-checked="${s.reducedMotion}"><i></i></button></div>
      <div class="field"><span>سرعة المؤثرات</span><div class="segmented" data-seg="cinematicSpeed"></div></div>
      <div class="field"><span>مهلة رد الفعل</span><div class="segmented" data-seg="reactionScale"></div></div>`;
    body.querySelectorAll("input[type=range]").forEach((r) => r.addEventListener("input", () => { s[r.dataset.k] = Number(r.value); onSettings(); }));
    body.querySelectorAll(".toggle").forEach((t) => t.addEventListener("click", () => {
      audio.play("tick");
      s[t.dataset.t] = !s[t.dataset.t];
      onSettings();
      renderSettings();
    }));
    const segs = {
      quality: [["high", "عالية"], ["medium", "متوسطة"], ["low", "منخفضة"]],
      cinematicSpeed: [[1, "عادية"], [1.8, "سريعة"]],
      reactionScale: [[0.7, "قصيرة"], [1, "عادية"], [1.6, "طويلة"]],
    };
    for (const [key, opts] of Object.entries(segs)) {
      const seg = body.querySelector(`[data-seg=${key}]`);
      for (const [v, label] of opts) {
        const b = el("button", `seg ${s[key] === v ? "on" : ""}`, label);
        b.addEventListener("click", () => { audio.play("tick"); s[key] = v; onSettings(); renderSettings(); });
        seg.append(b);
      }
    }
    settingsScreen.append(body);
  }

  // ---- Pause -----------------------------------------------------------------
  const pause = screen("pause", "panel-screen dim");
  pause.innerHTML = `<div class="panel compact"><h2 class="center">استراحة</h2><div class="menu-list"></div></div>`;
  {
    const list = pause.querySelector(".menu-list");
    const items = [
      ["متابعة", "play", "primary", () => { show(null); onResume(); }],
      ["الإعدادات", "gear", "", () => { settingsBack = "pause"; show("settings"); }],
      ["طريقة اللعب", "book", "", () => { slide = 0; renderRules(); show("rules"); }],
      ["القائمة الرئيسية", "home", "ghost", () => { onQuit(); show("menu"); audio.playMusic("menu"); }],
    ];
    for (const [label, ic, cls, fn] of items) {
      const b = btn(label, ic, cls);
      b.addEventListener("click", () => { audio.play("tick"); fn(); });
      list.append(b);
    }
  }

  // ---- Victory ---------------------------------------------------------------
  const victory = screen("victory", "panel-screen dim victory");
  function showVictory(match, cfg) {
    const w = match.players[match.winner];
    const order = [...match.eliminated].reverse();
    victory.innerHTML = `
      <div class="panel compact">
        <div class="win-avatar" style="background-image:url('${charUrl(w.avatar)}')"></div>
        <h2 class="center win-title">${esc(w.name)} فاز!</h2>
        <p class="center muted">آخر الناجين على الطاولة · ${match.turnCount} دورًا</p>
        <div class="stats"><div class="stats-head"><span></span><span>لعب</span><span>سحب</span><span>نجا</span><span>كفخة</span></div>
          ${[match.winner, ...order].map((id, i) => {
            const p = match.players[id];
            return `<div class="stats-row ${i === 0 ? "win" : ""}"><span class="who"><i class="seat-avatar" style="background-image:url('${charUrl(p.avatar)}')"></i>${i + 1}. ${esc(p.name)}</span><span>${p.stats.played}</span><span>${p.stats.drawn}</span><span>${p.stats.survived}</span><span>${p.stats.kafkhaLanded}</span></div>`;
          }).join("")}
        </div>
        <div class="menu-list row"></div>
      </div>`;
    const list = victory.querySelector(".menu-list");
    const again = btn("العب مجددًا", "redo", "primary");
    again.addEventListener("click", () => {
      audio.play("tick");
      // Same setup, new seating and deal.
      const players = cfg.players.map((p) => ({ name: p.name, avatar: p.avatar, isAI: p.isAI, difficulty: p.difficulty }));
      const humansFirst = cfg.mode === "ai" ? [players[0], ...players.slice(1).sort(() => Math.random() - 0.5)] : players.sort(() => Math.random() - 0.5);
      start({ ...cfg, players: humansFirst });
    });
    const rematch = btn("إعادة", "users", "");
    rematch.addEventListener("click", () => { audio.play("tick"); start({ ...cfg }); });
    const home = btn("القائمة الرئيسية", "home", "ghost");
    home.addEventListener("click", () => { audio.play("tick"); onQuit(); show("menu"); audio.playMusic("menu"); });
    list.append(again, rematch, home);
    show("victory");
  }

  // ---- Loading / error -------------------------------------------------------
  const loading = screen("loading", "loading");
  loading.innerHTML = `<div class="loader"><div class="logo-title small">وافقري</div><div class="bar"><i></i></div><div class="load-text">تحميل البطاقات الأصلية…</div></div>`;

  function setProgress(k) {
    loading.querySelector(".bar i").style.transform = `scaleX(${k})`;
  }
  function showError(msg) {
    loading.innerHTML = `<div class="loader"><div class="logo-title small">وافقري</div><p class="error">تعذّر تحميل صور البطاقات الأصلية: <b dir="ltr">${esc(msg)}</b></p><button class="control-btn primary retry"><span class="control-label">إعادة المحاولة</span></button></div>`;
    loading.querySelector(".retry").addEventListener("click", () => location.reload());
    show("loading");
  }

  return {
    show,
    get current() { return current; },
    showVictory,
    setProgress,
    showError,
    startIntro() { introT = 0; introDone = false; show("intro"); },
    update(dt) {
      if (current === "intro") {
        introT += dt;
        intro.style.setProperty("--k", Math.min(1, introT / 3));
        intro.classList.toggle("s1", introT > 0.4);
        intro.classList.toggle("s2", introT > 1.4);
        intro.classList.toggle("s3", introT > 2.4);
        intro.classList.toggle("s4", introT > 3.2);
      }
    },
    get introDone() { return introDone; },
    get lastConfig() { return lastConfig; },
    finishIntro,
  };
}
