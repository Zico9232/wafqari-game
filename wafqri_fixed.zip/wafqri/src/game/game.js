// WAFQARI 3D — composition root. Builds the 3D majlis, the rules
// controller, the presenter and the interface, and drives them from the SDK
// loop: update(dt) advances everything, render() only draws.
//
//   rules/      pure rules engine + AI (no DOM, tested headless)
//   view/       Three.js table, cards, characters, effects, camera
//   present/    event → cinematic playback
//   ui/         DOM screens and HUD
//   controller  match flow (turns, reactions, prompts, pass-the-phone)

import * as THREE from "three";
import { createAudio } from "./audio.js";
import { createController } from "./controller.js";
import { createPresenter } from "./present/presenter.js";
import { CARD_INFO } from "./rules/cards.js";
import { createStore } from "./store.js";
import { createHud } from "./ui/hud.js";
import { createScreens } from "./ui/screens.js";
import { createCameraRig } from "./view/cameraRig.js";
import { createCardMesh } from "./view/cardMesh.js";
import { setWaveScale } from "./view/character.js";
import { createFx } from "./view/fx.js";
import { applyQuality, createScene, QUALITY } from "./view/scene.js";
import { createTableView } from "./view/tableView.js";
import { loadTextures } from "./view/textures.js";

export function createGame({ mount, sdk, tweaks, assets }) {
  // Plain JSON the SDK passes to every hook and the Creator Tools read.
  const state = { loaded: false, screen: "loading", phase: null, turn: null, deck: 0, players: 0, alive: 0, mode: null };

  mount.classList.add("wafqari");
  const frame = document.createElement("div");
  frame.className = "frame";
  const canvasHost = document.createElement("div");
  canvasHost.className = "canvas-host";
  const ui = document.createElement("div");
  ui.className = "safe-area ui-layer";
  frame.append(canvasHost);
  mount.append(frame, ui);

  const audio = createAudio(sdk);
  let store = null;
  let parts = null; // everything built once textures are ready
  let run = null;
  const unsubs = [];

  // Loading screen is plain DOM so it shows before Three.js is ready.
  const loadingEl = document.createElement("div");
  loadingEl.className = "boot";
  loadingEl.innerHTML = `<div class="logo-title small">وافقري</div><div class="bar"><i></i></div><div class="load-text">تحميل البطاقات الأصلية…</div>`;
  ui.append(loadingEl);

  boot().catch((err) => {
    console.error("[wafqari] load failed", err);
    loadingEl.innerHTML = `<div class="logo-title small">وافقري</div><p class="error">تعذّر تحميل صور البطاقات الأصلية: <b dir="ltr">${String(err.message || err).replace(/[<>&]/g, "")}</b></p><button class="control-btn primary" onclick="location.reload()"><span class="control-label">إعادة المحاولة</span></button>`;
  });

  async function boot() {
    store = await createStore(sdk);
    const textures = await loadTextures(assets, (k) => {
      loadingEl.querySelector(".bar i").style.transform = `scaleX(${k})`;
    });
    build(textures);
    loadingEl.remove();
    state.loaded = true;
    parts.screens.startIntro();
    state.screen = "intro";
  }

  function build(textures) {
    const view = createScene(canvasHost, textures);
    const rig = createCameraRig(view.camera);
    const table = createTableView(view, textures);
    const fx = createFx(view);
    view.haptic = (pattern) => {
      try {
        if (sdk.device.haptics.isSupported()) sdk.device.haptics.vibrate(pattern);
      } catch { /* optional */ }
    };

    let controller = null;
    const hud = createHud({
      root: ui, frame, view, table, textures, audio,
      getController: () => controller,
      onMenu: () => pauseMatch(),
    });
    const settings = () => ({ ...store.settings, cinematicSpeed: store.settings.cinematicSpeed * (Number(tweaks.get("cinematicPace")) || 1) });
    const presenter = createPresenter({
      view, table, fx, audio, ui: hud, rig, textures,
      getViewer: () => controller?.viewer ?? null,
      avatarType: (id) => {
        const art = controller.match.players[id].avatar;
        return Object.keys(CARD_INFO).find((k) => CARD_INFO[k].art === art) || "batran";
      },
      settings,
    });
    controller = createController({
      presenter, table, ui: hud, audio, tweaks,
      settings: () => store.settings,
      onMatchEnd: (match, cfg) => endMatch(match, cfg),
    });
    const screens = createScreens({
      root: ui, textures, audio, store,
      onStart: (cfg) => startMatch(cfg),
      onResume: () => resumeMatch(),
      onQuit: () => quitMatch(),
      onSettings: () => { applySettings(); store.save(); },
      onScreen: (name) => {
        state.screen = name || "match";
        hud.setVisible(!name || name === "pause" || name === "victory");
      },
    });

    // Floating showcase cards for the intro and menu.
    const showcase = new THREE.Group();
    const order = Object.values(CARD_INFO).map((c) => c.art);
    order.forEach((art, i) => {
      const m = createCardMesh(art);
      m.userData.i = i;
      m.scale.setScalar(0.8);
      showcase.add(m);
    });
    view.scene.add(showcase);

    parts = { view, rig, table, fx, hud, presenter, controller, screens, showcase, textures, time: 0 };

    // --- input on the 3D table --------------------------------------------
    let down = null;
    const canvas = view.renderer.domElement;
    canvas.addEventListener("pointerdown", (e) => {
      down = { x: e.clientX, y: e.clientY };
    });
    canvas.addEventListener("pointerup", (e) => {
      if (!down) return;
      const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y);
      down = null;
      if (moved > 12) return;
      audio.unlock();
      onTableTap(e);
    });

    function onTableTap(e) {
      if (state.screen !== "match") return;
      if (!presenter.idle) {
        presenter.skip();
        return;
      }
      const r = canvas.getBoundingClientRect();
      const ndc = new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
      const hit = table.pick(ndc);
      if (!hit) {
        hud.select(null);
        table.setSelected(null);
        hud.refreshCardInfo();
        return;
      }
      if (hit.kind === "deck") {
        controller.draw();
        return;
      }
      if (hit.kind === "hand") {
        if (!controller.facesShown) return;
        audio.play("flick");
        if (table.selected === hit.cid && controller.legalFor().some((p) => p.cardId === hit.cid)) hud.playSelected();
        else hud.select(hit.cid);
      }
    }

    // --- resize: one atomic path ---------------------------------------------
    const resize = () => {
      const rect = canvasHost.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const q = QUALITY[store.settings.quality] || QUALITY.medium;
      view.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, q.dpr));
      view.renderer.setSize(rect.width, rect.height, false);
      rig.frame(rect.width / rect.height);
      view.fitBackground(rect.width / rect.height);
    };
    const ro = new ResizeObserver(resize);
    ro.observe(canvasHost);
    resize();
    parts.resize = resize;
    unsubs.push(() => ro.disconnect());

    // --- tweaks -----------------------------------------------------------------
    const applyTweaks = () => {
      rig.setHeightBias(Number(tweaks.get("cameraDistance")) || 1);
      resize();
      view.table.feltMat.color.set(String(tweaks.get("feltTint")));
      setWaveScale(Number(tweaks.get("clothRipple")));
      table.setRevealAll(Boolean(tweaks.get("showAllHands")));
      audio.setSettings({ ...store.settings, sfx: store.settings.sfx * Number(tweaks.get("masterVolume")), music: store.settings.music * Number(tweaks.get("masterVolume")) });
    };
    for (const key of ["cameraDistance", "feltTint", "clothRipple", "showAllHands", "masterVolume"]) {
      unsubs.push(tweaks.subscribe(key, applyTweaks));
    }
    applyTweaks();
    parts.applyTweaks = applyTweaks;
    applySettings();

    document.addEventListener("visibilitychange", onVisibility);
    unsubs.push(() => document.removeEventListener("visibilitychange", onVisibility));
  }

  function onVisibility() {
    audio.setPaused(document.hidden);
  }

  function applySettings() {
    if (!parts) return;
    const s = store.settings;
    const q = applyQuality(parts.view, s.quality);
    parts.fx.setBudget(q.particles);
    parts.fx.setReduced(s.reducedMotion);
    parts.rig.setReduced(s.reducedMotion);
    parts.applyTweaks?.();
    parts.resize?.();
  }

  // --- match lifecycle ---------------------------------------------------------

  function startMatch(cfg) {
    const { controller, rig, hud, fx } = parts;
    fx.clear();
    controller.start(cfg);
    rig.setMode("match");
    hud.setVisible(true);
    state.screen = "match";
    state.mode = cfg.mode;
    audio.playMusic("game");
  }

  function pauseMatch() {
    if (!parts?.controller.match) return;
    parts.controller.setPaused(true);
    parts.screens.show("pause");
  }

  function resumeMatch() {
    parts.controller.setPaused(false);
    state.screen = "match";
  }

  function quitMatch() {
    parts.controller.quit();
    parts.fx.clear();
    parts.rig.setMode("menu");
    parts.rig.release();
    state.mode = null;
  }

  function endMatch(match, cfg) {
    const r = store.record;
    r.games++;
    const human = match.players.filter((p) => !p.isAI);
    for (const p of human) r.wafqariSurvived += p.stats.survived;
    if (cfg.mode === "ai") {
      const won = match.winner === human[0]?.id;
      if (won) {
        r.wins[cfg.difficulty || "medium"]++;
        r.streak++;
        r.bestStreak = Math.max(r.bestStreak, r.streak);
      } else r.streak = 0;
      if (won) sdk.leaderboard.submit(Math.min(r.bestStreak, Number.MAX_SAFE_INTEGER)).catch(() => {});
    } else r.friendsGames++;
    store.save();
    parts.screens.showVictory(match, cfg);
  }

  // --- SDK hooks ---------------------------------------------------------------

  let firstInit = true;
  const hooks = {
    init(s) {
      // Restart from the Creator Tools: replay the current setup, or menu.
      if (firstInit) { firstInit = false; return; }
      if (!parts) return;
      const cfg = parts.screens.lastConfig;
      if (cfg && s.screen !== "menu") startMatch(cfg);
    },
    update(s, dt) {
      if (!parts) return;
      const { view, rig, table, fx, hud, presenter, controller, screens, showcase } = parts;
      parts.time += dt;
      audio.setPaused(Boolean(run?.frozen) || document.hidden);
      controller.update(dt);
      presenter.update(dt);
      rig.update(dt);
      table.update(dt);
      fx.update(dt);
      hud.update(dt);
      screens.update(dt);
      // Showcase cards orbit over the table outside matches.
      const inMatch = rig.mode === "match";
      showcase.visible = !inMatch || showcase.userData.fade > 0.01;
      showcase.userData.fade = THREE.MathUtils.damp(showcase.userData.fade ?? 1, inMatch ? 0 : 1, 3, dt);
      const t = parts.time;
      showcase.children.forEach((m, i) => {
        const a = (i / showcase.children.length) * Math.PI * 2 + t * 0.25;
        const f = showcase.userData.fade;
        m.position.set(Math.cos(a) * 2.6, 1.6 + Math.sin(t * 1.3 + i) * 0.25 + (1 - f) * 4, Math.sin(a) * 2.6);
        m.rotation.set(-0.25, -a + Math.PI / 2 + Math.sin(t + i) * 0.3, Math.sin(t * 0.8 + i) * 0.1);
        m.scale.setScalar(0.85 * f);
      });
      // Red warning light during a وافقري draw.
      view.alarm.intensity = view.alarmOn ? 40 + Math.sin(parts.time * 14) * 30 : THREE.MathUtils.damp(view.alarm.intensity, 0, 6, dt);
      // Creator Tools summary.
      const m = controller.match;
      s.phase = m?.phase ?? null;
      s.turn = m ? m.turn : null;
      s.deck = m ? m.deck.length : 0;
      s.players = m ? m.players.length : 0;
      s.alive = m ? m.players.filter((p) => p.alive).length : 0;
      s.screen = screens.current || (m ? "match" : s.screen);
    },
    render() {
      if (!parts) return;
      parts.view.renderer.render(parts.view.scene, parts.view.camera);
    },
  };

  return {
    state,
    hooks,
    setRun(r) { run = r; },
    // Named actions the Creator Tools call.
    quickMatch() {
      if (!parts) return;
      parts.screens.show(null);
      startMatch({ mode: "ai", difficulty: "medium", players: [
        { name: store.profile.name, avatar: store.profile.avatar, isAI: false },
        { name: "سالم", avatar: 13, isAI: true, difficulty: "medium" },
        { name: "مريم", avatar: 2, isAI: true, difficulty: "medium" },
        { name: "حمد", avatar: 5, isAI: true, difficulty: "medium" },
      ] });
    },
    skipCinematic() { parts?.presenter.skip(); },
    showScreen(id) {
      if (!parts) return;
      const map = { "screen:menu": "menu", "screen:intro": "intro", "screen:setup-ai": "setupAi", "screen:setup-friends": "setupFriends", "screen:rules": "rules", "screen:gallery": "gallery", "screen:settings": "settings", "screen:pause": "pause" };
      if (id === null) { parts.screens.show(null); return; }
      if (map[id]) parts.screens.show(map[id]);
    },
    currentScreen() {
      const rev = { menu: "screen:menu", intro: "screen:intro", setupAi: "screen:setup-ai", setupFriends: "screen:setup-friends", rules: "screen:rules", gallery: "screen:gallery", settings: "screen:settings", pause: "screen:pause", victory: "screen:victory" };
      return rev[parts?.screens.current] || null;
    },
    get parts() { return parts; },
    destroy() {
      for (const u of unsubs) u();
      parts?.view.renderer.dispose();
      mount.replaceChildren();
    },
  };
}
