// WAFQARI's Creator Tools vocabulary: what exists (catalog), what is on
// screen (describeScene), and what the editor may drive. Every member calls
// the game's real functions.

const rectOf = (node) => {
  const r = node?.getBoundingClientRect();
  return r && r.width ? { x: r.left, y: r.top, w: r.width, h: r.height } : null;
};

export function createDevtools({ mount, game }) {
  return {
    game: "WAFQARI 3D",

    catalog({ definition, screen, keysFor }) {
      return {
        levels: [],
        screens: [
          screen("screen:intro", "Intro", { tweakKeys: keysFor("screen:intro") }),
          screen("screen:menu", "Main menu", { tweakKeys: keysFor("screen:menu") }),
          screen("screen:setup-ai", "Play vs computer", { tweakKeys: keysFor("screen:setup-ai") }),
          screen("screen:setup-friends", "Play with friends", { tweakKeys: keysFor("screen:setup-friends") }),
          screen("screen:rules", "How to play", { tweakKeys: keysFor("screen:rules") }),
          screen("screen:gallery", "Card gallery", { tweakKeys: keysFor("screen:gallery") }),
          screen("screen:settings", "Settings", { tweakKeys: keysFor("screen:settings") }),
          screen("screen:pause", "Pause", { tweakKeys: keysFor("screen:pause") }),
          screen("screen:victory", "Victory", { tweakKeys: keysFor("screen:victory") }),
        ],
        definitions: [
          definition("def:table", "Majlis table", { tweakKeys: keysFor("def:table"), nodeKinds: ["table"], sprite: "FELT_TEXTURE", category: "world" }),
          definition("def:camera", "Table camera", { tweakKeys: keysFor("def:camera"), nodeKinds: [], category: "system" }),
          definition("def:cards", "Cards", { tweakKeys: keysFor("def:cards"), nodeKinds: [], sprite: "CARD_1", category: "world" }),
          definition("def:characters", "Card characters", { tweakKeys: keysFor("def:characters"), nodeKinds: [], sprite: "CHAR_18", category: "characters" }),
          definition("def:opponents", "Opponents", { tweakKeys: keysFor("def:opponents"), nodeKinds: ["seat"], singleton: false, category: "characters" }),
          definition("def:reaction-bar", "Reaction countdown", { tweakKeys: keysFor("def:reaction-bar"), nodeKinds: ["reaction-bar"], category: "interface" }),
          definition("def:cinematics", "Card cinematics", { tweakKeys: keysFor("def:cinematics"), nodeKinds: [], category: "effects" }),
          definition("def:hud", "Top bar", { tweakKeys: keysFor("def:hud"), nodeKinds: ["hud"], category: "interface" }),
          definition("def:action-bar", "Action bar", { tweakKeys: keysFor("def:action-bar"), nodeKinds: ["action-bar"], category: "interface" }),
        ],
      };
    },

    describeScene() {
      const nodes = [];
      const canvas = rectOf(mount.querySelector("canvas"));
      if (canvas) nodes.push({ id: "table", defId: "def:table", kind: "table", label: "Majlis table", rect: canvas, instance: {} });
      mount.querySelectorAll(".seat").forEach((s) => {
        const r = rectOf(s);
        if (r) nodes.push({ id: `seat-${s.dataset.id}`, defId: "def:opponents", kind: "seat", label: s.querySelector(".seat-name")?.textContent || "Opponent", rect: r, instance: { player: Number(s.dataset.id) } });
      });
      const top = mount.querySelector(".top-bar");
      if (top && !mount.querySelector(".hud")?.hidden) {
        const r = rectOf(top);
        if (r) nodes.push({ id: "hud", defId: "def:hud", kind: "hud", label: "Top bar", rect: r, instance: {} });
        const a = rectOf(mount.querySelector(".action-bar"));
        if (a) nodes.push({ id: "action-bar", defId: "def:action-bar", kind: "action-bar", label: "Action bar", rect: a, instance: {} });
      }
      const rb = mount.querySelector(".reaction-bar");
      if (rb && !rb.hidden) {
        const r = rectOf(rb);
        if (r) nodes.push({ id: "reaction-bar", defId: "def:reaction-bar", kind: "reaction-bar", label: "Reaction countdown", rect: r, instance: {} });
      }
      return { nodes };
    },

    getState: () => ({
      screen: game.state.screen,
      players: game.state.players,
      alive: game.state.alive,
      deck: game.state.deck,
    }),
    getScreen: () => game.currentScreen(),
    showScreen: (id) => game.showScreen(id),
    commands: {
      "quick-match": { label: "Quick match", icon: "Play", description: "Start a match against three medium AI", mutates: true, run: () => game.quickMatch() },
      "skip-cinematic": { label: "Skip cinematic", icon: "FastForward", description: "Speed through the playing cinematic", mutates: false, run: () => game.skipCinematic() },
    },
  };
}
