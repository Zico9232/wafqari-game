// Lightweight effects: pooled point particles (4 draw calls total), shock
// rings, the البطران shield dome, glowing redirect arrows, fireworks and
// confetti. Every effect advances only through update(dt).

import * as THREE from "three";

function dotTexture(kind) {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d");
  if (kind === "soft") {
    const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    grad.addColorStop(0, "rgba(255,255,255,1)");
    grad.addColorStop(0.35, "rgba(255,255,255,0.7)");
    grad.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = grad;
    g.fillRect(0, 0, 64, 64);
  } else if (kind === "star") {
    g.fillStyle = "#fff";
    g.translate(32, 32);
    g.beginPath();
    for (let i = 0; i < 10; i++) {
      const r = i % 2 ? 11 : 30;
      const a = (i / 10) * Math.PI * 2 - Math.PI / 2;
      g.lineTo(Math.cos(a) * r, Math.sin(a) * r);
    }
    g.closePath();
    g.fill();
  } else if (kind === "smoke") {
    for (let i = 0; i < 6; i++) {
      const x = 20 + Math.random() * 24, y = 20 + Math.random() * 24;
      const grad = g.createRadialGradient(x, y, 0, x, y, 22);
      grad.addColorStop(0, "rgba(255,255,255,0.55)");
      grad.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = grad;
      g.fillRect(0, 0, 64, 64);
    }
  } else {
    g.fillStyle = "#fff";
    g.fillRect(18, 8, 28, 48);
  }
  const t = new THREE.CanvasTexture(c);
  return t;
}

const pointVertex = /* glsl */ `
  attribute float aSize;
  attribute float aAlpha;
  attribute vec3 aColor;
  varying float vAlpha;
  varying vec3 vColor;
  uniform float uScale;
  void main() {
    vAlpha = aAlpha;
    vColor = aColor;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = aSize * uScale / -mv.z;
    gl_Position = projectionMatrix * mv;
  }
`;
const pointFragment = /* glsl */ `
  uniform sampler2D map;
  varying float vAlpha;
  varying vec3 vColor;
  void main() {
    vec4 t = texture2D(map, gl_PointCoord);
    gl_FragColor = vec4(vColor * t.rgb, t.a * vAlpha);
    if (gl_FragColor.a < 0.01) discard;
  }
`;

function createPool(scene, kind, capacity, blending) {
  const geo = new THREE.BufferGeometry();
  const pos = new Float32Array(capacity * 3);
  const size = new Float32Array(capacity);
  const alpha = new Float32Array(capacity);
  const color = new Float32Array(capacity * 3);
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage));
  geo.setAttribute("aSize", new THREE.BufferAttribute(size, 1).setUsage(THREE.DynamicDrawUsage));
  geo.setAttribute("aAlpha", new THREE.BufferAttribute(alpha, 1).setUsage(THREE.DynamicDrawUsage));
  geo.setAttribute("aColor", new THREE.BufferAttribute(color, 3).setUsage(THREE.DynamicDrawUsage));
  const mat = new THREE.ShaderMaterial({
    uniforms: { map: { value: dotTexture(kind) }, uScale: { value: 300 } },
    vertexShader: pointVertex,
    fragmentShader: pointFragment,
    transparent: true,
    depthWrite: false,
    blending,
  });
  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  points.renderOrder = 10;
  scene.add(points);
  return { points, geo, mat, list: [], capacity };
}

export function createFx(view) {
  const { scene, camera } = view;
  const pools = {
    soft: createPool(scene, "soft", 600, THREE.AdditiveBlending),
    star: createPool(scene, "star", 200, THREE.AdditiveBlending),
    smoke: createPool(scene, "smoke", 160, THREE.NormalBlending),
    confetti: createPool(scene, "confetti", 400, THREE.NormalBlending),
  };
  const meshes = []; // timed effect meshes { mesh, t, dur, update }
  let budget = 1;
  let reduced = false;

  function emit(kind, opts) {
    const pool = pools[kind];
    const n = Math.max(1, Math.round((opts.count || 10) * budget * (reduced ? 0.4 : 1)));
    const col = new THREE.Color(opts.color || "#ffffff");
    const col2 = opts.color2 ? new THREE.Color(opts.color2) : null;
    for (let i = 0; i < n; i++) {
      if (pool.list.length >= pool.capacity) pool.list.shift();
      const dir = new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize();
      if (opts.up) dir.y = Math.abs(dir.y) * opts.up + (1 - opts.up) * dir.y;
      const speed = (opts.speed || 2) * (0.4 + Math.random() * 0.8);
      const c = col2 ? col.clone().lerp(col2, Math.random()) : col.clone();
      pool.list.push({
        p: opts.pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * (opts.spread || 0), (Math.random() - 0.5) * (opts.spread || 0), (Math.random() - 0.5) * (opts.spread || 0))),
        v: dir.multiplyScalar(speed).add(opts.vel || new THREE.Vector3()),
        life: 0,
        max: (opts.life || 1) * (0.6 + Math.random() * 0.6),
        s0: (opts.size || 0.3) * (0.6 + Math.random() * 0.8),
        s1: opts.sizeEnd ?? (opts.size || 0.3) * 0.2,
        c,
        cEnd: opts.colorEnd ? new THREE.Color(opts.colorEnd) : null,
        g: opts.gravity || 0,
        drag: opts.drag ?? 1.5,
        a0: opts.alpha ?? 1,
        flutter: opts.flutter || 0,
        ph: Math.random() * 6,
      });
    }
  }

  function addTimed(mesh, dur, step) {
    scene.add(mesh);
    meshes.push({ mesh, t: 0, dur, step });
  }

  // --- Composite effects -------------------------------------------------

  function sparkle(pos, color = "#ffe08a", count = 24) {
    emit("star", { pos, count, color, speed: 2.2, size: 0.28, life: 0.7, drag: 2.5 });
    emit("soft", { pos, count: count * 0.6, color, speed: 1.2, size: 0.4, life: 0.5 });
  }

  function impact(pos, color = "#ffdd55") {
    emit("star", { pos, count: 26, color, color2: "#ffffff", speed: 4.5, size: 0.38, life: 0.55, drag: 3 });
    emit("soft", { pos, count: 18, color: "#ff5533", speed: 2.5, size: 0.6, life: 0.4 });
    ring(pos, "#ffd36a", 0.45, 1.6);
  }

  function explosion(pos) {
    emit("soft", { pos, count: 90, color: "#fff2a0", color2: "#ff7a1a", colorEnd: "#c01800", speed: 5.5, size: 1.1, sizeEnd: 0.2, life: 1.0, drag: 2.2, up: 0.4 });
    emit("star", { pos, count: 40, color: "#ffd060", speed: 7, size: 0.35, life: 0.9, gravity: -4, drag: 1.2 });
    emit("smoke", { pos, count: 40, color: "#3a2a24", color2: "#6a5a50", speed: 2.2, size: 1.6, sizeEnd: 3.2, life: 2.2, drag: 1.4, up: 0.8, vel: new THREE.Vector3(0, 1.2, 0), alpha: 0.85 });
    ring(pos, "#ffae3a", 0.9, 4.5, 0.08);
    ring(pos.clone().setY(0.05), "#ff5a20", 1.2, 6, 0.04);
  }

  function fire(pos, seconds = 1.2) {
    emit("soft", { pos, count: 40 * seconds, color: "#ffd060", colorEnd: "#ff2200", speed: 0.8, size: 0.7, sizeEnd: 0.1, life: 0.9, up: 1, vel: new THREE.Vector3(0, 2, 0), spread: 0.5 });
  }

  function ring(pos, color, dur = 0.6, maxScale = 2, thick = 0.06) {
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending });
    const mesh = new THREE.Mesh(new THREE.RingGeometry(1 - thick * 2, 1, 64), mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.copy(pos);
    addTimed(mesh, dur, (k) => {
      mesh.scale.setScalar(0.1 + maxScale * (1 - Math.pow(1 - k, 3)));
      mat.opacity = 0.9 * (1 - k);
    });
  }

  function shield(pos, dur = 2.0) {
    const mat = new THREE.ShaderMaterial({
      uniforms: { uT: { value: 0 }, uA: { value: 1 } },
      vertexShader: `varying vec3 vN; varying vec3 vV; varying vec2 vUv;
        void main(){ vUv=uv; vN=normalize(normalMatrix*normal); vec4 mv=modelViewMatrix*vec4(position,1.0); vV=normalize(-mv.xyz); gl_Position=projectionMatrix*mv; }`,
      fragmentShader: `uniform float uT; uniform float uA; varying vec3 vN; varying vec3 vV; varying vec2 vUv;
        void main(){ float f=pow(1.0-abs(dot(vN,vV)),2.2); float hex=step(0.92, fract(vUv.x*24.0+vUv.y*12.0))+step(0.92,fract(vUv.y*14.0-uT*0.5));
        vec3 c=mix(vec3(1.0,0.75,0.2),vec3(1.0,0.95,0.6),f); gl_FragColor=vec4(c,(f*0.9+hex*0.15+0.06)*uA); }`,
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    });
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), mat);
    mesh.position.copy(pos);
    addTimed(mesh, dur, (k, dt) => {
      mat.uniforms.uT.value += dt;
      const s = k < 0.2 ? k / 0.2 : 1;
      mesh.scale.setScalar(1.3 * (0.2 + 0.8 * (1 - Math.pow(1 - s, 3))) * (1 + Math.sin(k * 30) * 0.02));
      mat.uniforms.uA.value = k > 0.75 ? (1 - k) / 0.25 : 1;
    });
    sparkle(pos.clone().add(new THREE.Vector3(0, 0.8, 0)), "#ffe9a0", 30);
  }

  function arrow(from, to, color = "#5ff2ff", dur = 1.4) {
    const mid = from.clone().lerp(to, 0.5).add(new THREE.Vector3(0, 1.4, 0));
    const curve = new THREE.QuadraticBezierCurve3(from.clone(), mid, to.clone());
    const geo = new THREE.TubeGeometry(curve, 40, 0.06, 8, false);
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95, depthWrite: false, blending: THREE.AdditiveBlending });
    const tube = new THREE.Mesh(geo, mat);
    const head = new THREE.Mesh(new THREE.ConeGeometry(0.17, 0.42, 14), mat);
    const tangent = curve.getTangent(1);
    head.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), tangent);
    head.position.copy(to);
    const group = new THREE.Group();
    group.add(tube, head);
    const total = geo.index.count;
    addTimed(group, dur, (k) => {
      const draw = Math.min(1, k / 0.45);
      geo.setDrawRange(0, Math.floor(total * draw / 6) * 6);
      head.visible = draw >= 1;
      mat.opacity = k > 0.7 ? 0.95 * (1 - k) / 0.3 : 0.95;
    });
    emit("soft", { pos: to.clone(), count: 14, color, speed: 1.5, size: 0.4, life: 0.6 });
  }

  function fireworks(center) {
    const colors = ["#ffd24a", "#ff6a3a", "#5ff2ff", "#ff4fa8", "#9dff6a"];
    for (let i = 0; i < 3; i++) {
      const pos = center.clone().add(new THREE.Vector3((Math.random() - 0.5) * 5, 2.5 + Math.random() * 2, (Math.random() - 0.5) * 3));
      const c = colors[Math.floor(Math.random() * colors.length)];
      emit("soft", { pos, count: 50, color: c, color2: "#ffffff", speed: 4, size: 0.35, life: 1.3, gravity: -2.5, drag: 1.4 });
      emit("star", { pos, count: 12, color: c, speed: 3, size: 0.3, life: 1, gravity: -2 });
    }
  }

  function confetti(center, count = 120) {
    emit("confetti", { pos: center.clone().add(new THREE.Vector3(0, 4, 0)), count, color: "#ffd24a", color2: "#fff3c0", speed: 3, size: 0.32, sizeEnd: 0.28, life: 3.2, gravity: -2.2, drag: 1.8, spread: 5, flutter: 1 });
  }

  // --- Frame update ---------------------------------------------------------

  function update(dt) {
    for (const pool of Object.values(pools)) {
      const { list, geo } = pool;
      const posA = geo.attributes.position.array;
      const sizeA = geo.attributes.aSize.array;
      const alphaA = geo.attributes.aAlpha.array;
      const colA = geo.attributes.aColor.array;
      let w = 0;
      for (let i = 0; i < list.length; i++) {
        const q = list[i];
        q.life += dt;
        if (q.life >= q.max) continue;
        q.v.y += q.g * dt;
        q.v.multiplyScalar(Math.max(0, 1 - q.drag * dt));
        q.p.addScaledVector(q.v, dt);
        if (q.flutter) q.p.x += Math.sin(q.life * 6 + q.ph) * dt * 0.8;
        const k = q.life / q.max;
        posA[w * 3] = q.p.x; posA[w * 3 + 1] = q.p.y; posA[w * 3 + 2] = q.p.z;
        sizeA[w] = THREE.MathUtils.lerp(q.s0, q.s1, k) * (q.flutter ? 0.6 + Math.abs(Math.sin(q.life * 8 + q.ph)) * 0.6 : 1);
        alphaA[w] = q.a0 * (k < 0.1 ? k / 0.1 : 1 - Math.pow(k, 2));
        const c = q.cEnd ? q.c.clone().lerp(q.cEnd, k) : q.c;
        colA[w * 3] = c.r; colA[w * 3 + 1] = c.g; colA[w * 3 + 2] = c.b;
        list[w] = q;
        w++;
      }
      list.length = w;
      geo.setDrawRange(0, w);
      geo.attributes.position.needsUpdate = true;
      geo.attributes.aSize.needsUpdate = true;
      geo.attributes.aAlpha.needsUpdate = true;
      geo.attributes.aColor.needsUpdate = true;
      pool.mat.uniforms.uScale.value = view.renderer.domElement.height / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)));
    }
    for (let i = meshes.length - 1; i >= 0; i--) {
      const m = meshes[i];
      m.t += dt;
      const k = Math.min(1, m.t / m.dur);
      m.step(k, dt);
      if (k >= 1) {
        scene.remove(m.mesh);
        m.mesh.traverse((o) => { o.geometry?.dispose(); o.material?.dispose?.(); });
        meshes.splice(i, 1);
      }
    }
  }

  function clear() {
    for (const pool of Object.values(pools)) pool.list.length = 0;
    for (const m of meshes) scene.remove(m.mesh);
    meshes.length = 0;
  }

  return {
    emit, sparkle, impact, explosion, fire, ring, shield, arrow, fireworks, confetti, update, clear,
    setBudget(b) { budget = b; },
    setReduced(r) { reduced = r; },
  };
}
