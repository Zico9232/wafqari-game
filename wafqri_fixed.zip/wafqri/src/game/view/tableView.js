// Where every card is drawn. Card positions come only from engine snapshots
// (applySnapshot), so whatever the animations do, the table always settles
// on the true game state. Each card flies to a new zone along an arc, then
// eases to follow its slot (hands re-fan as they change).

import * as THREE from "three";
import { CARD_INFO, BACK_ART } from "../rules/cards.js";
import { CARD_H, CARD_W, cardMaterials, contactShadowTexture, createCardMesh, setCardArt } from "./cardMesh.js";
import { TABLE } from "./scene.js";

const DECK_POS = new THREE.Vector3(1.5, 0, 0.45);
const DISCARD_POS = new THREE.Vector3(-0.35, 0, 0.45);
const PILE_SCALE = 0.66;
const OPP_SCALE = 0.42;
const HAND_DIST = 3.2;
const UP = new THREE.Vector3(0, 1, 0);

const tmpV = new THREE.Vector3();
const tmpQ = new THREE.Quaternion();
const tmpE = new THREE.Euler();

function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619);
  return ((h >>> 0) % 1000) / 1000;
}

export function createTableView(view, textures) {
  const { scene, camera } = view;
  cardMaterials(textures);
  const root = new THREE.Group();
  root.name = "cards";
  scene.add(root);

  const cards = new Map(); // cid → { mesh, zone, flight, pos, quat, scale }
  let types = {};
  let snap = null;
  let viewer = 0; // seat shown at the bottom
  let showViewerFaces = true;
  let playerCount = 0;
  const seatAngles = [];
  const overrides = new Map();
  let selected = null;
  let revealAll = false; // debug: show every face

  // Contact shadows under the piles.
  const shadowMat = new THREE.MeshBasicMaterial({ map: contactShadowTexture(), transparent: true, depthWrite: false });
  for (const p of [DECK_POS, DISCARD_POS]) {
    const s = new THREE.Mesh(new THREE.PlaneGeometry(1.25, 1.6), shadowMat);
    s.rotation.x = -Math.PI / 2;
    s.position.set(p.x, 0.003, p.z);
    root.add(s);
  }

  // Turn-direction ring around the centre with three arrow heads.
  const ringGroup = new THREE.Group();
  ringGroup.position.set(0.55, 0.02, 0.45);
  const goldMat = new THREE.MeshStandardMaterial({ color: "#f2c35b", emissive: "#6a4300", emissiveIntensity: 0.7, metalness: 0.7, roughness: 0.3 });
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.75, 0.035, 8, 96), goldMat);
  ring.rotation.x = Math.PI / 2;
  ringGroup.add(ring);
  const arrows = new THREE.Group();
  const coneGeo = new THREE.ConeGeometry(0.13, 0.34, 12);
  for (let i = 0; i < 3; i++) {
    // Arrow heads point along increasing angle = clockwise seen from above,
    // the order seats are filled (bottom → left → top → right).
    const a = (i / 3) * Math.PI * 2;
    const head = new THREE.Mesh(coneGeo, goldMat);
    head.position.set(Math.cos(a) * 1.75, 0.04, Math.sin(a) * 1.75);
    head.quaternion.setFromUnitVectors(UP, new THREE.Vector3(-Math.sin(a), 0, Math.cos(a)));
    arrows.add(head);
  }
  ringGroup.add(arrows);
  root.add(ringGroup);
  let direction = 1;
  let ringFlip = 0; // 0..1 flip animation

  // Glowing seat marker for the current player.
  const glowMat = new THREE.MeshBasicMaterial({ color: "#ffd25a", transparent: true, opacity: 0.8, depthWrite: false, blending: THREE.AdditiveBlending });
  const turnGlow = new THREE.Mesh(new THREE.RingGeometry(0.45, 0.62, 48), glowMat);
  turnGlow.rotation.x = -Math.PI / 2;
  turnGlow.visible = false;
  root.add(turnGlow);
  let turnSeat = null;
  let time = 0;

  // ---------------------------------------------------------------------
  // Seats

  function seatOrder(index) {
    // Position of player `index` around the table relative to the viewer.
    return (index - viewer + playerCount) % playerCount;
  }

  function computeSeats() {
    seatAngles.length = 0;
    const k = playerCount - 1;
    const presets = {
      1: [0], 2: [-55, 55], 3: [-85, 0, 85], 4: [-100, -38, 38, 100], 5: [-108, -58, 0, 58, 108],
    };
    const list = presets[k] || [];
    for (const deg of list) seatAngles.push((deg * Math.PI) / 180);
  }

  // Seat anchor (just outside the rim) for player id.
  function seatWorld(id, out = new THREE.Vector3()) {
    const order = seatOrder(id);
    if (order === 0) return out.set(0, 0.4, TABLE.d / 2 + 0.9);
    const a = seatAngles[order - 1];
    return out.set(Math.sin(a) * (TABLE.w / 2 + 0.55), 0.45, -Math.cos(a) * (TABLE.d / 2 + 0.55));
  }

  // ---------------------------------------------------------------------
  // Camera-space hand layout for the viewer.

  function handMetrics() {
    const halfH = HAND_DIST * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    const halfW = halfH * camera.aspect;
    const cw = Math.min(halfW * 2 * 0.22, (halfH * 2 * 0.21) / CARD_H * CARD_W);
    return { halfH, halfW, cw, ch: cw * CARD_H };
  }

  function viewerHandSlot(i, n, cid, outPos, outQuat) {
    const { halfH, halfW, cw, ch } = handMetrics();
    const avail = halfW * 2 * 0.94 - cw;
    const spacing = n > 1 ? Math.min(cw * 0.78, avail / (n - 1)) : 0;
    const x = (i - (n - 1) / 2) * spacing;
    const t = n > 1 ? i / (n - 1) - 0.5 : 0;
    const angle = -t * Math.min(0.35, n * 0.045);
    let y = -halfH + ch * 0.5 + halfH * 0.035 - Math.abs(t) * ch * 0.08;
    let scale = cw;
    if (cid === selected) {
      y += ch * 0.32;
      scale *= 1.12;
    }
    outPos.set(x, y, -HAND_DIST + i * 0.004);
    camera.updateMatrixWorld();
    outPos.applyMatrix4(camera.matrixWorld);
    tmpE.set(0, 0, angle);
    outQuat.setFromEuler(tmpE);
    outQuat.premultiply(camera.quaternion);
    if (!showViewerFaces) outQuat.multiply(tmpQ.setFromAxisAngle(UP, Math.PI));
    return scale;
  }

  // Opponent fan on the felt in front of their seat, face down.
  function opponentSlot(id, i, n, outPos, outQuat) {
    const order = seatOrder(id);
    const a = seatAngles[order - 1] ?? 0;
    const cx = Math.sin(a) * (TABLE.w / 2 - 0.75);
    const cz = -Math.cos(a) * (TABLE.d / 2 - 0.85);
    const spacing = Math.min(0.17, 1.2 / Math.max(1, n));
    const off = (i - (n - 1) / 2) * spacing;
    // Tangent direction (perpendicular to seat direction).
    const tx = Math.cos(a), tz = Math.sin(a);
    outPos.set(cx + tx * off, 0.03 + i * 0.004, cz + tz * off);
    tmpE.set(revealAll ? -Math.PI / 2 : Math.PI / 2, 0, 0);
    outQuat.setFromEuler(tmpE);
    tmpQ.setFromAxisAngle(UP, -a + (i - (n - 1) / 2) * 0.06);
    outQuat.premultiply(tmpQ);
    return OPP_SCALE;
  }

  function slotFor(cid, zone, outPos, outQuat) {
    const ov = overrides.get(cid);
    if (ov) {
      outPos.copy(ov.pos);
      outQuat.copy(ov.quat);
      return ov.scale;
    }
    switch (zone.kind) {
      case "deck": {
        outPos.set(DECK_POS.x, 0.012 + zone.fromBottom * 0.011, DECK_POS.z);
        tmpE.set(Math.PI / 2, 0, 0);
        outQuat.setFromEuler(tmpE);
        outQuat.premultiply(tmpQ.setFromAxisAngle(UP, (hash(cid) - 0.5) * 0.08));
        return PILE_SCALE;
      }
      case "discard": {
        outPos.set(DISCARD_POS.x + (hash(cid + "x") - 0.5) * 0.12, 0.012 + Math.min(zone.index, 45) * 0.006, DISCARD_POS.z + (hash(cid + "z") - 0.5) * 0.12);
        tmpE.set(-Math.PI / 2, 0, 0);
        outQuat.setFromEuler(tmpE);
        outQuat.premultiply(tmpQ.setFromAxisAngle(UP, (hash(cid) - 0.5) * 0.6));
        return PILE_SCALE;
      }
      case "stack": {
        // Played cards hover above the table facing the camera.
        tmpV.set(0.05 + zone.index * 0.42, 1.45 + zone.index * 0.05, 1.2 + zone.index * 0.06);
        outPos.copy(tmpV);
        outQuat.copy(camera.quaternion);
        outQuat.multiply(tmpQ.setFromAxisAngle(new THREE.Vector3(0, 0, 1), -0.05 + zone.index * 0.08));
        return 0.95;
      }
      case "hand": {
        if (zone.owner === viewer) return viewerHandSlot(zone.index, zone.count, cid, outPos, outQuat);
        return opponentSlot(zone.owner, zone.index, zone.count, outPos, outQuat);
      }
      default:
        outPos.set(DECK_POS.x, 0.02, DECK_POS.z);
        outQuat.identity();
        return PILE_SCALE;
    }
  }

  function faceVisible(cid, zone) {
    const ov = overrides.get(cid);
    if (ov) return ov.faceUp;
    if (revealAll && zone.kind === "hand") return true;
    if (zone.kind === "stack" || zone.kind === "discard") return true;
    if (zone.kind === "hand") return zone.owner === viewer && showViewerFaces;
    return false;
  }

  function ensureCard(cid) {
    let c = cards.get(cid);
    if (c) return c;
    const mesh = createCardMesh(BACK_ART);
    mesh.position.copy(DECK_POS);
    mesh.scale.setScalar(PILE_SCALE);
    mesh.userData.cid = cid;
    root.add(mesh);
    c = { cid, mesh, zone: null, zoneKey: "", flight: null, faceArt: BACK_ART };
    cards.set(cid, c);
    return c;
  }

  function zonesFrom(s) {
    const zones = new Map();
    s.deck.forEach((cid, i) => zones.set(cid, { kind: "deck", index: i, fromBottom: s.deck.length - 1 - i }));
    s.discard.forEach((cid, i) => zones.set(cid, { kind: "discard", index: i }));
    s.stack.forEach((cid, i) => zones.set(cid, { kind: "stack", index: i }));
    s.hands.forEach((hand, owner) => hand.forEach((cid, i) => zones.set(cid, { kind: "hand", owner, index: i, count: hand.length })));
    return zones;
  }

  // Apply a snapshot. opts.stagger delays each flight (dealing); opts.snapDeck
  // re-sorts the deck instantly so a secret reinsertion leaves no trace.
  function applySnapshot(s, opts = {}) {
    snap = s;
    const zones = zonesFrom(s);
    let order = 0;
    for (const [cid, zone] of zones) {
      const c = ensureCard(cid);
      const key = zone.kind === "hand" ? `hand${zone.owner}` : zone.kind;
      const changed = key !== c.zoneKey;
      c.zone = zone;
      if (changed && c.zoneKey !== "") {
        if (zone.kind === "deck" && opts.snapDeck && c.zoneKey === "deck") {
          c.flight = null;
        } else {
          startFlight(c, opts.stagger ? order++ * opts.stagger : 0, opts.duration);
        }
      } else if (changed && c.zoneKey === "" && opts.stagger) {
        startFlight(c, order++ * opts.stagger, opts.duration);
      } else if (changed && c.zoneKey === "") {
        // First appearance without dealing: place directly.
        const p = new THREE.Vector3();
        const q = new THREE.Quaternion();
        const sc = slotFor(cid, zone, p, q);
        c.mesh.position.copy(p);
        c.mesh.quaternion.copy(q);
        c.mesh.scale.setScalar(sc);
      }
      if (zone.kind === "deck" && opts.snapDeck) {
        const p = new THREE.Vector3();
        const q = new THREE.Quaternion();
        const sc = slotFor(cid, zone, p, q);
        if (!c.flight) {
          c.mesh.position.copy(p);
          c.mesh.quaternion.copy(q);
          c.mesh.scale.setScalar(sc);
        }
      }
      c.zoneKey = key;
    }
    for (const cid of opts.teleport || []) {
      const c = cards.get(cid);
      const zone = zones.get(cid);
      if (!c || !zone) continue;
      const p = new THREE.Vector3();
      const q = new THREE.Quaternion();
      const sc = slotFor(cid, zone, p, q);
      c.flight = null;
      c.mesh.position.copy(p);
      c.mesh.quaternion.copy(q);
      c.mesh.scale.setScalar(sc);
    }
    // Cards no longer anywhere (shouldn't happen) are hidden.
    for (const [cid, c] of cards) c.mesh.visible = zones.has(cid);
    if (selected && !(zones.get(selected)?.kind === "hand" && zones.get(selected).owner === viewer)) selected = null;
    setDirection(s.direction);
  }

  function startFlight(c, delay = 0, duration = 0.5) {
    c.flight = {
      t: -delay,
      dur: duration || 0.5,
      from: c.mesh.position.clone(),
      fromQ: c.mesh.quaternion.clone(),
      fromS: c.mesh.scale.x,
    };
  }

  // ---------------------------------------------------------------------

  function setDirection(dir) {
    if (dir !== direction) {
      direction = dir;
      ringFlip = 1;
    }
  }

  function setTurn(id) {
    turnSeat = id;
  }

  const pos = new THREE.Vector3();
  const quat = new THREE.Quaternion();

  function update(dt) {
    time += dt;
    for (const c of cards.values()) {
      if (!c.zone || !c.mesh.visible) continue;
      const scale = slotFor(c.cid, c.zone, pos, quat);
      // Face texture only for cards this viewer may see.
      const art = faceVisible(c.cid, c.zone) ? CARD_INFO[types[c.cid]]?.art ?? BACK_ART : BACK_ART;
      if (art !== c.faceArt) {
        setCardArt(c.mesh, art);
        c.faceArt = art;
      }
      const f = c.flight;
      if (f) {
        f.t += dt;
        if (f.t < 0) continue;
        const k = Math.min(1, f.t / f.dur);
        const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        c.mesh.position.lerpVectors(f.from, pos, e);
        c.mesh.position.y += Math.sin(k * Math.PI) * 0.9;
        c.mesh.quaternion.slerpQuaternions(f.fromQ, quat, e);
        c.mesh.scale.setScalar(THREE.MathUtils.lerp(f.fromS, scale, e));
        if (k >= 1) c.flight = null;
      } else {
        const a = 1 - Math.exp(-dt * 16);
        c.mesh.position.lerp(pos, a);
        c.mesh.quaternion.slerp(quat, a);
        c.mesh.scale.setScalar(THREE.MathUtils.lerp(c.mesh.scale.x, scale, a));
      }
    }
    // Direction ring: slow spin in play direction, flip animation on شوح.
    arrows.rotation.y -= dt * 0.35 * direction;
    if (ringFlip > 0) {
      ringFlip = Math.max(0, ringFlip - dt * 1.6);
      arrows.scale.set(1, 1, direction * Math.cos(ringFlip * Math.PI));
      goldMat.emissiveIntensity = 0.7 + ringFlip * 2.5;
    } else {
      arrows.scale.set(1, 1, direction);
    }
    // Turn glow.
    if (turnSeat !== null && playerCount) {
      seatWorld(turnSeat, pos);
      const inward = pos.clone().setY(0).multiplyScalar(0.86);
      turnGlow.visible = true;
      turnGlow.position.set(inward.x, 0.02, inward.z);
      const pulse = 1 + Math.sin(time * 4) * 0.08;
      turnGlow.scale.setScalar(seatOrder(turnSeat) === 0 ? 1.6 * pulse : 1.25 * pulse);
      glowMat.opacity = 0.55 + Math.sin(time * 4) * 0.2;
    } else turnGlow.visible = false;
  }

  // ---------------------------------------------------------------------
  // Picking

  const raycaster = new THREE.Raycaster();
  function pick(ndc) {
    raycaster.setFromCamera(ndc, camera);
    const handMeshes = [];
    const deckMeshes = [];
    for (const c of cards.values()) {
      if (!c.mesh.visible || !c.zone) continue;
      if (c.zone.kind === "hand" && c.zone.owner === viewer) handMeshes.push(c.mesh);
      if (c.zone.kind === "deck") deckMeshes.push(c.mesh);
    }
    const hit = raycaster.intersectObjects(handMeshes, true)[0];
    if (hit) {
      let o = hit.object;
      while (o && !o.userData.cid) o = o.parent;
      if (o) return { kind: "hand", cid: o.userData.cid };
    }
    if (raycaster.intersectObjects(deckMeshes, true)[0]) return { kind: "deck" };
    return null;
  }

  return {
    root,
    applySnapshot,
    update,
    pick,
    seatWorld,
    setTurn,
    setDirection,
    setTypes(map) { types = map; },
    setPlayers(count, viewerSeat) {
      playerCount = count;
      viewer = viewerSeat;
      computeSeats();
    },
    setViewer(v, faces = true) {
      viewer = v;
      showViewerFaces = faces;
    },
    get viewer() { return viewer; },
    setSelected(cid) { selected = cid; },
    setRevealAll(v) { revealAll = v; },
    get selected() { return selected; },
    setOverride(cid, ov) { if (ov) overrides.set(cid, ov); else overrides.delete(cid); },
    clearOverrides() { overrides.clear(); },
    cardMesh: (cid) => cards.get(cid)?.mesh,
    cardWorld(cid, out = new THREE.Vector3()) {
      const m = cards.get(cid)?.mesh;
      return m ? out.copy(m.position) : out.copy(DISCARD_POS);
    },
    deckPos: () => DECK_POS.clone().setY(0.3),
    discardPos: () => DISCARD_POS.clone().setY(0.3),
    stackPos: () => new THREE.Vector3(0.05, 1.45, 1.2),
    handWorld(id, out = new THREE.Vector3()) {
      if (seatOrder(id) === 0) {
        const { halfH, ch } = handMetrics();
        out.set(0, -halfH + ch * 0.6, -HAND_DIST);
        camera.updateMatrixWorld();
        return out.applyMatrix4(camera.matrixWorld);
      }
      const a = seatAngles[seatOrder(id) - 1] ?? 0;
      return out.set(Math.sin(a) * (TABLE.w / 2 - 0.75), 0.2, -Math.cos(a) * (TABLE.d / 2 - 0.85));
    },
    clear() {
      for (const c of cards.values()) root.remove(c.mesh);
      cards.clear();
      overrides.clear();
      snap = null;
      selected = null;
      turnSeat = null;
    },
    get snapshot() { return snap; },
    shake(cid, amount) {
      const m = cards.get(cid)?.mesh;
      if (m) m.position.x += (Math.random() - 0.5) * amount;
    },
    allDeckCards: () => (snap ? snap.deck.slice() : []),
    handMetrics,
  };
}
