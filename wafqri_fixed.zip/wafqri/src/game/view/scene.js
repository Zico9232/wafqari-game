// The 3D majlis: renderer, camera rig, lights, the carved table and the room.
// Table space: felt top at y = 0, the viewer sits at +z (bottom of screen).

import * as THREE from "three";

export const TABLE = { w: 6.2, d: 7.4, rim: 0.42, radius: 1.2 };

export function createScene(mount, textures) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.domElement.className = "game-surface";
  mount.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color("#1a0d07");
  scene.fog = new THREE.Fog("#1a0d07", 22, 46);

  const camera = new THREE.PerspectiveCamera(42, 0.6, 0.1, 120);
  scene.add(camera);

  // --- Lights: warm lantern key + soft fill + rim.
  const hemi = new THREE.HemisphereLight("#ffd9a8", "#2a130a", 0.85);
  scene.add(hemi);
  const key = new THREE.DirectionalLight("#ffd2a0", 2.1);
  key.position.set(-4, 12, 5);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.left = -6;
  key.shadow.camera.right = 6;
  key.shadow.camera.top = 6;
  key.shadow.camera.bottom = -6;
  key.shadow.camera.near = 2;
  key.shadow.camera.far = 30;
  key.shadow.bias = -0.0015;
  key.shadow.normalBias = 0.02;
  scene.add(key);
  const lanternL = new THREE.PointLight("#ff9a3c", 18, 14, 1.8);
  lanternL.position.set(-5, 4.5, -5);
  scene.add(lanternL);
  const lanternR = new THREE.PointLight("#ff9a3c", 18, 14, 1.8);
  lanternR.position.set(5, 4.5, -5);
  scene.add(lanternR);
  // Red warning light used by the وافقري cinematic.
  const alarm = new THREE.PointLight("#ff2a12", 0, 16, 1.5);
  alarm.position.set(0, 4, 1);
  scene.add(alarm);

  // --- Room: the majlis plate is the screen background (cover-fitted on
  // resize, top kept); the table floats in front of it.
  const backdrop = textures.backdrop;
  backdrop.matrixAutoUpdate = true;
  scene.background = backdrop;
  scene.fog = null;
  const room = new THREE.Group();
  room.name = "room";
  scene.add(room);
  // Soft shadow pool under the table.
  const pool = new THREE.Mesh(
    new THREE.CircleGeometry(6.5, 40),
    new THREE.MeshBasicMaterial({ color: "#000000", transparent: true, opacity: 0.35, depthWrite: false }),
  );
  pool.rotation.x = -Math.PI / 2;
  pool.position.y = -3.3;
  room.add(pool);

  // --- Table.
  const table = buildTable(textures);
  scene.add(table.group);

  // Cover-fit the background image to the frame, keeping its top (lanterns).
  function fitBackground(aspect) {
    const img = backdrop.image;
    if (!img) return;
    const ia = img.naturalWidth / img.naturalHeight;
    if (aspect > ia) {
      backdrop.repeat.set(1, ia / aspect);
      backdrop.offset.set(0, 1 - ia / aspect);
    } else {
      backdrop.repeat.set(aspect / ia, 1);
      backdrop.offset.set((1 - aspect / ia) / 2, 0);
    }
  }

  return {
    renderer, scene, camera, key, hemi, alarm, table, room, backdrop, fitBackground,
    lanterns: [lanternL, lanternR],
  };
}

function roundedRectShape(w, d, r) {
  const s = new THREE.Shape();
  const x = -w / 2, y = -d / 2;
  s.moveTo(x + r, y);
  s.lineTo(x + w - r, y);
  s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + d - r);
  s.quadraticCurveTo(x + w, y + d, x + w - r, y + d);
  s.lineTo(x + r, y + d);
  s.quadraticCurveTo(x, y + d, x, y + d - r);
  s.lineTo(x, y + r);
  s.quadraticCurveTo(x, y, x + r, y);
  return s;
}

function buildTable(textures) {
  const group = new THREE.Group();
  group.name = "table";
  const { w, d, rim, radius } = TABLE;

  // Felt top (UVs remapped to world units so the pattern tiles evenly).
  const feltGeo = new THREE.ShapeGeometry(roundedRectShape(w, d, radius), 12);
  const uv = feltGeo.attributes.uv;
  const pos = feltGeo.attributes.position;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, pos.getX(i) / 2.4, pos.getY(i) / 2.4);
  const felt = textures.felt;
  const feltMat = new THREE.MeshStandardMaterial({ map: felt, color: "#ffffff", roughness: 0.95, metalness: 0 });
  const feltMesh = new THREE.Mesh(feltGeo, feltMat);
  feltMesh.rotation.x = -Math.PI / 2;
  feltMesh.receiveShadow = true;
  feltMesh.name = "felt";
  group.add(feltMesh);

  // Wooden rim: rounded ring extruded upward with a bevel.
  const outer = roundedRectShape(w + rim * 2, d + rim * 2, radius + rim);
  outer.holes.push(roundedRectShape(w, d, radius));
  const rimGeo = new THREE.ExtrudeGeometry(outer, { depth: 0.32, bevelEnabled: true, bevelThickness: 0.08, bevelSize: 0.08, bevelSegments: 3, curveSegments: 14 });
  const wood = textures.wood;
  wood.repeat.set(0.35, 0.35);
  const woodMat = new THREE.MeshStandardMaterial({ map: wood, color: "#b07a55", roughness: 0.45, metalness: 0.05 });
  const rimMesh = new THREE.Mesh(rimGeo, woodMat);
  rimMesh.rotation.x = -Math.PI / 2;
  rimMesh.position.y = -0.2;
  rimMesh.castShadow = true;
  rimMesh.receiveShadow = true;
  group.add(rimMesh);

  // Gold inlay band along the inner edge of the rim.
  const gold = new THREE.MeshStandardMaterial({ color: "#e0b04a", metalness: 0.9, roughness: 0.28, emissive: "#3a2400", emissiveIntensity: 0.4 });
  const band = roundedRectShape(w + rim * 1.1, d + rim * 1.1, radius + rim * 0.55);
  band.holes.push(roundedRectShape(w + rim * 0.8, d + rim * 0.8, radius + rim * 0.4));
  const inlayMesh = new THREE.Mesh(new THREE.ExtrudeGeometry(band, { depth: 0.03, bevelEnabled: false, curveSegments: 14 }), gold);
  inlayMesh.rotation.x = -Math.PI / 2;
  inlayMesh.position.y = 0.2;
  group.add(inlayMesh);

  // Gold studs around the rim.
  const studGeo = new THREE.SphereGeometry(0.07, 12, 8);
  const studs = new THREE.InstancedMesh(studGeo, gold, 28);
  const m = new THREE.Matrix4();
  let k = 0;
  for (let i = 0; i < 28; i++) {
    const t = (i / 28) * Math.PI * 2;
    const x = Math.sin(t) * (w / 2 + rim * 0.55);
    const z = Math.cos(t) * (d / 2 + rim * 0.55);
    const sx = Math.sign(x) * Math.min(Math.abs(x), w / 2 + rim * 0.55);
    const sz = Math.sign(z) * Math.min(Math.abs(z), d / 2 + rim * 0.55);
    m.makeTranslation(sx * 0.98, 0.24, sz * 0.98);
    studs.setMatrixAt(k++, m);
  }
  group.add(studs);

  // Apron + legs.
  const apron = new THREE.Mesh(new THREE.ExtrudeGeometry(roundedRectShape(w + 0.4, d + 0.4, radius), { depth: 0.5, bevelEnabled: false }), woodMat);
  apron.rotation.x = -Math.PI / 2;
  apron.position.y = -0.75;
  apron.castShadow = true;
  group.add(apron);
  const legGeo = new THREE.CylinderGeometry(0.22, 0.32, 2.7, 14);
  const ballGeo = new THREE.SphereGeometry(0.34, 16, 12);
  for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const leg = new THREE.Mesh(legGeo, woodMat);
    leg.position.set(x * (w / 2 - 0.5), -2.05, z * (d / 2 - 0.6));
    leg.castShadow = true;
    group.add(leg);
    const ball = new THREE.Mesh(ballGeo, gold);
    ball.position.set(leg.position.x, -0.85, leg.position.z);
    ball.scale.y = 0.55;
    group.add(ball);
  }

  // Central medallion ring (the turn-direction ring lives in table.js).
  return { group, felt: feltMesh, feltMat, rimMesh, gold };
}

// Quality presets: shadows, pixel ratio and particle budget.
export const QUALITY = {
  high: { shadows: true, shadowSize: 1024, dpr: 2, particles: 1 },
  medium: { shadows: true, shadowSize: 512, dpr: 1.5, particles: 0.6 },
  low: { shadows: false, shadowSize: 256, dpr: 1, particles: 0.35 },
};

export function applyQuality(view, level) {
  const q = QUALITY[level] || QUALITY.medium;
  view.renderer.shadowMap.enabled = q.shadows;
  view.key.castShadow = q.shadows;
  if (view.key.shadow.mapSize.x !== q.shadowSize) {
    view.key.shadow.mapSize.set(q.shadowSize, q.shadowSize);
    view.key.shadow.map?.dispose();
    view.key.shadow.map = null;
  }
  view.quality = q;
  view.scene.traverse((o) => {
    if (o.material) {
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      mats.forEach((mm) => { mm.needsUpdate = true; });
    }
  });
  return q;
}
