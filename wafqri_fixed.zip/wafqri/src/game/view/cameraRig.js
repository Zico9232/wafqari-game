// Camera rig: one base pose framed for the frame's aspect (near-square to
// tall portrait), a focus blend for cinematics, menu orbit, and shake.

import * as THREE from "three";
import { TABLE } from "./scene.js";

export function createCameraRig(camera) {
  const base = { pos: new THREE.Vector3(0, 12, 9), target: new THREE.Vector3(0, 0, 0.8) };
  const focus = { point: new THREE.Vector3(), weight: 0, goal: 0, dist: 5 };
  const lookNow = new THREE.Vector3();
  let mode = "menu"; // menu | match | intro
  let modeBlend = 0; // 0 = menu orbit, 1 = match pose
  let orbit = 0;
  let shakeAmt = 0;
  let shakeT = 0;
  let heightBias = 1;
  let reduced = false;

  function frame(aspect) {
    camera.aspect = aspect;
    const vf = THREE.MathUtils.degToRad(camera.fov / 2);
    const hf = Math.atan(Math.tan(vf) * aspect);
    const elev = THREE.MathUtils.degToRad(57);
    const halfW = TABLE.w / 2 + TABLE.rim + 0.55;
    const dH = halfW / Math.tan(hf);
    const projDepth = (TABLE.d + 1.2) * Math.sin(elev);
    const dV = (projDepth / 2 + 1.9) / Math.tan(vf);
    const d = Math.max(dH, dV) * heightBias;
    base.target.set(0, 0, 0.95 + (aspect < 0.7 ? 0.35 : 0));
    base.pos.set(0, Math.sin(elev) * d, Math.cos(elev) * d).add(base.target);
    camera.updateProjectionMatrix();
  }

  function focusOn(point, dist = 5.5) {
    focus.point.copy(point);
    focus.dist = dist;
    focus.goal = reduced ? 0.35 : 1;
  }

  function release() {
    focus.goal = 0;
  }

  function shake(amount, dur = 0.4) {
    if (reduced) return;
    shakeAmt = Math.max(shakeAmt, amount);
    shakeT = Math.max(shakeT, dur);
  }

  const p = new THREE.Vector3();
  const t = new THREE.Vector3();
  const fp = new THREE.Vector3();

  function update(dt) {
    orbit += dt * 0.12;
    modeBlend = THREE.MathUtils.damp(modeBlend, mode === "match" ? 1 : 0, 2.2, dt);
    focus.weight = THREE.MathUtils.damp(focus.weight, focus.goal, focus.goal > focus.weight ? 5 : 3, dt);

    // Menu orbit pose: higher, circling the table.
    const r = base.pos.distanceTo(base.target) * 0.95;
    const menuPos = new THREE.Vector3(Math.sin(orbit) * r * 0.55, r * 0.75, Math.cos(orbit) * r * 0.75);
    p.copy(menuPos).lerp(base.pos, modeBlend);
    t.set(0, 0.5, 0).lerp(base.target, modeBlend);

    if (focus.weight > 0.001) {
      fp.copy(p).sub(focus.point).normalize().multiplyScalar(focus.dist).add(focus.point);
      p.lerp(fp, focus.weight * 0.75);
      t.lerp(focus.point, focus.weight * 0.6);
    }
    if (shakeT > 0) {
      shakeT -= dt;
      const s = shakeAmt * Math.min(1, shakeT * 3);
      p.x += (Math.random() - 0.5) * s;
      p.y += (Math.random() - 0.5) * s;
      if (shakeT <= 0) shakeAmt = 0;
    }
    camera.position.copy(p);
    lookNow.copy(t);
    camera.lookAt(lookNow);
    camera.updateMatrixWorld();
  }

  return {
    frame,
    focusOn,
    release,
    shake,
    update,
    setMode(m, instant = false) {
      mode = m;
      if (instant) modeBlend = m === "match" ? 1 : 0;
    },
    setHeightBias(v) { heightBias = v; },
    setReduced(v) { reduced = v; },
    get mode() { return mode; },
  };
}
