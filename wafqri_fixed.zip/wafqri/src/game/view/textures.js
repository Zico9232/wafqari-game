// Loads every picture the table needs through the Playabl asset handle and
// turns them into Three.js textures. The 18 original card images are
// required: if any fails, loading rejects with the file that failed, and the
// game shows that instead of substituting other art.

import * as THREE from "three";
import { BACK_ART, CARD_INFO } from "../rules/cards.js";

// Open-eyed characters get a code-drawn blink. Coordinates are fractions of
// the cut-out image (x right, y down): eye centre, radii, and a nearby skin
// point the eyelid colour is sampled from. The other characters' eyes are
// hidden by hair, closed, or behind glasses in the original art.
export const EYES = {
  3: { cx: 0.465, cy: 0.5, rx: 0.082, ry: 0.058, sx: 0.465, sy: 0.43 },
  11: { cx: 0.452, cy: 0.562, rx: 0.068, ry: 0.06, sx: 0.39, sy: 0.6 },
  16: { cx: 0.494, cy: 0.556, rx: 0.08, ry: 0.085, sx: 0.62, sy: 0.6 },
};

const CARD_ARTS = Array.from({ length: 18 }, (_, i) => i + 1);
const CHAR_ARTS = Object.values(CARD_INFO).map((c) => c.art);

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.decoding = "async";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(url));
    img.src = url;
  });
}

export async function loadTextures(assets, onProgress) {
  const url = (key) => {
    const u = assets?.get(key);
    if (!u) throw new Error(key);
    return u;
  };
  const jobs = [];
  const out = { card: {}, char: {}, charImg: {}, lid: {}, felt: null, wood: null, backdrop: null, cardUrl: {}, charUrl: {} };
  let done = 0;
  const total = CARD_ARTS.length + CHAR_ARTS.length + 3;
  const track = (p) => p.then((v) => { done++; onProgress?.(done / total); return v; });

  for (const art of CARD_ARTS) {
    const key = `CARD_${art}`;
    const u = url(key);
    out.cardUrl[art] = u;
    jobs.push(track(loadImage(u).catch(() => { throw new Error(`${art}.png`); })).then((img) => {
      out.card[art] = makeTexture(img, true);
    }));
  }
  for (const art of CHAR_ARTS) {
    const u = url(`CHAR_${art}`);
    out.charUrl[art] = u;
    jobs.push(track(loadImage(u)).then((img) => {
      out.charImg[art] = img;
      out.char[art] = makeTexture(img, true);
      out.lid[art] = sampleLid(img, EYES[art]);
    }));
  }
  jobs.push(track(loadImage(url("FELT_TEXTURE"))).then((img) => { out.felt = makeTexture(img, true, true); }));
  jobs.push(track(loadImage(url("WOOD_TEXTURE"))).then((img) => { out.wood = makeTexture(img, true, true); }));
  jobs.push(track(loadImage(url("MAJLIS_BACKDROP"))).then((img) => { out.backdrop = makeTexture(img, true); }));
  await Promise.all(jobs);
  out.back = out.card[BACK_ART];
  return out;
}

function makeTexture(img, srgb, repeat = false) {
  const tex = new THREE.Texture(img);
  if (srgb) tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  if (repeat) tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.needsUpdate = true;
  return tex;
}

// Eyelid colour = the skin right next to the eye in the original art.
function sampleLid(img, eye) {
  if (!eye) return null;
  try {
    const c = document.createElement("canvas");
    c.width = 8;
    c.height = 8;
    const ctx = c.getContext("2d", { willReadFrequently: true });
    const sx = eye.sx * img.naturalWidth - 4;
    const sy = eye.sy * img.naturalHeight - 4;
    ctx.drawImage(img, sx, sy, 8, 8, 0, 0, 8, 8);
    const d = ctx.getImageData(0, 0, 8, 8).data;
    let r = 0, g = 0, b = 0, n = 0;
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] < 200) continue;
      r += d[i]; g += d[i + 1]; b += d[i + 2]; n++;
    }
    if (!n) return new THREE.Color("#f3c9a5");
    return new THREE.Color(`rgb(${Math.round(r / n)},${Math.round(g / n)},${Math.round(b / n)})`);
  } catch {
    return new THREE.Color("#f3c9a5");
  }
}
