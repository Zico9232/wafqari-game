// Living card characters — honest 2.5D: each is the character cut out of the
// creator's original card art, drawn on a flat plane that moves in 3D. The
// shader adds breathing, a head sway, a cloth ripple on the lower body and,
// for the three characters whose eyes are open in the art, a blink drawn as
// an eyelid. They are not rigged 3D models.

import * as THREE from "three";
import { CARD_INFO } from "../rules/cards.js";
import { EYES } from "./textures.js";

const vertex = /* glsl */ `
  uniform float uTime;
  uniform float uWave;
  uniform float uBreath;
  uniform float uSway;
  uniform float uSquash;
  varying vec2 vUv;
  void main() {
    vUv = uv;
    vec3 p = position;
    float h = uv.y;
    // Breathing: gentle vertical stretch from the feet.
    p.y += (h) * sin(uTime * 2.2) * 0.018 * uBreath;
    p.x *= 1.0 + sin(uTime * 2.2 + 1.2) * 0.01 * uBreath;
    // Head sway: the top leans more than the bottom.
    p.x += sin(uTime * 1.3) * 0.035 * uSway * h * h;
    // Cloth ripple: lower body only.
    float low = clamp(1.0 - h * 1.8, 0.0, 1.0);
    p.x += sin(uTime * 5.0 + h * 14.0) * 0.022 * uWave * low * low;
    // Squash & stretch for hops and impacts.
    p.y *= 1.0 + uSquash;
    p.x *= 1.0 - uSquash * 0.5;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`;

const fragment = /* glsl */ `
  uniform sampler2D map;
  uniform float uOpacity;
  uniform vec3 uTint;
  uniform float uTintAmt;
  uniform vec4 uEye;      // cx, cy (uv, y up), rx, ry
  uniform float uBlink;   // 0 open → 1 closed
  uniform vec3 uLid;
  uniform float uHasEye;
  uniform float uGhost;
  varying vec2 vUv;
  void main() {
    vec4 c = texture2D(map, vUv);
    if (c.a < 0.4) discard;
    if (uHasEye > 0.5 && uBlink > 0.01) {
      vec2 d = (vUv - uEye.xy) / uEye.zw;
      if (dot(d, d) < 1.0) {
        float lidEdge = 1.0 - 2.0 * uBlink;   // top of eye = 1, bottom = -1
        if (d.y > lidEdge) c.rgb = uLid;
        if (abs(d.y - lidEdge) < 0.14) c.rgb = mix(c.rgb, vec3(0.12, 0.06, 0.04), 0.85);
      }
    }
    c.rgb = mix(c.rgb, uTint, uTintAmt);
    if (uGhost > 0.0) c.rgb = mix(c.rgb, vec3(0.45, 0.95, 1.0), uGhost * 0.6) + vec3(0.1, 0.2, 0.25) * uGhost;
    gl_FragColor = vec4(c.rgb, c.a * uOpacity);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

let nextId = 1;
let waveScale = 1;
// Cloth ripple strength for every character (a live tweak).
export function setWaveScale(v) { waveScale = v; }

export function createCharacter(textures, type, { height = 1.6 } = {}) {
  const art = CARD_INFO[type]?.art ?? 2;
  const tex = textures.char[art];
  const img = textures.charImg[art];
  const aspect = img ? img.naturalWidth / img.naturalHeight : 0.7;
  const geo = new THREE.PlaneGeometry(height * aspect, height, 8, 14);
  geo.translate(0, height / 2, 0); // pivot at the feet
  const eye = EYES[art];
  const uniforms = {
    map: { value: tex },
    uTime: { value: Math.random() * 10 },
    uWave: { value: waveScale },
    uBreath: { value: 1 },
    uSway: { value: 1 },
    uSquash: { value: 0 },
    uOpacity: { value: 1 },
    uTint: { value: new THREE.Color("#ffffff") },
    uTintAmt: { value: 0 },
    uEye: { value: eye ? new THREE.Vector4(eye.cx, 1 - eye.cy, eye.rx, eye.ry) : new THREE.Vector4() },
    uBlink: { value: 0 },
    uLid: { value: textures.lid[art] || new THREE.Color("#f3c9a5") },
    uHasEye: { value: eye ? 1 : 0 },
    uGhost: { value: 0 },
  };
  const mat = new THREE.ShaderMaterial({
    uniforms, vertexShader: vertex, fragmentShader: fragment, transparent: true, side: THREE.DoubleSide, depthWrite: true,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = false;
  mesh.renderOrder = 5;
  const root = new THREE.Group();
  root.name = `character-${type}`;
  root.add(mesh);
  const actor = {
    id: `ch${nextId++}`,
    type,
    root,
    mesh,
    uniforms,
    height,
    blinkTimer: 1 + Math.random() * 3,
    blinkT: 0,
    frozen: false,
    billboard: true,
    update(dt, camera) {
      if (!actor.frozen) uniforms.uTime.value += dt;
      uniforms.uWave.value = waveScale;
      // Blink every few seconds (only shows on open-eyed characters).
      actor.blinkTimer -= dt;
      if (actor.blinkTimer <= 0) {
        actor.blinkT = 0.16;
        actor.blinkTimer = 2 + Math.random() * 3.5;
      }
      if (actor.blinkT > 0) {
        actor.blinkT = Math.max(0, actor.blinkT - dt);
        const k = 1 - Math.abs(actor.blinkT / 0.16 - 0.5) * 2;
        uniforms.uBlink.value = actor.frozen ? 0 : k;
      } else uniforms.uBlink.value = 0;
      // Face the camera around the vertical axis.
      if (actor.billboard && camera) {
        const p = root.getWorldPosition(tmp);
        const dx = camera.position.x - p.x;
        const dz = camera.position.z - p.z;
        mesh.rotation.y = Math.atan2(dx, dz) - root.rotation.y;
        const dy = camera.position.y - p.y;
        mesh.rotation.x = -Math.atan2(dy, Math.hypot(dx, dz)) * 0.35;
      }
    },
    dispose() {
      root.parent?.remove(root);
      geo.dispose();
      mat.dispose();
    },
  };
  return actor;
}

const tmp = new THREE.Vector3();
