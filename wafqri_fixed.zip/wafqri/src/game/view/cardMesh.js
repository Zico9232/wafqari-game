// A physical card: rounded, with real thickness. The original PNG is the
// face, the original 1.png is the back, and a cream edge runs around the
// side. Local space: the card lies in XY, face toward +Z, 1 × CARD_H units.

import * as THREE from "three";

export const CARD_W = 1;
export const CARD_H = 1.68;
const THICK = 0.018;
const R = 0.09;

function rounded(w, h, r) {
  const s = new THREE.Shape();
  const x = -w / 2, y = -h / 2;
  s.moveTo(x + r, y);
  s.lineTo(x + w - r, y);
  s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r);
  s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h);
  s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r);
  s.quadraticCurveTo(x, y, x + r, y);
  return s;
}

let shared = null;

function sharedParts() {
  if (shared) return shared;
  const shape = rounded(CARD_W, CARD_H, R);
  const face = new THREE.ShapeGeometry(shape, 6);
  const uv = face.attributes.uv;
  const p = face.attributes.position;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, p.getX(i) / CARD_W + 0.5, p.getY(i) / CARD_H + 0.5);
  const side = new THREE.ExtrudeGeometry(shape, { depth: THICK, bevelEnabled: false, curveSegments: 6 });
  side.translate(0, 0, -THICK / 2);
  const hidden = new THREE.MeshBasicMaterial({ visible: false });
  const edge = new THREE.MeshStandardMaterial({ color: "#efe6cf", roughness: 0.6 });
  shared = { face, side, hidden, edge, faceMats: {}, backMat: null };
  return shared;
}

export function cardMaterials(textures) {
  const s = sharedParts();
  for (const [art, tex] of Object.entries(textures.card)) {
    s.faceMats[art] = new THREE.MeshStandardMaterial({
      map: tex, roughness: 0.55, metalness: 0, alphaTest: 0.35, transparent: false,
    });
  }
  s.backMat = s.faceMats[1];
  return s;
}

export function createCardMesh(art) {
  const s = sharedParts();
  const group = new THREE.Group();
  const front = new THREE.Mesh(s.face, s.faceMats[art] || s.backMat);
  front.position.z = THICK / 2 + 0.0005;
  front.castShadow = true;
  const back = new THREE.Mesh(s.face, s.backMat);
  back.rotation.y = Math.PI;
  back.position.z = -THICK / 2 - 0.0005;
  back.castShadow = true;
  const side = new THREE.Mesh(s.side, [s.hidden, s.edge]);
  side.castShadow = true;
  group.add(front, back, side);
  group.userData.front = front;
  return group;
}

export function setCardArt(group, art) {
  const s = sharedParts();
  group.userData.front.material = s.faceMats[art] || s.backMat;
}

// Soft round shadow texture used as fake contact shadows under piles.
export function contactShadowTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d");
  const grad = g.createRadialGradient(32, 32, 4, 32, 32, 32);
  grad.addColorStop(0, "rgba(0,0,0,0.55)");
  grad.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}
