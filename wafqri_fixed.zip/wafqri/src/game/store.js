// Player settings, profile and lifetime record, saved with the Playabl save
// API. Loaded data is treated as untrusted and merged over defaults.

const DEFAULTS = {
  version: 1,
  settings: { music: 0.5, sfx: 0.8, muted: false, quality: "auto", reducedMotion: false, cinematicSpeed: 1, reactionScale: 1 },
  profile: { name: "أنت", avatar: 16 },
  record: { games: 0, wins: { easy: 0, medium: 0, hard: 0 }, friendsGames: 0, wafqariSurvived: 0, streak: 0, bestStreak: 0 },
};

export async function createStore(sdk) {
  let data = structuredClone(DEFAULTS);
  // Follow the device's reduced-motion preference until the player chooses.
  if (typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches) data.settings.reducedMotion = true;
  try {
    const saved = await sdk.gameState.load();
    if (saved && saved.version === 1) {
      data.settings = { ...data.settings, ...(saved.settings || {}) };
      data.profile = { ...data.profile, ...(saved.profile || {}) };
      data.record = { ...data.record, ...(saved.record || {}), wins: { ...data.record.wins, ...(saved.record?.wins || {}) } };
    }
  } catch {
    /* first run or no host: defaults */
  }
  if (data.settings.quality === "auto") {
    const coarse = typeof matchMedia === "function" && matchMedia("(pointer: coarse)").matches;
    data.settings.quality = coarse ? "medium" : "high";
  }
  return {
    get settings() { return data.settings; },
    get profile() { return data.profile; },
    get record() { return data.record; },
    save() {
      sdk.gameState.save(structuredClone(data)).catch(() => {});
    },
  };
}
