// All sound is synthesized: the audio generation service was unavailable,
// so the music is composed in code (rendered once into looping buffers) and
// every effect is built from oscillators and filtered noise. Runs on the
// Playabl-managed audio context; silent until the first tap unlocks it.

const HIJAZ = [0, 1, 4, 5, 7, 8, 10, 12, 13, 16, 17, 19];
const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);

export function createAudio(sdk) {
  let handle = null;
  let ctx = null;
  let master = null;
  let musicGain = null;
  let sfxGain = null;
  let noiseBuf = null;
  let music = { menu: null, game: null };
  let current = null; // { name, source }
  let wanted = null;
  let settings = { music: 0.5, sfx: 0.8, muted: false };
  let suspendedByHost = false;
  let unlocking = null;

  async function init() {
    try {
      handle = await sdk.audio.getContext();
      ctx = handle.context;
      master = ctx.createGain();
      master.connect(ctx.destination);
      musicGain = ctx.createGain();
      sfxGain = ctx.createGain();
      musicGain.connect(master);
      sfxGain.connect(master);
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -10;
      sfxGain.disconnect();
      sfxGain.connect(comp);
      comp.connect(master);
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      applyLevels();
    } catch (e) {
      console.warn("[audio] unavailable", e);
    }
  }
  const ready = init();

  function applyLevels() {
    if (!ctx) return;
    const m = settings.muted ? 0 : 1;
    master.gain.value = m;
    musicGain.gain.value = settings.music * 0.55;
    sfxGain.gain.value = settings.sfx;
  }

  // First genuine tap: unlock, then render music in the background.
  function unlock() {
    if (unlocking) return unlocking;
    unlocking = ready.then(async () => {
      if (!handle) return;
      try { await handle.unlock(); } catch { /* stays silent */ }
      if (!music.menu) music.menu = await renderMenuMusic(ctx.sampleRate).catch(() => null);
      if (!music.game) music.game = await renderGameMusic(ctx.sampleRate).catch(() => null);
      if (wanted) playMusic(wanted, true);
    });
    return unlocking;
  }

  function playMusic(name, force = false) {
    wanted = name;
    if (!ctx || suspendedByHost) return;
    if (!force && current?.name === name) return;
    const buf = music[name];
    if (current) {
      const old = current;
      try {
        old.gain.gain.setTargetAtTime(0, ctx.currentTime, 0.4);
        old.source.stop(ctx.currentTime + 1.5);
      } catch { /* already stopped */ }
      current = null;
    }
    if (!buf || !name) return;
    const source = ctx.createBufferSource();
    source.buffer = buf;
    source.loop = true;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    gain.gain.setTargetAtTime(1, ctx.currentTime, 0.6);
    source.connect(gain);
    gain.connect(musicGain);
    source.start();
    current = { name, source, gain };
  }

  // Frozen / hidden: stop music; resume from the same track afterwards.
  function setPaused(paused) {
    if (paused === suspendedByHost) return;
    suspendedByHost = paused;
    if (paused && current) {
      try { current.source.stop(); } catch { /* noop */ }
      current = null;
    } else if (!paused && wanted) playMusic(wanted, true);
  }

  // ---- synth helpers ----------------------------------------------------

  function osc(type, f0, t0, dur, gain, f1 = f0, attack = 0.005) {
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t0);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(sfxGain);
    o.start(t0);
    o.stop(t0 + dur + 0.05);
    return o;
  }

  function noise(t0, dur, gain, type = "bandpass", f0 = 1000, f1 = f0, q = 1, attack = 0.003) {
    const s = ctx.createBufferSource();
    s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.Q.value = q;
    f.frequency.setValueAtTime(f0, t0);
    if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    s.connect(f);
    f.connect(g);
    g.connect(sfxGain);
    s.start(t0, Math.random());
    s.stop(t0 + dur + 0.05);
  }

  const SFX = {
    tick: (t) => osc("triangle", 1300, t, 0.05, 0.12, 1600),
    pop: (t) => { osc("sine", 500, t, 0.12, 0.25, 1100); },
    flick: (t) => { noise(t, 0.09, 0.35, "highpass", 2500, 4500, 0.7); osc("triangle", 900, t, 0.04, 0.05, 500); },
    deal: (t) => noise(t, 0.06, 0.22, "bandpass", 3000, 5000, 0.8),
    shuffle: (t) => { for (let i = 0; i < 14; i++) noise(t + i * 0.045 + Math.random() * 0.01, 0.04, 0.2 + Math.random() * 0.1, "bandpass", 2600 + Math.random() * 1500, 3500, 1.2); },
    slap: (t) => { noise(t, 0.16, 0.9, "bandpass", 1800, 600, 0.8, 0.001); osc("sine", 160, t, 0.18, 0.7, 60); noise(t + 0.02, 0.25, 0.25, "highpass", 5000, 3000, 0.5); },
    steal: (t) => { [0, 3, 7, 3, 0].forEach((d, i) => osc("triangle", mtof(72 + d), t + i * 0.07, 0.09, 0.18)); osc("sine", 1200, t + 0.38, 0.15, 0.15, 2400); },
    magic: (t) => { noise(t, 0.6, 0.25, "bandpass", 400, 4000, 3, 0.15); [0, 4, 7, 12, 16].forEach((d, i) => osc("sine", mtof(79 + d), t + 0.1 + i * 0.06, 0.4, 0.08)); },
    whoosh: (t) => noise(t, 0.35, 0.4, "bandpass", 300, 2500, 1.5, 0.08),
    shield: (t) => { [62, 66, 69, 74, 78].forEach((m, i) => { osc("sine", mtof(m), t + i * 0.05, 1.6, 0.1, mtof(m), 0.02); osc("sine", mtof(m + 12), t + i * 0.05, 0.9, 0.03); }); noise(t, 0.8, 0.12, "highpass", 6000, 9000, 0.5, 0.05); },
    explosion: (t) => {
      noise(t, 2.2, 1.0, "lowpass", 2400, 60, 0.7, 0.005);
      osc("sine", 110, t, 1.4, 1.0, 28);
      osc("sawtooth", 70, t, 0.6, 0.3, 30);
      noise(t + 0.05, 1.2, 0.35, "bandpass", 900, 200, 0.6);
    },
    alarm: (t) => { for (let i = 0; i < 3; i++) { osc("square", 880, t + i * 0.32, 0.14, 0.08); osc("square", 660, t + i * 0.32 + 0.15, 0.14, 0.08); } },
    stamp: (t) => { osc("sine", 120, t, 0.25, 0.9, 50); noise(t, 0.12, 0.6, "lowpass", 900, 200, 0.7, 0.001); },
    reverse: (t) => { noise(t, 0.5, 0.35, "bandpass", 3000, 300, 2, 0.05); osc("sine", 300, t, 0.5, 0.12, 900); },
    reveal: (t) => { [74, 78, 81, 86].forEach((m, i) => osc("sine", mtof(m), t + i * 0.08, 0.7, 0.12)); },
    turn: (t) => { osc("sine", mtof(74), t, 0.35, 0.14); osc("sine", mtof(81), t + 0.1, 0.45, 0.12); },
    attack: (t) => { osc("sawtooth", 220, t, 0.25, 0.15, 110); noise(t, 0.2, 0.3, "bandpass", 1200, 400, 1); },
    error: (t) => osc("square", 160, t, 0.15, 0.08, 120),
    fanfare: (t) => {
      const notes = [[62, 0, 0.18], [66, 0.18, 0.18], [69, 0.36, 0.18], [74, 0.54, 0.7], [72, 1.3, 0.2], [74, 1.5, 1.0]];
      for (const [m, s, d] of notes) {
        osc("sawtooth", mtof(m), t + s, d + 0.2, 0.09, mtof(m), 0.03);
        osc("triangle", mtof(m + 12), t + s, d + 0.15, 0.06, mtof(m + 12), 0.03);
      }
      osc("sine", mtof(50), t + 0.54, 2.2, 0.2, mtof(50), 0.05);
    },
    defeat: (t) => { [67, 66, 65, 63].forEach((m, i) => osc("sawtooth", mtof(m - 12), t + i * 0.35, i === 3 ? 1.1 : 0.35, 0.1, i === 3 ? mtof(m - 13) : mtof(m - 12), 0.03)); },
    sting: (t) => {
      osc("sine", mtof(50), t, 2.5, 0.25, mtof(50), 0.02);
      [62, 63, 66, 69, 74].forEach((m, i) => osc("triangle", mtof(m), t + 0.15 + i * 0.12, 0.8, 0.12));
      noise(t, 0.4, 0.4, "lowpass", 400, 100, 0.8);
    },
  };

  function play(name, delay = 0) {
    if (!ctx || ctx.state !== "running" || settings.muted) return;
    const fn = SFX[name];
    if (fn) fn(ctx.currentTime + 0.01 + delay);
  }

  // Cartoon "voice": a few vowel-formant syllables under a speech bubble.
  function mumble(pitch = 1, syllables = 3, excited = false) {
    if (!ctx || ctx.state !== "running" || settings.muted) return;
    const t0 = ctx.currentTime + 0.02;
    const vowels = [[800, 1200], [400, 2000], [600, 1000], [300, 2300]];
    for (let i = 0; i < syllables; i++) {
      const t = t0 + i * 0.11;
      const [f1, f2] = vowels[Math.floor(Math.random() * vowels.length)];
      const o = ctx.createOscillator();
      o.type = "sawtooth";
      const base = 180 * pitch * (excited ? 1.25 : 1);
      o.frequency.setValueAtTime(base * (1 + Math.random() * 0.2), t);
      o.frequency.linearRampToValueAtTime(base * (excited && i === syllables - 1 ? 1.6 : 0.9), t + 0.1);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.16, t + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);
      const b1 = ctx.createBiquadFilter();
      b1.type = "bandpass"; b1.frequency.value = f1; b1.Q.value = 6;
      const b2 = ctx.createBiquadFilter();
      b2.type = "bandpass"; b2.frequency.value = f2; b2.Q.value = 8;
      o.connect(b1); o.connect(b2);
      b1.connect(g); b2.connect(g);
      g.connect(sfxGain);
      o.start(t);
      o.stop(t + 0.12);
    }
  }

  return {
    unlock,
    play,
    mumble,
    playMusic,
    setPaused,
    setSettings(s) { settings = { ...settings, ...s }; applyLevels(); },
    get running() { return ctx?.state === "running"; },
  };
}

// ---------------------------------------------------------------------------
// Music, rendered once with an OfflineAudioContext.

function scaleNote(deg, base = 62) {
  const oct = Math.floor(deg / 7);
  const d = ((deg % 7) + 7) % 7;
  return base + HIJAZ[d] + oct * 12;
}

function makeNoise(oc) {
  const b = oc.createBuffer(1, oc.sampleRate, oc.sampleRate);
  const d = b.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  return b;
}

// Plucked oud-like note: sine + soft 2nd/3rd harmonics, quick attack, long decay.
function pluck(oc, out, t, midi, dur, level, pan = 0) {
  const p = oc.createStereoPanner();
  p.pan.value = pan;
  p.connect(out);
  const g = oc.createGain();
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(level, t + 0.012);
  g.gain.setTargetAtTime(level * 0.35, t + 0.02, 0.12);
  g.gain.setTargetAtTime(0, t + dur, 0.18);
  g.connect(p);
  const f = mtof(midi);
  for (const [mult, amp, type] of [[1, 1, "triangle"], [2, 0.25, "sine"], [3, 0.08, "sine"]]) {
    const o = oc.createOscillator();
    o.type = type;
    o.frequency.value = f * mult;
    const og = oc.createGain();
    og.gain.value = amp;
    o.connect(og);
    og.connect(g);
    o.start(t);
    o.stop(t + dur + 1.2);
  }
}

function pad(oc, out, t, midi, dur, level, pan = 0) {
  const p = oc.createStereoPanner();
  p.pan.value = pan;
  p.connect(out);
  const g = oc.createGain();
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(level, t + 0.6);
  g.gain.setValueAtTime(level, t + Math.max(0.6, dur - 0.8));
  g.gain.linearRampToValueAtTime(0, t + dur + 0.6);
  g.connect(p);
  const o = oc.createOscillator();
  o.type = "sine";
  o.frequency.value = mtof(midi);
  const o2 = oc.createOscillator();
  o2.type = "sine";
  o2.frequency.value = mtof(midi) * 2.003;
  const g2 = oc.createGain();
  g2.gain.value = 0.06;
  o.connect(g);
  o2.connect(g2);
  g2.connect(g);
  o.start(t); o2.start(t);
  o.stop(t + dur + 0.8); o2.stop(t + dur + 0.8);
}

function dum(oc, out, t, level) {
  const o = oc.createOscillator();
  o.type = "sine";
  o.frequency.setValueAtTime(110, t);
  o.frequency.exponentialRampToValueAtTime(48, t + 0.25);
  const g = oc.createGain();
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(level, t + 0.006);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.4);
  o.connect(g); g.connect(out);
  o.start(t); o.stop(t + 0.45);
}

function tak(oc, out, t, level, noiseBuf, pan = 0.2) {
  const s = oc.createBufferSource();
  s.buffer = noiseBuf;
  const f = oc.createBiquadFilter();
  f.type = "bandpass"; f.frequency.value = 3200; f.Q.value = 1.4;
  const g = oc.createGain();
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(level, t + 0.003);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);
  const p = oc.createStereoPanner();
  p.pan.value = pan;
  s.connect(f); f.connect(g); g.connect(p); p.connect(out);
  s.start(t, Math.random() * 0.5); s.stop(t + 0.1);
}

const TAIL = 2;

// Schedule every note, render loop + tail, then fold the tail back onto the
// start so the loop has no seam.
async function renderLoop(oc, out, length, notes) {
  for (const n of notes) n(oc, out, 0);
  const rendered = await oc.startRendering();
  const sr = rendered.sampleRate;
  const loopLen = Math.floor(length * sr);
  const buf = new AudioBuffer({ numberOfChannels: 2, length: loopLen, sampleRate: sr });
  for (let ch = 0; ch < 2; ch++) {
    const src = rendered.getChannelData(ch);
    const dst = buf.getChannelData(ch);
    dst.set(src.subarray(0, loopLen));
    for (let i = loopLen; i < src.length; i++) dst[i - loopLen] += src[i];
  }
  return buf;
}

async function renderMenuMusic(sampleRate) {
  const sr = Math.min(sampleRate, 22050);
  const eighth = 60 / 104 / 2;
  const bar = eighth * 6;
  const bars = 24;
  const length = bar * bars;
  const oc = new OfflineAudioContext(2, Math.ceil((length + TAIL) * sr), sr);
  const out = oc.createGain();
  out.gain.value = 0.55;
  out.connect(oc.destination);
  const nb = makeNoise(oc);
  const notes = [];
  // Melody phrases in hijaz scale degrees: [eighth, length, degree].
  const A = [[0, 2, 4], [2, 1, 3], [3, 2, 2], [6, 1, 1], [7, 2, 2], [9, 3, 0]];
  const B = [[0, 1, 4], [1, 1, 5], [2, 2, 6], [4, 1, 5], [5, 1, 4], [6, 3, 3], [9, 1, 2], [10, 2, 1]];
  const C = [[0, 3, 7], [3, 1, 6], [4, 2, 5], [6, 2, 4], [8, 1, 3], [9, 3, 4]];
  const D = [[0, 2, 2], [2, 1, 1], [3, 3, 0], [6, 6, -1]];
  const form = [A, null, B, null, A, D, C, null, B, null, C, D];
  form.forEach((phrase, i) => {
    if (!phrase) return;
    const start = i * 2 * bar;
    for (const [e, len, deg] of phrase) {
      const t = start + e * eighth;
      const lvl = 0.13 + (deg > 4 ? 0.02 : 0);
      notes.push((c, o, off) => pluck(c, o, t + off, scaleNote(deg), len * eighth, lvl, -0.15));
    }
  });
  // Bass + pad, chord per bar pair.
  const roots = [50, 50, 48, 50, 55, 55, 48, 50, 50, 46, 48, 50];
  roots.forEach((r, i) => {
    const t = i * 2 * bar;
    notes.push((c, o, off) => pad(c, o, t + off, r, bar * 2, 0.05, 0.25));
    for (let b = 0; b < 2; b++) {
      notes.push((c, o, off) => pluck(c, o, t + b * bar + off, r - 12, eighth * 2, 0.12, 0));
      notes.push((c, o, off) => pluck(c, o, t + b * bar + eighth * 3 + off, r - 12 + 7, eighth * 2, 0.07, 0));
    }
  });
  // Khaleeji 6/8 percussion with variations and breaths.
  for (let b = 0; b < bars; b++) {
    if (b % 8 === 7) continue; // breathing bar
    const t = b * bar;
    notes.push((c, o, off) => dum(c, o, t + off, 0.32));
    notes.push((c, o, off) => tak(c, o, t + eighth * 2 + off, 0.12, nb));
    notes.push((c, o, off) => dum(c, o, t + eighth * 3 + off, 0.22));
    notes.push((c, o, off) => tak(c, o, t + eighth * 4 + off, 0.09, nb, -0.2));
    if (b % 2) notes.push((c, o, off) => tak(c, o, t + eighth * 5 + off, 0.1, nb));
  }
  return renderLoop(oc, out, length, notes);
}

async function renderGameMusic(sampleRate) {
  const sr = Math.min(sampleRate, 22050);
  const beat = 60 / 72;
  const bar = beat * 4;
  const bars = 12;
  const length = bar * bars;
  const oc = new OfflineAudioContext(2, Math.ceil((length + TAIL) * sr), sr);
  const out = oc.createGain();
  out.gain.value = 0.5;
  out.connect(oc.destination);
  const nb = makeNoise(oc);
  const notes = [];
  // Drone: D and A, re-voiced every 4 bars.
  for (let i = 0; i < bars; i += 4) {
    const t = i * bar;
    notes.push((c, o, off) => pad(c, o, t + off, 50, bar * 4, 0.06, -0.3));
    notes.push((c, o, off) => pad(c, o, t + 0.4 + off, i === 4 ? 56 : 57, bar * 4 - 0.4, 0.035, 0.3));
  }
  // Sparse sneaky oud phrases with rests.
  const phrases = {
    0: [[0, 0.5, 0], [0.5, 0.5, 1], [1, 1, 2], [2.5, 1.5, 1]],
    2: [[0, 0.5, 4], [0.5, 0.5, 3], [1, 0.5, 2], [1.5, 0.5, 1], [2, 2, 0]],
    5: [[0, 1, 2], [1.5, 0.5, 3], [2, 0.5, 4], [2.5, 1.5, 5]],
    7: [[0, 0.5, 4], [0.5, 1, 2], [2, 2, 1]],
    9: [[0, 0.5, -1], [0.5, 0.5, 0], [1, 0.5, 1], [1.5, 2.5, 0]],
  };
  for (const [barIdx, ph] of Object.entries(phrases)) {
    const t0 = Number(barIdx) * bar;
    for (const [b, len, deg] of ph) {
      notes.push((c, o, off) => pluck(c, o, t0 + b * beat + off, scaleNote(deg, 62), len * beat, 0.11, 0.1));
    }
  }
  // Soft frame drum + finger snaps.
  for (let b = 0; b < bars; b++) {
    const t = b * bar;
    notes.push((c, o, off) => dum(c, o, t + off, 0.18));
    if (b % 4 !== 3) notes.push((c, o, off) => dum(c, o, t + beat * 2.5 + off, 0.1));
    notes.push((c, o, off) => tak(c, o, t + beat + off, 0.05, nb));
    notes.push((c, o, off) => tak(c, o, t + beat * 3 + off, 0.06, nb, -0.25));
  }
  return renderLoop(oc, out, length, notes);
}
